var http = require('http');
var server = http.createServer();
var fs = require('fs-extra');
var vurl = require('url');
var qs = require('querystring');
const path = require("path");
//const UAParser = require('ua-parser-js')

function getType(_url) {
  var types = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'text/javascript',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.jpeg': 'image/jpeg'
  }
  for (var key in types) {
    if (_url.endsWith(key)) {
      return types[key];
    }
  }
  return 'text/plain';
}
function import_material(){
  //************ ダウンロードファイルの取得。mtに格納
  const home_dir = process.env[process.platform == "win32" ? "USERPROFILE" : "HOME"];
  let mt = "";
  //******************* 以下は開発段階でのみ使用する *******************
  // materialディレクトリに格納されているapp(dir)の取得
  const app_files = fs.readdirSync(__dirname + "/materials");
  const app_dirList = app_files.filter((file) => {
    return fs.statSync(path.join(__dirname + "/materials", file)).isDirectory()
  });
  //************************************************************ */

  //インポート済みとしていmaterials.txtに書き込みれているapp(dir)
  let fsrt_array = [];
  let fsrt = fs.readFileSync(__dirname + "/materials.txt");
  if(fsrt == ""){
    fsrt_array =[];
  }else{
    //console.log("ss=" + fsrt);
    const mt_dir_array = String(fsrt).split(":");
    for(q1=0;q1<mt_dir_array.length;q1++){
      if(mt_dir_array[q1] == "") continue;
      fsrt_array.push(mt_dir_array[q1].split("^")[0])
    }
    //fsrt_array = String(fsrt).split(":");
    //fsrt_array.pop();
  }
  //取り込みが必要なapp(dir)
  const r_array = app_dirList.filter(i => fsrt_array.indexOf(i) == -1)
  //console.log("s1=" + app_dirList);
  //console.log("s2=" + fsrt_array);
  //console.log("s3=" + r_array);
  let rt = "";
  if(mt == ""){
    //Downloadsディレクトリに対象ファイルが無い場合
    if(r_array.length == 0){
      rt = "取り込むファイルが存在しません!";
      return rt;
    //materialsに新規教材が存在する場合
    }else{
      for(i=0;i<r_array.length;i++){
        fsrt += r_array[i] + "^";
        const sdata = fs.readFileSync(__dirname + "/materials/" + r_array[i] + "/sdata.txt");
        const obj = JSON.parse(sdata);
        const alias = obj.alias;
        fsrt += alias + ":";
        fs.writeFileSync(__dirname + "/materials.txt", fsrt);
        //ipadはコピー付加
        //fs.copySync(__dirname + "/materials/" + r_array[i] +"/" + r_array[i] + ".jpeg", __dirname + "/udbook/stocks/stocks_img/"+ r_array[i] + ".jpeg");
        //2022-5-18 改造によりrename不必要になった。
        //fs.rename(__dirname + "/materials/" + r_array[i] +"/" + r_array[i] + ".jpeg", __dirname + "/udbook/stocks/stocks_img/"+ r_array[i] + ".jpeg");
        rt += "「" + r_array[i] +"」のインポートを完了しました。\n";
      }
      return rt;
    }
  }
  //以降はダウンロードファイルが存在する場合で使用しない
  const download_dir_array = mt.slice(0,-1).split(":");//ud___xxx:ud___yyy:→['ud_xxx','ud_yyy]
  const import_dir_array = mt.replace("ud___","").slice(0,-1).split(":");//['xxx','yyy']
  //ディレクトリチェック
  for(i=0;i<import_dir_array.length;i++){
    let check_dir = __dirname + "/materials/" + import_dir_array[i];
    if( fs.existsSync(check_dir) ){
      rt += "「" + import_dir_array[i] + "」は既にインポートされています!\n";
    }else{
      fsrt += import_dir_array[i] + ":";
      fs.writeFileSync(__dirname + "/materials.txt", fsrt);
      //fs.copySync(check_dir + "/" + import_dir_array[i] + ".jpeg", __dirname + "/udbook/stocks/stocks_img/"+ import_dir_array[i] + ".jpeg");
      fs.rename(check_dir + "/" + import_dir_array[i] + ".jpeg", __dirname + "/udbook/stocks/stocks_img/"+ import_dir_array[i] + ".jpeg");
      rt += "「" + import_dir_array[i] +"」のインポートを完了しました。\n";
    }
  }
  return rt;
}
function delete_material(mtnm){
  //インポート済みとしていmaterials.txtに書き込みれているapp(dir)
  let fsrt = fs.readFileSync(__dirname + "/materials.txt");
  let fsrt_array;
  fsrt_array = String(fsrt).split(":");
  fsrt_array.pop();
  const index = fsrt_array.indexOf(mtnm);
  fsrt_array.splice(index, 1);
  
  let update_fsrt = "";
  for(i=0;i<fsrt_array.length;i++){
    update_fsrt += fsrt_array[i] + ":";
  }
  //materials.txtファイルの更新
  fs.writeFileSync(__dirname + "/materials.txt", update_fsrt);
  //書庫のアイコンの削除 2022-5-18不必要になった
  //fs.remove( __dirname + "/udbook/stocks/stocks_img/"+ mtnm + ".jpeg");
  //教材の削除
  fs.remove( __dirname + "/materials/" + mtnm);
  return mtnm + "を削除しました。";
}
//***************************************************************************************
//グローバル変数宣言・初期化
//2画面同時requestで最初は画面左ページ、次に画面右ページがrequestされる
//global.fh_pathは2画面のうち最後にrequestしたhtmlのパス(ページNo)になっている
global.fh_path = "/udbook";
global.fh_path_L;
global.fh_path_R;
global.material;
//__dirname:現在のディレクトリのパスを示す特別な変数(server.jsがあるディレクトリ:/Users/user1/udBookReader)
//request受信
server.on('request',function(req,res) {
  const dec_url = decodeURI(req.url);
  //console.log(dec_url);
  //GETメソッドによるrequest受信
  if (req.method === "GET") {
    //urlに付加されているクエリー格納
    const query_array = vurl.parse(dec_url,true).query;
    //xxx.html?key=material&???=???&...
    switch(query_array.key){
      //読み込む教材が選択されて最初のページがrequestされた場合
      case "material":
        page_url = __dirname + '/materials/' + query_array.material + "/" + query_array.page_no + "/index.html";
        //console.log(page_url);
        //requestされたhtmlファイルが格納されているフォルダをglobal変数に格納する
        //canvas,memo保存時の保存先指定に使用する
        global.fh_path = '/materials/' + query_array.material + "/" + query_array.page_no;
        if(query_array.side == "L"){
          global.fh_path_L = global.fh_path;
        }else if(query_array.side == "R"){
          global.fh_path_R = global.fh_path;
        }
        //教材名(フォルダ名)をglobal変数に格納する
        global.material = query_array.material;
        //page_urlのファイルをresponseで返す
        eri(req,res,page_url);
        break;
      //xxx.html?key=material_cont&???=???&...
      //教材が選択済みでページがrequestされた場合
      case "material_cont":
        //ページS0をrequestされた場合
        if(query_array.page_no == "S0"){
          page_url = __dirname + '/udbook/tmp_page.html';    
        }else{
          page_url = __dirname + '/materials/' + global.material + "/" + query_array.page_no + "/index.html";    
        }  //requestされたhtmlファイルが格納されているフォルダをglobal変数に格納する
        //canvas,memo保存時の保存先指定に使用する
        global.fh_path = '/materials/' + global.material + "/" + query_array.page_no;
        if(query_array.side == "L"){
          global.fh_path_L = global.fh_path;
        }else if(query_array.side == "R"){
          global.fh_path_R = global.fh_path;
        }
        console.log("side=" + query_array.side);
        console.log("L=" + global.fh_path_L);
        console.log("R=" + global.fh_path_R);
        //page_urlのファイルをresponseで返す
        eri(req,res,page_url);
        break;
      default:
        tani(req,res);
    }
  //POSTメソッドによるrequest受信(canvas,memoの保存処理)
  } else if (req.method === "POST") {
    var body = '';
    // data受信イベントの発生時に断片データ(chunk)を取得
    // body 変数に連結
    req.on('data', function(chunk) {
        body += chunk;
    });
    // 受信完了(end)イベント発生時
    req.on('end', function() {
      let page;
      const key2 = qs.parse(body).key2;
      switch(key2){
        case "material_memo_reg":
          //let page = "";//fs.readFileSync(__dirname + '/udbook/tmp_reg.html');
          const memo_str = qs.parse(body).memo_str;
          const memo_inhtml = qs.parse(body).data;
          const rep_src = qs.parse(body).rep_src;
          if(qs.parse(body).side == "L"){
            page = fs.readFileSync(__dirname + '/udbook/tmp_reg_L.html');
            fs.writeFile(__dirname + global.fh_path_L + "/memo.txt", memo_str, (err) => {
              if (err) throw err;
              console.log("正常に書き込みが完了しました");
            });
            let text = fs.readFileSync(__dirname + global.fh_path_L + "/index.html", 'utf-8');
            //const rep_src = '/<div id="memo_div">.+</div>/g';
            //text = text.replace(rep_src, '<div id="memo_div">' + memo_inhtml + '</div>');
            text = text.replace(/<div id="memo_div">.*?div>\n/, '<div id="memo_div">' + memo_inhtml + '</div>\n');
            fs.writeFile(__dirname + global.fh_path_L + "/index.html", text, (err) => {
              if (err) throw err;
              console.log("正常に書き込みが完了しました");
            });
          }else if(qs.parse(body).side == "R"){
            page = fs.readFileSync(__dirname + '/udbook/tmp_reg_R.html');
            fs.writeFile(__dirname + global.fh_path_R + "/memo.txt", memo_str, (err) => {
              if (err) throw err;
              console.log("正常に書き込みが完了しました");
            });
            let text = fs.readFileSync(__dirname + global.fh_path_R + "/index.html", 'utf-8');
            //const rep_src = '/<div id="memo_div">.+</div>/g';
            //text = text.replace(rep_src, '<div id="memo_div">' + memo_inhtml + '</div>');
            text = text.replace(/<div id="memo_div">.*?div>\n/, '<div id="memo_div">' + memo_inhtml + '</div>\n');
            fs.writeFile(__dirname + global.fh_path_R + "/index.html", text, (err) => {
              if (err) throw err;
              console.log("正常に書き込みが完了しました");
            });
          }
          break;
        case "material_paint_reg":
          const img = qs.parse(body).data;
          let  data = img.split(',')[1];//   .replace(/^data:image\/\w+;base64,/, "");
          let buf = new Buffer.from(data, 'base64');
          if(qs.parse(body).side == "L"){
            page = fs.readFileSync(__dirname + '/udbook/tmp_reg_L.html');
            fs.writeFile(__dirname + global.fh_path_L + "/image.png", buf, (err) => {
              if (err) throw err;
              console.log("正常に書き込みが完了しました");
            });
          }else if(qs.parse(body).side == "R"){
            page = fs.readFileSync(__dirname + '/udbook/tmp_reg_R.html');
            fs.writeFile(__dirname + global.fh_path_R + "/image.png", buf, (err) => {
              if (err) throw err;
              console.log("正常に書き込みが完了しました");
            });
          }
          /*
          page = fs.readFileSync(__dirname + '/udbook/tmp_reg.html');
          fs.writeFile(__dirname + global.fh_path + "/image.png", buf, (err) => {
            if (err) throw err;
            console.log("正常に書き込みが完了しました");
          });
          */
          break;
        case "config":
          const config_data = qs.parse(body).key;
          page = "保存しました。";
          fs.writeFile(__dirname +  "/config.txt", config_data, (err) => {
            if (err) throw err;
            console.log("正常に書き込みが完了しました");
          });
          break;
        case "reg_pageNo":
          const page_data = qs.parse(body).key;
          page = "保存しました。";
          fs.writeFile(__dirname + "/materials/" + global.material +  "/read_last_page.txt", page_data, (err) => {
            if (err) throw err;
            console.log("正常に書き込みが完了しました");
          });
          break
        case "update_icon_order":
          const order_data = qs.parse(body).key;
          fs.writeFileSync(__dirname + "/materials.txt", order_data);
          page = "順序を変えました。";
          break;
      }
      res.writeHead(200, {'Content-Type': 'text/html'});
      res.end(page);
    });
  }
})
//requestファイルのresponse
function eri(req,res,page){
  if (fs.existsSync(page)) {
    fs.readFile(page, (err, data) => {
      if (!err) {
        res.writeHead(200, {'Content-Type': getType(page)});
        res.end(data);
      } else {
        res.statusCode = 500;
        res.end();
      }
    });
  } else {
    res.statusCode = 404;
    res.end();
  }
}
//リンクファイルのresponse
function tani(req,res){
  let url;
  if(req.url == "/udbook/canvas_event.js"){
    url = __dirname + "/udbook/canvas_event.js";
  }else if(req.url == "/udbook/jquery-3.6.0.js"){
    url = __dirname + "/udbook/jquery-3.6.0.js";
  }else if(req.url == "/udbook/jquery-ui.js"){
    url = __dirname + "/udbook/jquery-ui.js";
  }else if(req.url == "/udbook/page.css"){
    url = __dirname + "/udbook/page.css";
  }else if(req.url == "/udbook/page.js"){
    url = __dirname + "/udbook/page.js";
  }else{
    if(req.url.endsWith('/sdata.txt')){
      //let path = global.fh_path.substring(0,global.fh_path.lastIndexOf('/'));
      url = __dirname + req.url;
      //console.log("z=" + decodeURI(url));
    }else if(req.url.endsWith('/page_order.txt')){//-----------
      url = __dirname + req.url;
    }else if(req.url.endsWith('/page_numDirected_order.txt')){
      url = __dirname + decodeURI(req.url);
      if (!fs.existsSync(url)) {
        res.end("none");
      }
    }else if(req.url.endsWith('/config.txt')){
      url = __dirname + req.url;
    }else if(req.url.endsWith('/ud_materials.txt')){
      url = __dirname + req.url;
    }else if(req.url.endsWith('/read_last_page.txt')){
      url = __dirname + req.url;
    }else if(req.url.endsWith('/delete_material')){
      const mtnm = decodeURI(req.url).split('/').slice(-2)[0];
      // parser関数を使ってユーザーエージェントを解析
      res.end(delete_material(mtnm));
    }else if(req.url.startsWith('/icon')){
      url = __dirname + "/udbook" + req.url;
    }else if(req.url.startsWith('/fingerspell')){
      url = __dirname + "/udbook" + req.url;
    }else if(req.url.endsWith('.jpegx')){
      const jf = decodeURI(req.url);
      url = __dirname + jf.replace(".jpegx",".jpeg");
      if (!fs.existsSync(url)) {
        url = __dirname + "/udbook/stocks/stocks_img/" + ((jf.split("/")).slice(-1)[0]).replace(".jpegx",".jpeg");
      }
    }else if(req.url.startsWith('/down_load')){
      res.end(import_material());
      return;
    }else{
      url = __dirname + global.fh_path + (req.url.endsWith('/') ? req.url + 'index.html' : req.url);
    }
  }
  //console.log("req:" + req.url);
  url = decodeURI(url);
  console.log("tani:" + url);
  if(req.url.startsWith('/stocks_img')) return;
  //console.log(url);
  if (fs.existsSync(url)) {
    fs.readFile(url, (err, data) => {
      if (!err) {
        res.writeHead(200, {'Content-Type': getType(url)});
        if (url == __dirname + "/udbook/stocks/stocks.html"){
          const fsrt = fs.readFileSync(__dirname + "/materials.txt");
          let f = data + "";
          f= f.replace("ud________ud",fsrt)  
          res.end(f);
        }else{
          res.end(data);
        }
      } else {
        res.statusCode = 500;
        res.end();
      }
    });
  } else {
    console.log("ファイルがありません!");
    res.statusCode = 404;
    res.end();
  }
}
//***************************************************************************************
/*
var server = http.createServer((req, res) => {
  const decode_req_url = decodeURI(req.url);
  console.log(vurl.parse(decode_req_url,true).query);
  let query_array;
  if (req.method === "GET") {
    query_array = vurl.parse(decode_req_url,true).query;
    switch(query_array.key){
      case "material":
        console.log("1-" + decode_req_url)

        var page_url;
        if(decode_req_url.startsWith('/3page')){
          page_url = __dirname + '/materials/' + query_array.material + "/3page/" + '3page.jpeg';
        }else{
          page_url = __dirname + '/materials/' + query_array.material + "/3page/" + 'index.html';
        }
        console.log(page_url);
        if (fs.existsSync(page_url)) {
          fs.readFile(page_url, (err, data) => {
            if (!err) {
              res.writeHead(200, {'Content-Type': getType(page_url)});
              res.end(data);
            } else {
              res.statusCode = 500;
              res.end();
            }
          });
        } else {
          res.statusCode = 404;
          res.end();
        }
        break;
    }
  } else if (req.method === "POST") {

  }
  console.log("2-" + decode_req_url)

  switch(vurl.parse(decode_req_url,true).pathname){
    case "/material":
      break;
    default:
      var url = __dirname + '/udbook' + (req.url.endsWith('/') ? req.url + 'index.html' : req.url);
      url = decodeURI(url);
      if(req.url.startsWith('/stocks_img')) return;
      if (fs.existsSync(url)) {
        fs.readFile(url, (err, data) => {
          if (!err) {
            res.writeHead(200, {'Content-Type': getType(url)});
            res.end(data);
          } else {
            res.statusCode = 500;
            res.end();
          }
        });
      } else {
        res.statusCode = 404;
        res.end();
      }
  }
});
*/
var port = 8080;
server.listen(port, () => {
  console.log(`Server listening on ${port}`);
});
