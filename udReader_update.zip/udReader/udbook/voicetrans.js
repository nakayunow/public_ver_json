//21-10-17
/* <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< [ 音声合成 ]>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.>>>>
    voice_trans_pause:一時停止
    voice_trans_restart:再開
    voice_trans_quit:終了
    voice_trans:開始
<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> */ 
const glb_synth = window.speechSynthesis;
const glb_uttr = new SpeechSynthesisUtterance();

//const _sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
let glb_span_elems = [];//phraseクラスまたはStrCtrlクラスの配列
let glb_span_hilight_elems = [];//ハイライトさせるspanエレメント
let glb_ct_for_hilight = 0;//ハイライトさせるspanエレメントの順番
let glb_span_reflow_elems = [];
let glb_span_reflow_hilight_elems = [];
let current_span_elem = "";
let pause = false;          //ポーズボタン〓をクリックした時 trueにする
let glb_cancel_flg = false; //ストップボタン■をクリックした時 trueにする
let reflow_flg;
let otowaku_flg = false;
let voice_highlight_color = "";
let voice_highlight_color_rf = "";
let chng_bg = [];
let pr_speech_elem = []; //音声発声枠クリック時に使用する
let phrase_ari_short_flg = false;
let glb_ct = 0; //文書カウンター
let pre_glb_ct = -1;

//page.jsからアクセス
function get_phrase_ari_short_flg(){
    return phrase_ari_short_flg;
}
//config.jsからアクセス
function set_phrase_ari_short_flg(val){
    phrase_ari_short_flg = val;
}
function get_otowaku_flg(){
    return otowaku_flg;
}
//config設定の文書を読む
let voice_t = function(){
    //最初の文節からスタートする
    phrase_ari_start_flg = true;
    if(phrase_umu == "ari"){
        pre_voice_trans(4,'setting_text');
    }else if(phrase_umu == "ari_short"){
        //start_phrase_elem = document.getElementById("div_dammy").getElementsByClassName("phrase")[0];
        pre_voice_trans(5,'div_dammy');
    }else{
        pre_voice_trans(5,'setting_text');
    }
}
//音声ボタンクリック時に起動
/* ***********************************************************
    指定ページ側のspeech_orderに格納されたStrCtrlのid順に読み上げる
    div_id:クリックしたStrCtrlのid
    direct:クリックした側のpage_frame
    vflg:true=reflowから false=pageから呼び出し
*********************************************************** */
let start_phrase_elem; //分節区切り短の場合にスタートphraseを格納する。
function get_phrase_elems(div_id,direct,vflg,direct_phrase_elem = null){
    start_phrase_elem = direct_phrase_elem;
    phrase_ari_start_flg = false; //どのphraseエレメントから読みをスタートさせるかを決めるflgを初期化する。
    let speech_order_array = [];//speech_orderを配列として格納
    let speech_reflow_order_array = [];
    //let idx = 0;
    let ret_array = [];
    let ret_array2 = [];
    let flg = false;
    //引数div_idがnullの場合はspeech_orderの最初のStrCtrlからspeech開始する
    if(div_id == null) flg = true;
    //reflow_flg = false;
    if(document.getElementById(direct).contentDocument.getElementById("speech_order") == null || document.getElementById(direct).contentDocument.getElementById("speech_order") == "") return;
    //speech_orderのStrCtrlのidを配列で格納
    let StrCtrl_ids = document.getElementById(direct).contentDocument.getElementById("speech_order").innerHTML.split(':');
    //const divFrame_id = (direct.indexOf("left") != -1) ? "divFrame_right" : "divFrame_left";
    reflow_flg = get_reflow_mode();//vflg;
    let telems;
    if(get_reflow_frame_side() == "L"){
        telems = document.getElementById("divFrame_left").getElementsByClassName("StrCtrl");
    }else if(get_reflow_frame_side() == "R"){
        telems = document.getElementById("divFrame_right").getElementsByClassName("StrCtrl");;
    }
    for(i=0;i<StrCtrl_ids.length - 1;i++){
        //指定のStrCtrlのidがspeech_order中のidと一致した場合、flgをtrueにする
        if(div_id == StrCtrl_ids[i]){
            flg = true;
        }
        if(flg){
            if(reflow_flg){
                for(t1=0;t1<telems.length;t1++){
                    if(telems[t1].id == StrCtrl_ids[i].replace("div","exdiv")){
                        speech_reflow_order_array.push(telems[t1]);
                        break;
                    }
                }
            }
            if(document.getElementById(direct).contentDocument.getElementById(StrCtrl_ids[i]) != null){
                speech_order_array.push(document.getElementById(direct).contentDocument.getElementById(StrCtrl_ids[i]));
            }
        } 
    }
    for(k=0;k<speech_order_array.length;k++){
        if(speech_order_array[k] == null) continue;
        let phrase_elems = speech_order_array[k].getElementsByClassName("phrase");
        for(m=0;m<phrase_elems.length;m++){
            const st2 = phrase_elems[m].textContent.replace(/\r?\n/g,"").replace(/\s+/g, "");
            if(st2 !="" )ret_array.push(phrase_elems[m]);//  [idx] = phrase_elems[m];
        }
        if(reflow_flg){
            let phrase_elems2 = speech_reflow_order_array[k].getElementsByClassName("phrase");
            for(n=0;n<phrase_elems2.length;n++){
                const stt2 = phrase_elems2[n].textContent.replace(/\r?\n/g,"").replace(/\s+/g, "");
                if(stt2 != "")ret_array2.push(phrase_elems2[n]);//  [idx2] = phrase_elems2[n];
            }       
        }
    }
    glb_span_reflow_elems = ret_array2;
    //if(start_phrase_elem == null) start_phrase_elem = ret_array[0];
    return ret_array;
}
//**************************************????????????????????????????
/*
function get_phrase_elems2(div_id,direct,vflg,direct_phrase_elem){
    let speech_order_array = [];//speech_orderを配列として格納
    let speech_reflow_order_array = [];
    //let idx = 0;
    let ret_array = [];
    let ret_array2 = [];
    let flg = false;
    //引数div_idがnullの場合はspeech_orderの最初のStrCtrlからspeech開始する
    if(div_id == null) flg = true;
    //reflow_flg = false;
    if(document.getElementById(direct).contentDocument.getElementById("speech_order") == null || document.getElementById(direct).contentDocument.getElementById("speech_order") == "") return;
    //speech_orderのStrCtrlのidを配列で格納
    let StrCtrl_ids = document.getElementById(direct).contentDocument.getElementById("speech_order").innerHTML.split(':');
    
    //const divFrame_id = (direct.indexOf("left") != -1) ? "divFrame_right" : "divFrame_left";
    reflow_flg = get_reflow_mode();//vflg;
    let telems;
    if(get_reflow_frame_side() == "L"){
        telems = document.getElementById("divFrame_left").getElementsByClassName("StrCtrl");
    }else if(get_reflow_frame_side() == "R"){
        telems = document.getElementById("divFrame_right").getElementsByClassName("StrCtrl");
    }
    for(i=0;i<StrCtrl_ids.length - 1;i++){
        //指定のStrCtrlのidがspeech_order中のidと一致した場合、flgをtrueにする
        if(div_id == StrCtrl_ids[i]){
            flg = true;
        }
        if(flg){
            if(reflow_flg){
                for(t1=0;t1<telems.length;t1++){
                    if(telems[t1].id == StrCtrl_ids[i].replace("div","exdiv")){
                        speech_reflow_order_array.push(telems[t1]);
                        break;
                    }
                }
            }
            if(document.getElementById(direct).contentDocument.getElementById(StrCtrl_ids[i]) != null){
                speech_order_array.push(document.getElementById(direct).contentDocument.getElementById(StrCtrl_ids[i]));
            }
        } 
    }
    let sct_strctrl = null;
    let sct_phrase = null;
    for(let q=0;q<speech_order_array.length;q++){
        if(speech_order_array[q] == null) continue;
        let phrase_elems = speech_order_array[q].getElementsByClassName("phrase");
        for(m=0;m<phrase_elems.length;m++){
            if(phrase_elems[m] === direct_phrase_elem){
                sct_strctrl = q;
                sct_phrase = m;
                break;
            }
        }
        if(sct_strctrl == null && reflow_flg){
                let phrase_elems2 = speech_reflow_order_array[q].getElementsByClassName("phrase");
                for(n=0;n<phrase_elems2.length;n++){
                    if(phrase_elems2[n] == direct_phrase_elem){
                        sct_strctrl = q;
                        sct_phrase = m;
                        break;
                    }
                }       
        }
        if(sct_strctrl != null) break;
    }
    let temp_StrCtrl_div = document.createElement("div");
    temp_StrCtrl_div.classList.add("StrCtrl");

    for(k=sct_strctrl;k<speech_order_array.length;k++){
        if(speech_order_array[k] == null) continue;
        let phrase_elems = speech_order_array[k].getElementsByClassName("phrase");
        for(m=sct_phrase;m<phrase_elems.length;m++){
            const st2 = phrase_elems[m].textContent.replace(/\r?\n/g,"").replace(/\s+/g, "");
            //if(st2 !="" )ret_array.push(phrase_elems[m]);//  [idx] = phrase_elems[m];
            if(st2 !="" )temp_StrCtrl_div.appendChild(phrase_elems[m]);
        }
        if(reflow_flg){
            let phrase_elems2 = speech_reflow_order_array[k].getElementsByClassName("phrase");
            for(n=0;n<phrase_elems2.length;n++){
                const stt2 = phrase_elems2[n].textContent.replace(/\r?\n/g,"").replace(/\s+/g, "");
                if(stt2 != "")ret_array2.push(phrase_elems2[n]);//  [idx2] = phrase_elems2[n];
            }       
        }
    }
    glb_span_reflow_elems = ret_array2;
    ret_array.push(temp_StrCtrl_div);
    return ret_array;
}
*/
//分節区切り無し、または分節区切り短
function get_StrCtrl_elems(div_id,direct,vflg,direct_phrase_elem = null){
    start_phrase_elem = direct_phrase_elem;
    let speech_order_array = [];//speech_orderを配列として格納
    let speech_reflow_order_array = [];
    let flg = false;
    //引数div_idがnullの場合はspeech_orderの最初のStrCtrlからspeech開始する
    if(div_id == null) flg = true;
    //reflow_flg = false;
    if(document.getElementById(direct).contentDocument.getElementById("speech_order") == null || document.getElementById(direct).contentDocument.getElementById("speech_order") == "") return;
    //speech_orderのStrCtrlのidを配列で格納
    let StrCtrl_ids = document.getElementById(direct).contentDocument.getElementById("speech_order").innerHTML.split(':');
    //const divFrame_id = (direct.indexOf("left") != -1) ? "divFrame_right" : "divFrame_left";
    reflow_flg = get_reflow_mode();//vflg;
    let telems2;
    if(get_reflow_frame_side() == "L"){
        telems2 = document.getElementById("divFrame_left").getElementsByClassName("StrCtrl");
    }else if(get_reflow_frame_side() == "R"){
        telems2 = document.getElementById("divFrame_right").getElementsByClassName("StrCtrl");
    }
    for(i2=0;i2<StrCtrl_ids.length - 1;i2++){
        //指定のStrCtrlのidがspeech_order中のidと一致した場合、flgをtrueにする
        if(div_id == StrCtrl_ids[i2]){
            flg = true;
        }
        if(flg){
            if(reflow_flg){
                for(t2=0;t2<telems2.length;t2++){
                    if(telems2[t2].id == StrCtrl_ids[i2].replace("div","exdiv")){
                        speech_reflow_order_array.push(telems2[t2]);
                        break;
                    }
                }
            }
            if(document.getElementById(direct).contentDocument.getElementById(StrCtrl_ids[i2]) != null){
                speech_order_array.push(document.getElementById(direct).contentDocument.getElementById(StrCtrl_ids[i2]));
            }
            //idx += 1;
        } 
    }
    glb_span_reflow_elems = speech_reflow_order_array;
    //if(start_phrase_elem == null) start_phrase_elem = speech_order_array[0];
    return speech_order_array;
}
//音声発声枠クリック時に起動。elm_id:音声枠idvのid
function get_speech_element(elm_id,direct){
    otowaku_flg = true;
    let ret_array = [];
    //div_7-div_1$div_3:
    let SpeechElem_ids = document.getElementById(direct).contentDocument.getElementById("speech_element").innerHTML.split(':');
    //連想配列作成
    let speech_element_array = {};
    let target_elem = [];
    for(i=0;i<SpeechElem_ids.length - 1;i++){
        let val = SpeechElem_ids[i].split("-");
        speech_element_array[val[0]] = val[1]; //[音声発声枠div-id:音声変換対象文字内包div-id$...]
    }
    //音声発声枠クリック時にdivのidに対応した音声変換対象文字内包divエレメントを所得する
    let d_array = speech_element_array[elm_id].split("$");
    
    for(j=0;j<d_array.length;j++){
        target_elem[j] =  document.getElementById(direct).contentDocument.getElementById(d_array[j]);
        if(target_elem[j].classList.contains("PrSpeechElem")){
            if(!target_elem[j].classList.contains("StrCtrl_v")){
                target_elem[j].style.height = "";
            }
            pr_speech_elem.push(target_elem[j]);
            target_elem[j].style.border = "";
            target_elem[j].style.display = "";
            target_elem[j].style.zIndex = "10000";
        }
        
        const phrase_elems = target_elem[j].getElementsByClassName("phrase");
        let temp_array = [];
        for(m=0;m<phrase_elems.length;m++){
            temp_array[m] = phrase_elems[m];
        }
        ret_array = ret_array.concat(temp_array);
    }
    return ret_array;
}
function reset_pr_speech_elem(){
    for(j=0;j<pr_speech_elem.length;j++){
        pr_speech_elem[j].style.display = "none";
    }
    pr_speech_elem = [];
}
function set_phrase_elems(id){
    let ret_array = [];
    let elem = document.getElementById(id);
    let phrase_elems = elem.getElementsByClassName("phrase");
    for(m=0;m<phrase_elems.length;m++){
        ret_array[m] = phrase_elems[m];
    }
    return ret_array;
}
function set_StrCtrl_elems(id){
    let ret_array = [];
    let elem = document.getElementById(id);
    ret_array[0] = elem;
    return ret_array;
}
function getElemIdx(targetElem,ElemnArray){
    for(i=0;i<ElemnArray.length;i++){
        if(ElemnArray[i] === targetElem) return i;
    }
    return -1;
}
//*************** HTML編集後に初期化が必要 ***************
let glb_flg = false;
//---------- 初期化関数 -----------
let init_glbVar_html = function () {
    glb_flg = false;
}
//************* 音声再生終了時に初期化が必要 ***************
//page.jsからアクセス
function getPauseFlg(){
    return (pause)?true:false;
}
function voice_trans_pause(){
    if(glb_span_elems === undefined) return;
    pause = true;
    glb_cancel_flg = true;
    if(phrase_ari_short_flg && !otowaku_flg){
        glb_synth.pause();
        //current_span_elem = glb_span_elems[glb_ct - 1];
    }else{
        current_span_elem = glb_span_elems[glb_ct];
    }
    //remove_nodes();
}
function voice_trans_restart(){
    glb_synth.resume();
    glb_cancel_flg = false;
    pause = false;
}
function voice_trans_quit(flg = true){
    if(glb_span_elems == null) return;
    glb_cancel_flg = true;
    pause = false;
    //ipad対応
    if(touch_flg){
        glb_uttr.text = "";
        glb_synth.speak(glb_uttr);
    }
    //safari対応
    if(agent.indexOf("safari") != -1 && agent.indexOf("chrome") == -1){
        glb_uttr.text = "";
        glb_synth.speak(glb_uttr);
    }
    glb_synth.cancel();
    //選択解除
    for(i=0;i<glb_span_elems.length;i++){
        if(phrase_ari_short_flg && !otowaku_flg){
            const t_elem = glb_span_elems[i].getElementsByClassName("phrase");
            let t_elem_reflow;
            if(reflow_flg){
                t_elem_reflow = glb_span_reflow_elems[i].getElementsByClassName("phrase");
                for(j=0;j<t_elem.length;j++){
                    t_elem[j].style.backgroundColor = "";
                    t_elem_reflow[j].style.backgroundColor = "";
                }
            }else{
                for(j=0;j<t_elem.length;j++){
                    t_elem[j].style.backgroundColor = "";
                }
            }
        }else{
            glb_span_elems[i].style.backgroundColor = "";
            if(reflow_flg) glb_span_reflow_elems[i].style.backgroundColor = '';
        }
    }
    reset_pr_speech_elem();
    set_page_speaking_flg(false);
    glb_ct = 0;
    pre_glb_ct = -1;
    glb_ct_for_hilight = 0;
    otowaku_flg = false;
    //auto_speech()終了
    set_execution_quit(flg);
}
//******************* 使える声の配列を取得 *******************
const voiceSelect = document.querySelector('#voice-select')
function appendVoices() {
    // 配列の中身は SpeechSynthesisVoice オブジェクト
    const voices = glb_synth.getVoices()
    voiceSelect.innerHTML = ''
    voices.forEach(voice => { // アロー関数 (ES6)
        // 日本語と英語以外の声は選択肢に追加しない。
        //if(!voice.lang.match('ja|en-US')) return
        if(!voice.lang.match('ja')) return
        const option = document.createElement('option')
        option.value = voice.name
        option.text  = `${voice.name} (${voice.lang})`
        option.setAttribute('selected', voice.default)
        voiceSelect.appendChild(option)
    });
}
//******** onload時に実行し使える声をselecterに格納する *******
appendVoices()

// 使える声が追加されたときに着火するイベントハンドラ。
// Chrome は非同期に(一個ずつ)声を読み込むため必要。    
glb_synth.onvoiceschanged = e => {
    appendVoices()
}

//glb_uttr.voice = speechSynthesis.getVoices().filter(voice => voice.name === voiceSelect.value)[0] 
glb_uttr.lang = "ja-JP"
function set_voice_speech_rate(val){
    glb_uttr.rate = val;//document.getElementById("voice_trans_speed_ate").value;
}
function set_voice_speech_pitch(val){
    glb_uttr.pitch = val;//document.getElementById("voice_trans_pitch_ate").value;
}
function set_voice_speech_volume(val){
    glb_uttr.volume = val;//document.getElementById("voice_trans_pitch_ate").value;
}
function set_voice(){
    if(voiceSelect.value == "") return;
    glb_uttr.voice = speechSynthesis.getVoices().filter(voice => voice.name === voiceSelect.value)[0];
    glb_uttr.lang = glb_uttr.voice.lang;
}
function set_voice_highlight_color(val){
    voice_highlight_color = val;
}
function set_voice_highlight_color_rf(val){
    voice_highlight_color_rf = val;
}
function hilight(){
    /******************************************************
     StrCtrlに前景・背景色が設定されている場合に備える
     glb_span_elemsが<span class="phrase"の場合fore-colorのみ
     親のfore-colorをコントロールする
    *****************************************************/
    if(glb_cancel_flg) return;
    /*
    glb_span_elemsがphraseエレメントで構成されている場合、
    (音節区切り短で無い場合。又は(音節区切り短だが)音枠の場合)
    glb_span_elemsをglb_span_hilight_elemsに代入する。
    glb_span_elemsがdivエレメント(StrCtrl)で構成されている場合、
    (音節区切り短の場合)
    voice_trans_rcsの実行時にglb_span_hilight_elemsにphraseが代入される。
    */
    if(!phrase_ari_short_flg || otowaku_flg){
        glb_span_hilight_elems = glb_span_elems;
        glb_span_reflow_hilight_elems = glb_span_reflow_elems;
        glb_ct_for_hilight = glb_ct;
    }
    let fr_color = glb_span_hilight_elems[glb_ct_for_hilight].parentNode.style.color;
    if(fr_color != ""){
        const rc_array = fr_color.replace("rgb(", "").replace(")", "").split(",");
        //前景色が白に近い場合、黒に変換する
        if(rc_array[0]>230 && rc_array[1]>230 && rc_array[2]>230){
            chng_bg.push(glb_ct_for_hilight);
            chng_bg.push(fr_color);
            glb_span_hilight_elems[glb_ct_for_hilight].style.color = "rgb(0,0,0)";
        }
    }
    glb_span_hilight_elems[glb_ct_for_hilight].style.backgroundColor = voice_highlight_color;
    if(reflow_flg) glb_span_reflow_hilight_elems[glb_ct_for_hilight].style.backgroundColor = voice_highlight_color_rf;
    if(pre_glb_ct != -1){
        if(phrase_ari_short_flg && glb_ct_for_hilight == 0){
            ; //何もしない
        }else{
            glb_span_hilight_elems[pre_glb_ct].style.backgroundColor = "";
            if(reflow_flg) glb_span_reflow_hilight_elems[pre_glb_ct].style.backgroundColor = '';
        }
    }
    pre_glb_ct = glb_ct_for_hilight;
}
//arg 音声変換する文字列の配列
let voice_str = "";
function play_voice(arg) {
    /******************************************************
     StrCtrlに前景・背景色が設定されている場合に備える
     glb_span_elemsが<span class="phrase"の場合fore-colorのみ
     親のfore-colorをコントロールする
     *****************************************************/
    hilight();
    const delimita = "(";
    for(i=0;i<arg.length;i++){
        if(get_phrase_umu() == "nasi"){
            voice_str += arg[i];
        }else{
            voice_str += arg[i] + delimita;
        }
    }
    voice_str = voice_str.substring(0,voice_str.length - 1);
    speak_exe(voice_str);
    
}
let speak_exe = function(arg){
    glb_uttr.text = arg;
    glb_synth.speak(glb_uttr);
}
glb_uttr.onboundary = function(e){
    let sct = "";
    //文節区切り短の場合
    if(phrase_ari_short_flg){
        if(e.charIndex == 0){
            hilight("StrCtrl");
            glb_ct_for_hilight += 1;
        }
        //ipadでは、e.charLengthがundefinedになる。またsubstringに対応していない。
        //sct = voice_str.substring(e.charIndex-1,e.charIndex-1 + e.charLength);
        sct = voice_str.slice(e.charIndex-1,e.charIndex-1 + 1);
        const cct = ( sct.match( new RegExp( "\\(", "g" ) ) || [] ).length ;
        if(cct != 0){
            hilight("StrCtrl");
            glb_ct_for_hilight += 1;//cct;
        }
    }
}
glb_uttr.onend = function(e) {
    /*****************************************************
    pauseでonendが発火する。
    文節読み間隔短でpauseが実行された場合、onend処理を無効にする
    *****************************************************/
    if(pause && phrase_ari_short_flg) return;
    voice_str = "";
    //文節読み間隔短の場合。
    if(phrase_ari_short_flg){
        if(glb_ct_for_hilight != 0){
            glb_span_hilight_elems[glb_ct_for_hilight-1].style.backgroundColor = "";
            if(reflow_flg) glb_span_reflow_hilight_elems[glb_ct_for_hilight-1].style.backgroundColor = "";
        }
        glb_ct_for_hilight = 0;
        pre_glb_ct = -1;
        //otowaku_flg = false;
    }
    if(chng_bg.length !=0){
        glb_span_hilight_elems[chng_bg[0]].style.color = chng_bg[1];
        chng_bg = [];
    }
    if(!glb_cancel_flg && !glb_synth.pending ) {
        voice_trans(glb_ct);
    }
}
//speech_orderに沿って読み上げの最中の場合のみ、auto_speechを有効にするための判別flg
let current_sort;
let exe_auto_speech_flg = function(){
    if(current_sort == 0 || current_sort == 1 || current_sort == 6 || current_sort == 7){
        return true;
    }else{
        return false;
    }
}
//*************** メインメニューで▶︎がクリックされて駆動 ******************
function pre_voice_trans(sort,vElem,reflow_flg,velm = null) {
    //alert(vElem);
    //alert(reflow_flg);
    current_sort = sort;
    if(pause){
        glb_cancel_flg = false;
        pause = false;
        //選択解除        
        for(i=0;i<glb_span_elems.length;i++){
            glb_span_elems[i].style.backgroundColor = "";
            if(reflow_flg) glb_span_reflow_elems[i].style.backgroundColor = '';
        }
        var index = getElemIdx(current_span_elem,glb_span_elems); 
        glb_ct = index;
        voice_trans(index); 
        return;
    }else{
        glb_cancel_flg = false;
        if(!glb_flg){
            if(sort == 0){
            //指定ページ側のspeech_orderに格納されたStrCtrlのid順に読み上げる
                glb_span_elems = get_phrase_elems(vElem,'pageFrame_left',reflow_flg,velm);//document.getElementsByClassName("phrase");
            }else if(sort == 1){
            //指定ページ側のspeech_orderに格納されたStrCtrlのid順に読み上げる
                glb_span_elems = get_phrase_elems(vElem,'pageFrame_right',reflow_flg,velm);//document.getElementsByClassName("phrase");  
            }else if(sort == 2){
            //指定ページ側のspeech_element(音枠)に格納されたStrCtrlのid順に読み上げる
                glb_span_elems = get_speech_element(vElem,'pageFrame_left');//document.getElementsByClassName("phrase");
            }else if(sort == 3){
            //指定ページ側のspeech_element(音枠)に格納されたStrCtrlのid順に読み上げる
                glb_span_elems = get_speech_element(vElem,'pageFrame_right');//document.getElementsByClassName("phrase");
            //vElem(div_id)のinnerTextを読み上げる
            }else if(sort == 4){
                glb_span_elems = set_phrase_elems(vElem);
            //プレビューを読み上げる
            }else if(sort == 5){
                glb_span_elems = set_StrCtrl_elems(vElem);
            //分節区切り無し
            }else if(sort == 6){
                glb_span_elems = get_StrCtrl_elems(vElem,'pageFrame_left',reflow_flg,velm);//document.getElementsByClassName("phrase");
                k_flg = false;
            }else if(sort == 7){
                glb_span_elems = get_StrCtrl_elems(vElem,'pageFrame_right',reflow_flg,velm);//document.getElementsByClassName("phrase");
                k_flg = false;
            }
            /*
            else if(sort == 8){
                glb_span_elems = get_phrase_elems2(vElem,'pageFrame_left',reflow_flg,velm);//document.getElementsByClassName("phrase");
            }else if(sort == 9){
                glb_span_elems = get_phrase_elems2(vElem,'pageFrame_right',reflow_flg,velm);//document.getElementsByClassName("phrase");
            }
            */
            //glb_flg = true; ********************** 本稼働時にはコメントアウトを外す
        }
    }
    //スピーチ開始行の選択がある場合、該当する<span>エレメントを取得する
    if (window.getSelection()!="") {
        let vrg = window.getSelection().getRangeAt(0).getBoundingClientRect();
        let vrg_top = vrg.top;
        let vrg_left = vrg.left;
        let target_spnan_elem;//取得した<span>エレメントを格納
        flg = false;
        for(i=1;i<glb_span_elems.length;i++){
            if(vrg_top >= glb_span_elems[i].getBoundingClientRect().top -20 && vrg_top <= glb_span_elems[i].getBoundingClientRect().top + 10 ){
                if(vrg_left <= glb_span_elems[i].getBoundingClientRect().left){
                    target_spnan_elem = glb_span_elems[i];
                    flg = true;
                    break;
                }
            }
        }
        if(!flg){
            alert("選択範囲を選び直して下さい。");
            window.getSelection().removeAllRanges();
            return;
        }
        window.getSelection().removeAllRanges();
        var index = getElemIdx(target_spnan_elem,glb_span_elems);   //glb_span_elems.indexOf(target_spnan_elem);
        glb_ct = index - 1;
        voice_trans(glb_ct); 
    }else{
        voice_trans(0);
    }
}
//************************ 音声変換開始 ************************
//開始行の指定がない場合は、i=0からスタート
let phrase_ari_start_flg = false;
function voice_trans(i){
    var vs;
    if(glb_span_elems === undefined) return;
    const ct = glb_span_elems.length;
    //音声変換終了処理
    if(i>=ct){
        glb_cancel_flg = true;
        let elm = glb_span_elems;//get_phrase_elems();//document.getElementsByClassName("phrase");
        let elm2 = glb_span_reflow_elems;
        for(i=0;i<elm.length;i++){
            elm[i].style.backgroundColor="";
            if(reflow_flg) elm2[i].style.backgroundColor="";
        }
        glb_ct = 0;
        pre_glb_ct = -1;
        glb_ct_for_hilight = 0;
        otowaku_flg = false;
        reset_pr_speech_elem();
        set_page_speaking_flg(false);
        reset_vspeech_flg(false);
        //remove_nodes();
        if(exe_auto_speech_flg()) auto_speech();
        return;
    }
    let vss;
    if(glb_span_elems[i] == null) return;
    if(glb_span_elems[i].classList.contains("StrCtrl")){
        //sort = "StrCtrl";
        glb_span_hilight_elems = [];
        glb_span_reflow_hilight_elems = [];
        let tmp_reflow_elems;
        if(reflow_flg){
            tmp_reflow_elems =  glb_span_reflow_elems[i].getElementsByClassName("phrase");
        }
        vss = voice_trans_rcs(glb_span_elems[i].getElementsByClassName("phrase"),true,tmp_reflow_elems);
    }else{
        //sort = "phrase";
        if(get_phrase_umu() == "ari" && current_sort !=2 && current_sort != 3){
                if(start_phrase_elem == null){
                    phrase_ari_start_flg = true;
                }else{
                    if(glb_span_elems[i] === start_phrase_elem) phrase_ari_start_flg = true;
                }
                if(phrase_ari_start_flg){
                    vss = voice_trans_rcs(glb_span_elems[i].childNodes);
                }else{
                    vss = [];
                }
        }else{
            vss = voice_trans_rcs(glb_span_elems[i].childNodes);
        }
    }
    //vsにテキストが含まれる場合
    vs = vss.join("");
    if (vs != ""){
        play_voice(vss);
        glb_ct +=  1;
    }else{
        glb_ct +=  1;
        if(glb_ct>=ct){
            glb_cancel_flg = true;
            let elm = glb_span_elems;//get_phrase_elems();//document.getElementsByClassName("phrase");
            let elm2 = glb_span_reflow_elems;
            for(i=0;i<elm.length;i++){
                //if(elm[i].style.backgroundColor == voice_highlight_color)
                elm[i].style.backgroundColor="";
                if(reflow_flg)elm2[i].style.backgroundColor="";
            }
            glb_ct = 0;
            pre_glb_ct = -1;
            glb_ct_for_hilight = 0;
            otowaku_flg = false;
            reset_pr_speech_elem();
            set_page_speaking_flg(false);
            reset_vspeech_flg(false);
            //remove_nodes();
            if(exe_auto_speech_flg()) auto_speech();
        }else{
            voice_trans(glb_ct);
        }
    }
}
/*
function get_vs(i){
    var vs;
    const ct = glb_span_elems.length;
    //改行・スペースの削除-----------------------------------
    if(i>=ct){
        glb_cancel_flg = true;
        let elm = glb_span_elems;//get_phrase_elems();//document.getElementsByClassName("phrase");
        let elm2 = glb_span_reflow_elems;
        for(i=0;i<elm.length;i++){
            //if(elm[i].style.backgroundColor == voice_highlight_color)
            elm[i].style.backgroundColor="";
            if(reflow_flg) elm2[i].style.backgroundColor="";
        }
        glb_ct = 0;
        pre_glb_ct = -1;
        return;
    }
    vs = voice_trans_rcs(glb_span_elems[i].childNodes);
    vs = vs.replace(/\r?\n/g,"");
    vs = vs.replace(/\s+/g, "");
    if(vs == 'undefined'){
        vs = "";
    }
    //vsにテキストが含まれる場合
    if (vs != ""){
        glb_ct +=  1;
        return vs;
    }else{
        get_vs(glb_ct);
    }

}
*/
function furigana_rt(rt_elem,arg){
    let rt;
    if(rt_elem.classList.contains("hira")){
        rt = arg.replace(/[\u30a1-\u30f6]/g, function(match) {
            var chr = match.charCodeAt(0) - 0x60;
            return String.fromCharCode(chr);
        });    
    }else if(rt_elem.classList.contains("kata")){
        rt = arg.replace(/[\u3041-\u3096]/g, function(match) {
            var chr = match.charCodeAt(0) + 0x60;
        return String.fromCharCode(chr);
        });     
    }else{
        rt = arg;
    }
    return rt;
}   
//ElementsからTextNodeのみの取得。再帰関数 vctは開始エレメントのインデックス
/*************************************************
flg:true-velementsがphraseクラスエレメントの場合。
    false-velementsがphraseクラスエレメントの子ノード場合。
*************************************************/
let k_flg = false;
function voice_trans_rcs(velements,flg = false,velements_reflow = []){
    let voice_str_rcs_array = [];
    if(flg){
        for(let k=0;k<velements.length;k++){
            //文節区切り短の場合
            if(phrase_ari_short_flg){
                if(start_phrase_elem == null){
                    k_flg = true;
                }else{
                    if(velements[k] === start_phrase_elem) k_flg = true;
                }
                if(k_flg){
                    const rt_srt = voice_trans_rcs_sub(velements[k].childNodes);
                    if(rt_srt == "") continue;
                    voice_str_rcs_array.push(rt_srt);                
                    glb_span_hilight_elems.push(velements[k]);
                    glb_span_reflow_hilight_elems.push(velements_reflow[k]);
                }
            }else{
                const rt_srt = voice_trans_rcs_sub(velements[k].childNodes);
                if(rt_srt == "") continue;
                voice_str_rcs_array.push(rt_srt);
            }
            /*
            const rt_srt = voice_trans_rcs_sub(velements[k].childNodes);
            if(rt_srt == "") continue;
            voice_str_rcs_array.push(rt_srt);
            //文節区切り短の場合
            if(phrase_ari_short_flg){
                glb_span_hilight_elems.push(velements[k]);
                glb_span_reflow_hilight_elems.push(velements_reflow[k]);
            }
            */
        }
    }else{
        voice_str_rcs_array.push(voice_trans_rcs_sub(velements));
    }
    function voice_trans_rcs_sub(elements){
        const cct = elements.length;
        let voice_str_rcs = "";
        for(let j = 0; j < cct ; j++){
            //取得したノードがテキストノードの場合
            if(elements.item(j).nodeType == 3){
                voice_str_rcs += elements.item(j).textContent;
            //エレメントノードの場合
            }else if(elements.item(j).nodeType == 1){
                //rubyタグの場合は子ノードのrtのtextContentを取得
                if(elements.item(j).tagName == "RUBY"){
                    const txt = elements.item(j).children[0].textContent;
                    voice_str_rcs += furigana_rt(elements.item(j).children[0],txt);
                }else{
                    voice_str_rcs += voice_trans_rcs(elements.item(j).childNodes)
                }                
            }
        }
        //改行・スペース等を削除
        voice_str_rcs = voice_str_rcs.replace(/\r?\n/g,"").replace(/\s+/g, "").replace("(","").replace("〜","");
        if(voice_str_rcs == 'undefined'){
            voice_str_rcs = "";
        }
        return voice_str_rcs;
    }
    return voice_str_rcs_array;
}
