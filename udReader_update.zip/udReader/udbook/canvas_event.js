// コンテキストを取得---グラフィックを描画するためのメソッドやプロパティをもつオブジェクトを返す
//子ページに読み込みれる
const canvas = window.document.getElementById("my_canvas");
const ctx = canvas.getContext('2d');
//const margin_left = window.parent.get_margin_left();
//const margin_top = window.parent.get_margin_top();
const target_rect = canvas.getBoundingClientRect();
//タッチ画面? yes:true, no:false
const isTouchValid = window.parent.isTouchValid();//  ('ontouchstart' in window);

// 現在の描画状態を保存する
ctx.save();

ctx.lineCap = 'butt';
var flag_eraser = true;
$(() => {
    let preX = 0; // 1つ前のX座標
    let preY = 0; // 1つ前のY座標
    let trans_resio = 0;//1/get_trans_resio();
    //shiftモード
    let preX2 = 0; // 1つ前のX座標
    let preY2 = 0; // 1つ前のY座標
    let shift_mode_flg = false;
    drawFlag = false;   // 線を描画中か
    $('#my_canvas').bind({'touchstart mousedown': function(e) { 
        //e.preventDefault();
        //modeがpaint以外は稼働させない
        if(current_mode != "paint") return;
        if(trans_resio == 0) trans_resio = 1/get_trans_resio();
        //const target_rect = e.currentTarget.getBoundingClientRect();
        var downX = (isTouchValid ? e.touches[0].pageX : e.clientX) - target_rect.left;// - margin_left;
        var downY = (isTouchValid ? e.touches[0].pageY : e.clientY) - target_rect.top;// - margin_top;
        if (e.touches == undefined){ 
            downX = e.clientX - target_rect.left;
            downY = e.clientY - target_rect.top;
        }else{
            downX = e.touches[0].pageX - target_rect.left;
            downY = e.touches[0].pageY - target_rect.top;
        }
        
        // canvasの左上隅を原点とする座標を求める
        //const downX = e.offsetX,
            //downY = e.offsetY;

        // ダウンしたので、描画フラグをtrueにする
        drawFlag = true;
     // 座標を保持する
        preX = downX*trans_resio;
        preY = downY*trans_resio;

        //shiftモード
        if(e.shiftKey){
            if(!shift_mode_flg){
                preX2 = downX*trans_resio;
                preY2 = downY*trans_resio;
                
                ctx.globalAlpha = 1.0;
                ctx.strokeStyle = window.parent.get_current_line_clr();
                ctx.fillStyle = window.parent.get_current_line_clr();
                ctx.lineWidth = 5; // 線の幅は5px
            
                ctx.beginPath(); // パスの初期化
                ctx.arc(preX2, preY2, 5, 0, 2 * Math.PI); // (x, y)の位置に半径5pxの円
                ctx.closePath(); // パスを閉じる
                ctx.fill(); // 軌跡の範囲を塗りつぶす
                
            }
            if(preX2 != 0 && preY2 != 0 && shift_mode_flg){
                ctx.globalCompositeOperation = "destination-out";
                ctx.beginPath();
                ctx.arc(preX2, preY2, 5, 0, 2 * Math.PI); // (x, y)の位置に半径5pxの円
                ctx.fill();
                ctx.globalCompositeOperation = 'source-over';

                var downX3 = ((isTouchValid ? e.changedTouches[0].pageX : e.clientX) - target_rect.left)*trans_resio;// - margin_left;
                var downY3 = ((isTouchValid ? e.changedTouches[0].pageY : e.clientY) - target_rect.top)*trans_resio;// - margin_top;                    }
                if (e.touches == undefined){ 

                    downX3 = (e.clientX - target_rect.left)*trans_resio;
                    downY3 = (e.clientY - target_rect.top)*trans_resio;
                }else{
    
                    downX3 = (e.touches[0].pageX - target_rect.left)*trans_resio;
                    downY3 = (e.touches[0].pageY - target_rect.top)*trans_resio;
                }
                drawLine(preX2, preY2, downX3, downY3);
                preX2 = 0;
                preY2 = 0;
                shift_mode_flg = false;
                return;
            }
            shift_mode_flg = true;
        }
        },
        'touchmove mousemove': function(e) {
            if(!drawFlag) {// 描画中でない
                return;
            }
            //e.preventDefault();
            // canvasの左上隅を原点とする座標を求める
            //const target_rect = e.currentTarget.getBoundingClientRect();
            var downX2 = (isTouchValid ? e.changedTouches[0].pageX : e.clientX) - target_rect.left;// - margin_left;
            var downY2 = (isTouchValid ? e.changedTouches[0].pageY : e.clientY) - target_rect.top;// - margin_top;
            if (e.changedTouches == undefined){ 

                downX2 = e.clientX - target_rect.left;
                downY2 = e.clientY - target_rect.top;
            }else{

                downX2 = e.changedTouches[0].pageX - target_rect.left;
                downY2 = e.changedTouches[0].pageY - target_rect.top;
            }
            // 1つ前の座標から現在の座標まで線分を描画する
            drawLine(preX, preY, downX2*trans_resio, downY2*trans_resio);
           console.log(downX2 +""+downY2)
            // 座標を保持する
            preX = downX2*trans_resio;
            preY = downY2*trans_resio;  
        },
        'touchend mouseup': function(e) {
            // マウスボタンが離されたので、描画フラグをfalseにする
            drawFlag = false;          
            preX = 0;
            preY = 0;
        },
        'touchleave mouseout': function(e) {
        // マウスカーソルがcanvasの外に出たので、描画フラグをfalseにする
            drawFlag = false;
            preX = 0;
            preY = 0;
        }              
    });
    function drawLine(startX, startY, endX, endY) {
        //ctx.lineWidth = 1;
        //ctx.strokeStyle = '#000000';
        if(flag_eraser){
            ctx.lineWidth = window.parent.get_current_line_size();
        }
        ctx.strokeStyle = window.parent.get_current_line_clr();
        ctx.globalAlpha = window.parent.get_current_line_opacity();
        switch(window.parent.get_current_line_sort()){
            case "1":
                ctx.setLineDash([]);
                break;
            case "2":
                ctx.setLineDash([]);
                ctx.beginPath();                // 現在のパスをリセットする
                ctx.moveTo(startX, startY);     // パスの開始座標を指定する
                ctx.lineTo(endX, endY);         // 座標を指定してラインを引く
                ctx.stroke();
                ctx.moveTo(startX, startY + window.parent.get_current_line_size() * 1.8);     // パスの開始座標を指定する
                ctx.lineTo(endX, endY + window.parent.get_current_line_size() * 1.8);         // 座標を指定してラインを引く
                ctx.stroke();
                ctx.restore();
                return;  
                break;
            case "3":
                ctx.setLineDash([3,3]);
                break;
        }
        //currentlineWidth = $('#line_width option:selected').val();

        ctx.beginPath();                // 現在のパスをリセットする
        ctx.moveTo(startX, startY);     // パスの開始座標を指定する
        ctx.lineTo(endX, endY);         // 座標を指定してラインを引く
        ctx.stroke();                   // 現在のパスを描画する

        // 描画状態を保存した時点のものに戻す
        ctx.restore();
    }
});

function allclear() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

function s_eraser(arg,flg){
    if ( flg ) {
        ctx.globalCompositeOperation = 'destination-out';
        ctx.lineWidth = arg;
        flag_eraser = false;
        //$("#eraser_btn").css('color','#ff0000');
    } else {
        ctx.globalCompositeOperation = 'source-over';
        flag_eraser = true;
        //$("#eraser_btn").css('color','#000000');
    }
}
function setHtmlTouchActionOff(){
    if(isTouchValid) $('html').css('touch-action','none');  
}
function setHtmlTouchActionOn(){
    if(isTouchValid) $('html').css('touch-action','auto');  
}
function set_img(val){
    ctx.drawImage(val, 0, 0);
}
