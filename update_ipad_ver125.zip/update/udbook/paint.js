//paintモードcanvasのデフォルト値とメソッド
let canvas_smpl;//paintの線種指定画面
let ctx_smpl;
let current_line_clr = "black";
let current_line_size = "3";
let current_line_opacity = "1";
let current_line_sort = "1";
function get_current_line_clr(){
    return current_line_clr;
}
function get_current_line_size(){
    return current_line_size;
}
function get_current_line_opacity(){
    return current_line_opacity;
}
function get_current_line_sort(){
    return current_line_sort;
}
function drawText(){
    canvas_smpl = window.document.getElementById("line_sample");
    ctx_smpl = canvas_smpl.getContext('2d');          
    ctx_smpl.font = '39px serif';
    ctx_smpl.fillStyle = '#404040';
    //文字の配置を指定（左上基準にしたければtop/leftだが、文字の中心座標を指定するのでcenter
    ctx_smpl.textBaseline = 'center';
    ctx_smpl.textAlign = 'center';
    //座標を指定して文字を描く（座標は画像の中心に）
    var x = (canvas_smpl.width / 2);
    var y = (canvas_smpl.height / 1.35);
    ctx_smpl.globalAlpha = 1.0;
    ctx_smpl.fillText("あいうえお", x, y);
}
function smpl_drawLine(clr,wide,alfa,sort){
    ctx_smpl.clearRect(0, 0, canvas_smpl.width, canvas_smpl.height);
    drawText();
    startX = 150;
    startY = 37;
    endX = 370;
    endY = 37;
    ctx_smpl.beginPath () ;
    // 線を引くスタート地点に移動
    ctx_smpl.moveTo( startX, startY ) ;
    // スタート地点から(200,200)まで線を引く
    ctx_smpl.lineTo( endX, endY )
    // 線の色
    ctx_smpl.strokeStyle = clr ;
    ctx_smpl.globalAlpha = alfa;
    // 線の太さ
    ctx_smpl.lineWidth = wide ;
    switch(sort){
        case "1":
            ctx_smpl.setLineDash([]);
            break;
        case "2":
            ctx_smpl.setLineDash([]);
            ctx_smpl.beginPath();                // 現在のパスをリセットする
            ctx_smpl.moveTo(startX, startY);     // パスの開始座標を指定する
            ctx_smpl.lineTo(endX, endY);         // 座標を指定してラインを引く
            ctx_smpl.stroke();
            ctx_smpl.moveTo(startX, startY + current_line_size * 1.8);     // パスの開始座標を指定する
            ctx_smpl.lineTo(endX, endY + current_line_size * 1.8);         // 座標を指定してラインを引く
            ctx_smpl.stroke();
            ctx_smpl.restore();
            return;  
            break;
        case "3":
            ctx_smpl.setLineDash([3,3]);
            break;
    }
    // 線を描画する
    ctx_smpl.stroke() ;
}

let eraser = function(elem,size){
    const eraser_S = document.getElementById("eraser_S");
    const eraser_L = document.getElementById("eraser_L");
    let flg = true;
    switch(elem.id){
        case "eraser_S":
            if(eraser_L.classList.contains("circle_comon_btn_active")){
                eraser_L.classList.toggle('circle_comon_btn_active');
                eraser_S.classList.toggle('circle_comon_btn_active');           
            }else if(eraser_S.classList.contains("circle_comon_btn_active")){
                eraser_S.classList.toggle('circle_comon_btn_active');
                flg = false; 
            }else{
                eraser_S.classList.toggle('circle_comon_btn_active'); 
            }
        break;
        case "eraser_L":
            if(eraser_S.classList.contains("circle_comon_btn_active")){
                eraser_S.classList.toggle('circle_comon_btn_active');
                eraser_L.classList.toggle('circle_comon_btn_active');         
            }else if(eraser_L.classList.contains("circle_comon_btn_active")){
                eraser_L.classList.toggle('circle_comon_btn_active');
                flg = false; 
            }else{
                eraser_L.classList.toggle('circle_comon_btn_active'); 
            }
        break;
    }
    document.getElementById("pageFrame_left").contentWindow.s_eraser(size,flg);
    document.getElementById("pageFrame_right").contentWindow.s_eraser(size,flg);
}
/****************************************
 index.htmlからアクセス
 arg:pageFrame_right, arg1:pageFrame_left
 連結ページの場合は引数を修正する
****************************************/ 
let canvas_clr = function(arg){
    if(get_dsp_mode() == "single"){
        if(get_dbl_page_side() == ""){
            if(get_single_mode_func_arg() == "L"){
                arg = "pageFrame_left";
            }else if(get_single_mode_func_arg() == "R"){
                arg = "pageFrame_right";
            }
        }else if(get_dbl_page_side() == "L"){
            arg = "pageFrame_left";
        }else if(get_dbl_page_side() == "R"){
            arg = "pageFrame_right";
        }
    }else if(get_dsp_mode() == "dual"){
        if(get_dbl_page_side()=="R"){
            arg="pageFrame_right"
        }else if(get_dbl_page_side()=="L"){
            arg="pageFrame_left"
        }
    }
    document.getElementById(arg).contentWindow.allclear();
}
//paint,memoを保存した後tmp_reg_L.html、tmp_reg_R.htmlで参照する変数
let reg_L_flg = false;
let reg_R_flg = false;
let reg_flg;
function get_reg_flg(arg){
    if(arg == "L"){
        return reg_L_flg;
    }else if(arg == "R"){
        return reg_R_flg;
    }
}
function get_reg(){
    return reg_flg;
}
function set_reg_flg(arg,flg){
    reg_L_flg = false;
    reg_R_flg = false;
    if(arg == "L"){
        reg_L_flg = flg;
    }else if(arg == "R"){
        reg_R_flg = flg;
    }
    reg_flg = "";
}
/****************************************
 index.htmlからアクセス
 arg1:pageFrame_right arg2:reg_frame_R
 arg1:pageFrame_left  arg2:reg_frame_L
 連結ページの場合は引数を修正する
 page.jsからもアクセスあり--memo削除の保存
****************************************/ 
function reg_paint_memo(arg1,arg2){
    const mode = get_mode();
    if(get_dsp_mode() == "single"){
        if(get_dbl_page_side() == ""){
            if(get_single_mode_func_arg() == "L"){
                arg1 = "pageFrame_left";
                arg2 = "reg_frame_L";
                set_reg_flg("L",true);
            }else if(get_single_mode_func_arg() == "R"){
                arg1 = "pageFrame_right";
                arg2 = "reg_frame_R";
                set_reg_flg("R",true);
            }
        }else if(get_dbl_page_side() == "L"){
            arg1 = "pageFrame_left";
            arg2 = "reg_frame_L";
            set_reg_flg("L",true);
        }else if(get_dbl_page_side() == "R"){
            arg1 = "pageFrame_right";
            arg2 = "reg_frame_R";
            set_reg_flg("R",true);
        }
    }else if(get_dsp_mode() == "dual"){
        if(get_dbl_page_side()=="R"){
            arg1 = "pageFrame_right"
            arg2 = "reg_frame_R";
            set_reg_flg("R",true);
        }else if(get_dbl_page_side()=="L"){
            arg1 = "pageFrame_left"
            arg2 = "reg_frame_L";
            set_reg_flg("L",true);
        }else if(get_dbl_page_side()==""){
            if(arg1 == "pageFrame_left"){
                set_reg_flg("L",true);
            }else if(arg1 == "pageFrame_right"){
                set_reg_flg("R",true);
            }
        }
    }   
    /*
    if(arg1=="pageFrame_left"){
        //if(get_right_iframe_width() == get_iframe_dbl_width()){
        if(get_dbl_page_side()=="R"){
            arg1="pageFrame_right"
            arg2 = "reg_frame_R";
            reg_R_flg = true;
        }else{
            reg_L_flg = true;
        }
    }else if(arg1=="pageFrame_right"){
        //if(get_left_iframe_width() == get_iframe_dbl_width()){
        if(get_dbl_page_side()=="L"){   
            arg1="pageFrame_left"
            arg2 = "reg_frame_L";
            reg_L_flg = true;
        }else{
            reg_R_flg = true;
        }
    */
    if(mode == "paint"){
        document.getElementById(arg1).contentWindow.reg_paint(arg2);
    }else if(mode == "memo"){
        document.getElementById(arg1).contentWindow.reg_memo(arg2);
    }else if(mode == "speech"){
        set_read_last_pageNo(document.getElementById(arg1).contentWindow.get_page_no());
        document.getElementById(arg1).contentWindow.reg_pageNo();
    }
}
let reg_memo = function(arg1,arg2){
    if(arg1=="pageFrame_left"){
        reg_L_flg = true;
    }else if(arg1=="pageFrame_right"){
        reg_R_flg = true;
    }
    document.getElementById(arg1).contentWindow.reg_memo(arg2);
}
const line_sort_elems = document.getElementsByClassName("line_sort");
for(i=0;i<line_sort_elems.length;i++){
    line_sort_elems[i].onclick = function(){
        //色
        if(this.firstChild == null){
            current_line_clr = this.style.backgroundColor;current_line_opacity
            smpl_drawLine(current_line_clr,current_line_size,current_line_opacity,current_line_sort);
        //太さ
        }else if(this.firstChild.tagName == "HR"){
            const fragment = document.createRange().createContextualFragment(this.outerHTML);
            const size = fragment.childNodes[0].getAttribute("size");
            const alfa = fragment.childNodes[0].getAttribute("alfa");
            current_line_size = size;
            current_line_opacity = alfa;
            smpl_drawLine(current_line_clr,current_line_size,current_line_opacity,current_line_sort);
        //種類
        }else if(this.firstChild.tagName == "P"){
            const fragment = document.createRange().createContextualFragment(this.outerHTML);
            current_line_sort = fragment.childNodes[0].id
            smpl_drawLine(current_line_clr,current_line_size,current_line_opacity,current_line_sort);
        }
    }
}

