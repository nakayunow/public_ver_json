const _sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
//スタートモード
let mode = "speech";
function get_mode(){
    return mode;
}
let speech_flg = false;
function set_speech_flg(val){
    speech_flg = val;
}

let page_speaking_flg = false;
function set_page_speaking_flg(val){
    page_speaking_flg = val;
}
function get_page_speaking_flg(){
    return page_speaking_flg;
}
//書庫から教材を選択済みの場合、true
let selected_material_flg = false;
function set_selected_material_flg(val){
    selected_material_flg = val;
}
function get_selected_material_flg(){
    return selected_material_flg;
}
function page_trans_conver_non(){
    get_elem_byId("page_trans_conver").style.display = "none";
}
/****************** ページコントロールメソッド ****************** */

/* ************************* リフロー関連 ***************************** */
let compare_pageNo;
let dual_flg = true;
let reflow_frame_side;
function get_reflow_frame_side(){
    return reflow_frame_side;
}
/* ****************************************
引数
btn:クリックしたボタンエレメント
side:クリックしたボタンの位置。右か左か。
**************************************** */
let show_reflow = function(btn,side){
    reflow_frame_side = side;
    //タッチパネルの場合は、divFrameが右に55pxズレているので、-55px移動させる
    //const delta = ('ontouchstart' in window) ? 55 : 0;
    const delta = ('ontouchstart' in window) ? 0 : 0;
    let input_pageFrame;
    let divFrame;//[リフローを表示する側のdiv要素のid,表示する場合のstyle.left]
    let pre_voice_trans_arg1;//speechに使用する

    //Rボタン表示変更とpre_voice_trans_arg1の設定
    //左側のRボタンクリック
    if(side=="L"){
        if(btn != null){ //右側のRボタンがアクティブの時,非アクティブにする
            if(get_elem_byId("R_right_btn").classList.contains("circle_btn_e_active")){
                get_elem_byId("R_right_btn").classList.toggle('circle_btn_e_active');
            }
        }
        if(phrase_umu == "ari"){
            pre_voice_trans_arg1 = 0;
        }else{
            pre_voice_trans_arg1 = 6;
        }
        //左側のページをリフロー表示
        input_pageFrame= "pageFrame_left";
        if(get_open_direct() == 'R'){
            compare_pageNo = "large";
        }else{
            compare_pageNo = "small";
        }
    //右側のRボタンクリック
    }else if(side=="R"){
        if(btn != null){
            if(get_elem_byId("R_left_btn").classList.contains("circle_btn_w_active")){
                get_elem_byId("R_left_btn").classList.toggle('circle_btn_w_active');
            }
        }
        if(phrase_umu == "ari"){
            pre_voice_trans_arg1 = 1;
        }else{
            pre_voice_trans_arg1 = 7;
        }
        //右側のページをリフロー表示
        input_pageFrame = "pageFrame_right";
        if(get_open_direct() == 'R'){
            compare_pageNo = "small";
        }else{
            compare_pageNo = "large";
        }
    }
    //************************** リフロー表示 **************************
    if(side=="L"){//左側のボタンクリック
        divFrame = "divFrame_left";
        if(btn == null || btn.classList.contains("circle_btn_w_active")){
            reflow_mode = true;
            dsp_reflow("L");
            //右側のiframeがdual_pageの場合
            //if(get_elem_byId("pageFrame_right").style.width == get_iframe_dbl_width()){
            if(get_dbl_page_side()=="R"){
                input_pageFrame = "pageFrame_right";
                if(pre_voice_trans_arg1 == 0){
                    pre_voice_trans_arg1= 1;
                }else{
                    pre_voice_trans_arg1= 7
                }
                //======= scrollバーの表示 =======
                if(get_dsp_mode() == "dual"){
                    get_elem_byId("pageFrame_right").parentNode.style.width = get_iframe_width();
                }
            }
            //左側のiframeがdual_pageの場合
            //if(get_elem_byId("pageFrame_left").style.width  == get_iframe_dbl_width()){
            if(get_dbl_page_side()=="L"){
                if(get_dsp_mode() == "dual"){
                    get_elem_byId("pageFrame_left").parentNode.style.width = get_iframe_width();
                }
            }
        //リフローを非表示にする
        }else{
            reflow_mode = false;
            hide_reflow();
            return;
        }        
    }else if(side=="R"){//右側のRボタンクリック
        divFrame = "divFrame_right";
        if(btn == null || btn.classList.contains("circle_btn_e_active")){
            reflow_mode = true;
            dsp_reflow("R");//右側のページをリフロー表示する
            //左側のiframeがdual_pageの場合、右ボタンをクリックしても左側のページのリフローを表示する。
            if(get_dbl_page_side()=="L"){
                input_pageFrame = "pageFrame_left";
                if(pre_voice_trans_arg1 == 1){
                    pre_voice_trans_arg1= 0;
                }else{
                    pre_voice_trans_arg1= 6
                }            
                if(get_dsp_mode() == "dual"){                    
                    //********** scrollバーの表示 **********
                    get_elem_byId("pageFrame_left").parentNode.style.width = get_iframe_width();
                    get_elem_byId("pageFrame_left").parentNode.scrollLeft = get_iframe_int_width_under_dual();
                    //page_frameのwidthが半分になりleftが左に寄っている為
                    if(reflow_dsp_side == "R") page_frame.style.left = "0px";
                    if(reflow_dsp_side == "L") page_frame.style.left = get_iframe_width();
                }
            }
            //右側のiframeがdual_pageの場合。
            if(get_dbl_page_side()=="R"){
                if(get_dsp_mode() == "dual"){
                    //********** scrollバーの表示 **********
                    //get_elem_byId("pageFrame_right").parentNode.style.width = get_iframe_width();
                    //リフローモード時
                    if(get_reflow_mode){
                        get_elem_byId("pageFrame_right").parentNode.style.width = get_iframe_width();
                        //リフローモード時は、ageFrame_leftのwidthをget_iframe_widthで設定してpageFrame_rightを左に寄せる
                        get_elem_byId("pageFrame_left").parentNode.style.width = get_iframe_width();
                        get_elem_byId("pageFrame_right").parentNode.scrollLeft = get_iframe_int_width_under_dual();
                    }else{
                        get_elem_byId("pageFrame_right").parentNode.style.width = get_iframe_width();
                    }
                }
            }
        }else{
            reflow_mode = false;
            hide_reflow();
            return;
        }
    }
    //alert(input_pageFrame);
    //alert(divFrame);
    make_reflow_dsp(input_pageFrame,divFrame,pre_voice_trans_arg1);
    let rt_elems_rf = get_strctrl_elems("exdiv");//get_strctrl_elems()--config.js
    if(get_furigana_umu_rf() == "ari"){
        for(i=0;i<rt_elems_rf.length;i++){
            rt_elems_rf[i].style.visibility = "visible";
        }    
    }else if(get_furigana_umu_rf() == "nasi"){
        for(i=0;i<rt_elems_rf.length;i++){
            rt_elems_rf[i].style.visibility = "hidden";
        }
    }
    get_elem_byId(divFrame).scrollTop = 0;
    return pre_voice_trans_arg1;
}

//リフローボタン色をinactive色に戻す。
function reset_reflow_btn(){
    if(get_elem_byId("R_right_btn").classList.contains("circle_btn_e_active")){
        get_elem_byId("R_right_btn").classList.toggle('circle_btn_e_active');
    }
    if(get_elem_byId("R_left_btn").classList.contains("circle_btn_w_active")){
        get_elem_byId("R_left_btn").classList.toggle('circle_btn_w_active');
    }
}

/* ****************************************************************
引数:
input_pageFrame:クリックしたRボタン側のiframeのid
divFrame:クリックしたRボタン側のdivFrameのid
pre_voice_trans_arg1:スピーチのモード
※連結ページの場合の修正が必要。
**************************************************************** */
let make_reflow_dsp = function(input_pageFrame,divFrame,pre_voice_trans_arg1){
    //初期化--divFrameのinnerTextを消去
    const divFrame_elem = document.getElementById(divFrame);
    while(divFrame_elem.firstChild ){
        divFrame_elem.removeChild(divFrame_elem.firstChild);
    }
    if(document.getElementById(input_pageFrame).contentDocument.getElementById("speech_order") == null)return;
    const StrCtrl_ids = document.getElementById(input_pageFrame).contentDocument.getElementById("speech_order").innerHTML.split(':');  
    
    divFrame_elem.ondblclick = function(event){
        set_execution_quit();
        voice_trans_quit();
        if(event != null) event.stopPropagation();
    }
    //リフロー画面クリックでspeech
    for(i=0;i<StrCtrl_ids.length - 1;i++){
        let strCtrl_elem = document.getElementById(input_pageFrame).contentDocument.getElementById(StrCtrl_ids[i]);
        //fragment--class.StrCtrlのouterHTML
        if(strCtrl_elem == null) continue;

        let fragment = document.createRange().createContextualFragment(strCtrl_elem.outerHTML);
        //class.StrCtrlのbackgroundColorをデフォルトにする
        let strCtrl_elem_array = fragment.childNodes[0].innerHTML.split("<br>");
        let ctrl_br_html = "";
        for(m=0;m<strCtrl_elem_array.length;m++){
            const tmp_div_elm = document.createElement("div");
            tmp_div_elm.innerHTML = strCtrl_elem_array[m];
            if(tmp_div_elm.textContent.endsWith("。") || tmp_div_elm.textContent.endsWith("。」")){
                ctrl_br_html += tmp_div_elm.innerHTML + "<br>";
            }else{
                ctrl_br_html += tmp_div_elm.innerHTML;
            }
        }
        fragment.childNodes[0].innerHTML = ctrl_br_html;
        fragment.childNodes[0].style.backgroundColor = "";
        fragment.childNodes[0].style.color = "rgb(0,0,0)";
        fragment.childNodes[0].style.opacity = "1.0";
        fragment.childNodes[0].style.cursor = "pointer";
        let celems = fragment.childNodes[0].getElementsByClassName("phrase");
        //オリジナルのphraseエレメント群
        let orign_phrase_elems = strCtrl_elem.getElementsByClassName("phrase");
        for(j=0;j<celems.length;j++){
            celems[j].blur();
            celems[j].style.opacity = "1.0";
            const orign_phrase_elem = orign_phrase_elems[j];
            celems[j].addEventListener("click",function(event){
                //if(isAutoPageExecution()) return;
                if(speech_flg){
                    voice_trans_pause();
                    speech_flg = false;  
                }else{
                    let id_elem = strCtrl_elem;//読み出す対象のStrCtrlを格納
                    pre_voice_trans(pre_voice_trans_arg1,id_elem.id,true,orign_phrase_elem);           
                    speech_flg = true;
                }
                if(get_auto_page_changing_flg){
                    set_current_page((input_pageFrame == "pageFrame_left")?left_page:right_page);
                }
                event.stopPropagation();
            });
            celems[j].addEventListener("dblclick",function(event){
                set_execution_quit();
                voice_trans_quit();
                voice_trans_quit();
                event.stopPropagation();
            });
        }
        //fragment.childNodes[0]=class.StrCtrl
        //ルビ表示
        const rt_elems = fragment.childNodes[0].getElementsByTagName("rt");
        for(k=0;k<rt_elems.length;k++){
            rt_elems[k].style.display = "";
        };
        fragment.childNodes[0].id = strCtrl_elem.id.replace("div","exdiv");
        fragment.childNodes[0].style.height = "";
        fragment.childNodes[0].style.width = "";
        fragment.childNodes[0].style.lineHeight = "normal";
        fragment.childNodes[0].style.writingMode = "";
        fragment.childNodes[0].style.color = get_font_color_rf();
        const elem = get_elem_byId("reflow_font_size");
        const fontSize =  elem.options[reflow_font_size].value;
        fragment.childNodes[0].style.fontSize = fontSize;
        const elem1 = get_elem_byId("reflow_font_size");
        const s1 =  elem1.options[elem1.selectedIndex].textContent;
        const elem2 = get_elem_byId("reflow_line_height");
        const s2 =  elem2.options[elem2.selectedIndex].textContent;
        const s = Number(s1.replace("px","")) + Number(s2.replace("px","")) + "px";

        const elm = fragment.childNodes[0].getElementsByTagName("span");
        for(q=0;q<elm.length;q++){
            elm[q].style.opacity = "";
            elm[q].style.lineHeight = s;
        }
        fragment.childNodes[0].style.display= "inline-block";
        divFrame_elem.appendChild(fragment.childNodes[0]);
        divFrame_elem.appendChild(document.createElement("br"));
    }
    //divFrame_elem.style.display = "block";
    //リフロー画面のフォントサイズ設定
    set_current_reflow_font_size();
}
let exec_count = 0;
//page.jsが呼び出される度に実行される。
//リフローモードの時に、2ページ読み込んだ後にshow_reflow_at_pageLoad実行。
function count_up(){
    exec_count += 1;
    if(exec_count > 1){
        if(reflow_mode) {
            show_reflow_at_pageLoad();
            exec_count = 0;
        }
    }
}

let reflow_mode = false;
//page.jsからアクセス
function get_reflow_mode(){
    return reflow_mode;
}
function set_reflow_mode(val){
    //reflow_mode = false;
    reflow_mode = val;
}
let rt_side;//L:左ボタンクリック。R:右ボタンクリック。
function show_reflow_at_pageLoad(){
    //show_reflow(null,rt_side) null:ボタン表示操作しない。
    if(reflow_mode && rt_side != null){
        const rt = show_reflow(null,rt_side);
        //リフローモードの時auto_speechの場合は以下を実行
        if(execution_flg) pre_voice_trans(rt,null,reflow_flg)
    }
}
/* *******************************************************
リフローモードの時のページ遷移を実行する。
ページ遷移と同時に、ページが読み込まれた時に表示するリフローを設定する。
2ページの読み込み完了後にshow_reflow_at_pageLoad()が発火。
show_reflow_at_pageLoad()でリフロー表示ボタンの設定により擬似的に
クリックイベントを発生させる。
リフローモードの場合はその後、pre_voice_transを実行される。これ重要。

◀︎ ▶︎ ボタンをクリックした場合、btnはクリツクしたエレメント
関数から呼ばれた場合btn = null;

get_dbl_page_side -- arrange_for_each_mode.jsの関数
L:左ページが連結ページ
R:右ページが連結ページ
"":左右単ページ
******************************************************* */
let set_page_in_reflow_mode = function(sort){
    if(sort == "proceed"){
        if(get_open_direct() == "R"){
            //表示中のページがlargeページの場合はproceedする。
            //if(compare_pageNo == "large" || compare_pageNo == ""){
            if(compare_pageNo == "large"){
                set_page("proceed");
                rt_side = "R";
            }else{
                //if(get_right_iframe_width() == get_iframe_dbl_width()){
                //表示中のページがlargeページでないが、連結ページの場合はproceedする。
                if(get_dbl_page_side()!=""){   
                    set_page("proceed");
                    rt_side = "R";
                //ページ遷移無し。リフロー表示ページのみ切替
                }else{         
                    show_reflow(null,"L")
                    rt_side = null;
                }            
            }
        //左開きの場合
        }else if(get_open_direct() == "L"){
            //if(compare_pageNo == "large" || compare_pageNo == ""){
            if(compare_pageNo == "large"){
                set_page("proceed");
                rt_side = "L";
            }else{
                //if(get_left_iframe_width() == get_iframe_dbl_width()){
                if(get_dbl_page_side()!=""){
                    set_page("proceed");
                    rt_side = "L";
                }else{        
                    show_reflow(null,"R")
                    rt_side = null;
                }
            }
        }
    }else if(sort == "reverse"){
        //右開きの場合のreverse
        if(get_open_direct() == "R"){
            //if(compare_pageNo == "small" || compare_pageNo == ""){
            if(compare_pageNo == "small"){
                //if(get_left_iframe_width() == get_iframe_dbl_width()){
                //if(get_dbl_page_side()=="L"){   
                    //set_page("reverse");
                    //rt_side = "L";
                //}else{
                    set_page("reverse");
                    rt_side = "L";
                //}
            }else{
                if(get_dbl_page_side()!=""){   
                    set_page("reverse");
                    rt_side = "L";
                }else{ 
                    show_reflow(null,"R")
                    rt_side = null;
                }
            }
        //左開きの場合のreverse
        }else if(get_open_direct() == "L"){
            //if(compare_pageNo == "small" || compare_pageNo == ""){
            if(compare_pageNo == "small"){
                //if(get_right_iframe_width() == get_iframe_dbl_width()){
                //if(get_dbl_page_side()=="R"){   
                    //set_page("reverse");
                    //rt_side = "R";
                //}else{
                    set_page("reverse");
                    rt_side = "R";
                //}
            }else{
                if(get_dbl_page_side()!=""){   
                    set_page("reverse");
                    rt_side = "R";//ページが読み込まれた時にshow_reflow(null,rt_side)を実行する
                }else{
                    show_reflow(null,"L") //nullは、リフロー表示ボタンの見栄えを変えるメソッドを実行しない。
                    rt_side = null;//nullは、reflow_modeがtrueでもページが読み込まれた時にshow_reflowを実行させない。
                }
            }
        }
    }
}
/* **************** get_next_pages ****************
指定ページが含まれるページの次の2ページを返す
引数:pno 指定ページ
戻り値:rt rt[SmallNo_page,BigNo_page]
************************************************ */
const get_next_pages = function(pno){
    const array = get_page_order_array();
    const idx = array.indexOf(pno);
    let rt = [];
    if(idx%2 == 0){
        rt.push(array[idx + 2]);
        rt.push(array[idx + 3]);
    }else{
        rt.push(array[idx + 1]);
        rt.push(array[idx + 2]);
    }
    return rt;
}
/* **************** get_pre_pages ****************
指定ページが含まれるページの前の2ページを返す
引数:pno 指定ページ
戻り値:rt rt[SmallNo_page,BigNo_page]
************************************************ */
const get_pre_pages = function(pno){
    const array = get_page_order_array();
    const idx = array.indexOf(pno);
    let rt = [];
    if(idx%2 == 0){
        rt.push(array[idx - 2]);
        rt.push(array[idx - 1]);
    }else{
        rt.push(array[idx - 3]);
        rt.push(array[idx - 2]);
    }
    return rt;
}
/******************** trans_directed_page ******************
番号で指定したページにジャンプする
ページは番号のみ指定できる(S1,E1等は指定できない)
引数:pno ページ番号
戻り値:教科書の捲り方向を前提とした画面左右のページ番号を配列で返す
        rt_array[左ページ,右ページ]
表示するページ番号を指定した時に発動する
子要素からのアクセス有り
********************************************************** */        
function trans_directed_page(pno){
    let trans_idx;
    const direct_array = get_page_numDirected_order_array();
    const array = get_page_order_array();
    if(direct_array.length != 0){
        for(v=0;v<direct_array.length;v++){
            const t_array = direct_array[v].split("-");
            if(t_array.indexOf(pno) != -1){
                trans_idx = v;
                break;
            }
        }
    }else{
        trans_idx = array.indexOf(pno);
    }
    
    const idx = trans_idx;//array.indexOf(pno);  
    if(idx == -1){
        show_reg_info("指定のページ番号が最後のページをより大きいので、最後のページを表示します!");
        trans_directed_page(array[array.length-1]);
        return;
    }
    let rt = [];
    document.getElementById("dsp_area").scrollLeft = 0;
    //SmallNo
    if(idx%2 == 0){
        rt.push(array[idx]);
        rt.push(array[idx + 1]);
        //右開きの場合--左側がBigNo
        if(get_open_direct() == 'R' && get_dsp_mode() == "single"){
            document.getElementById("dsp_area").scrollLeft = get_iframe_int_width_under_sigle();
        }
    //BigNo
    }else{
        rt.push(array[idx - 1]);
        rt.push(array[idx]);
        //左開きの場合--左側がBigNo
        if(get_open_direct() == 'L' && get_dsp_mode() == "single"){
            document.getElementById("dsp_area").scrollLeft = get_iframe_int_width_under_sigle();
        }
    }
    //左開きの場合--右側がBigNoなので何もしない
    //右開きの場合--左側がBigNo
    if(get_open_direct() == 'R'){
       const temp_page = rt[0];
       rt.shift();
       rt.push(temp_page);
    }
    set_left_page(rt[0]);
    set_right_page(rt[1]);
    if(get_dsp_mode() == "single"){
        if(idx%2 == 0){
            if(get_open_direct() == 'L'){        
                single_mode_func_arg = "L";            
            }else if(get_open_direct() == 'R'){
                single_mode_func_arg = "R"; 
            }
        }else{
            if(get_open_direct() == 'L'){        
                single_mode_func_arg = "R"; 
            }else if(get_open_direct() == 'R'){
                single_mode_func_arg = "L"; 
            }
        }
    }
    req_page(rt[0],rt[1]);
}
//ページ指定ダイアログ
const en_pno = document.getElementsByClassName("en_pno");
for(i=0;i<en_pno.length;i++){
    let tg = en_pno[i].innerHTML;
    en_pno[i].onclick = function(){
        if(isNaN(this.innerHTML)){
            const rt = get_read_last_pageNo();
            if(rt == "nofile"){
                //alert("読み終わったページがありません!");
                show_reg_info("読み終わったページがありません!")
            }else{
                dsp_page.value=get_read_last_pageNo();
            }
        }else{
            dsp_page.value += tg;
        }
    }
}
//表示ページ指定ウィンドウからのページ遷移
let jump_page = function(){
    const dsp_page = document.getElementById("dsp_page");
    //ページ指定欄が空白の場合
    if(dsp_page.value == ""){
        document.getElementById("page_tb").style.display = "none";
        return;
    }
    //const array = get_page_order_array();
    //const idx = array.indexOf(dsp_page.value);

    let idx = -1;
    const direct_array = get_page_numDirected_order_array();
    const array = get_page_order_array();
    if(direct_array.length != 0){
        for(v=0;v<direct_array.length;v++){
            const t_array = direct_array[v].split("-");
            if(t_array.indexOf(dsp_page.value) != -1){
                idx = v;
                break;
            }
        }
    }else{
        idx = array.indexOf(dsp_page.value);
    }
    if(idx == -1){
        if(direct_array.length != 0){
            for (let m = direct_array.length - 1; m >= 0 ; m--){
                if(!isNaN(direct_array[m])){
                    show_reg_info(direct_array[m] + "ページが最後のページです!");
                    break;
                }
            }
        }else{
            show_reg_info(get_last_number_page() + "ページが最後のページです!");
        }
        return;
    }
    trans_directed_page(dsp_page.value);
    document.getElementById("page_tb").style.display = "none";
    dsp_page.value = "";
}
/************************ show_pages **********************
menuボタンクリックで稼働
auto_speech中にページ遷移をした場合、auto_speechを終了させる。
************************ show_pages **********************/
const trun_page = function(val){
    if(execution_flg) {
        voice_trans_quit(false);
    }
    show_pages(val);
}
/************************ show_pages **********************
set_pageのラッパー。ページを進めて表示する。戻して表示する。
引数:proceed or reverse
リフローモードの時は、set_page_in_reflow_mode実行
通常モードの時は、set_page実行
********************************************************** */
const show_pages = function(sort){
    if(reflow_mode){
        exec_count = 0;
        set_page_in_reflow_mode(sort);
    }else{
        set_page(sort); 
    }
}
/************************ single_mode ***********************
single_modeの時のページ表示構成指定
引数:side-表示するページサイド
speech_mode:
********************************************************** */
let single_mode = function(side,speech_mode = true){
    if(!speech_mode){
        show_reg_info("xxxxxxxx");
        switch(side){
            //左サイド表示
            case "L":
                document.getElementById("dsp_area").scrollLeft = 0;
                get_elem_byId("pageFrame_left").parentNode.style.width = get_iframe_int_width_under_sigle() + "px";
                get_elem_byId("pageFrame_right").parentNode.style.width = get_iframe_int_width_under_sigle() + "px";            
                break;
            //右サイド表示
            case "R":
                document.getElementById("dsp_area").scrollLeft = get_iframe_int_width_under_sigle();//get_iframe_int_width();
                get_elem_byId("pageFrame_left").parentNode.style.width = "";
                get_elem_byId("pageFrame_right").parentNode.style.width = "";
            break;
        }
    }else{
        switch(side){
            //左サイド表示
            case "L":
                get_elem_byId("pageFrame_left").parentNode.style.width = get_iframe_int_width_under_sigle() + "px";
                get_elem_byId("pageFrame_right").parentNode.style.width = get_iframe_int_width_under_sigle() + "px";                    
                //dsp_areaをスクロール無しにする
                document.getElementById("dsp_area").scrollLeft = 0;
                if(get_dbl_page_side() == "R"){
                    document.getElementById("dsp_area").scrollLeft = get_iframe_int_width_under_sigle();
                }
                document.getElementById("pageFrame_left").parentNode.scrollLeft = 0;
                document.getElementById("pageFrame_right").parentNode.scrollLeft = 0;
                
                //単ページだが画像が連結されてサイズアップしている場合-2022-5-21追加
                const img_elem = document.getElementById("pageFrame_left").contentDocument.getElementById("image");
                const img_n_width = img_elem.naturalWidth * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
                const img_n_height = img_elem.naturalHeight * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
                if(img_n_width > get_iframe_int_width_under_sigle() * 1.5){
                    const resio = get_iframe_int_height_under_sigle()/img_n_height;
                    const v = "scale(" + resio + "," + resio + ")";
                    document.getElementById("pageFrame_left").contentWindow.set_body_transform(v,resio);
                    document.getElementById("pageFrame_left").style.width = img_n_width + "px";
                    if(touch_flg) document.getElementById("pageFrame_left").parentNode.style.backgroundColor = IFRAME_OVERFLOW;
                }

                if(get_open_direct() == 'L'){
                    document.getElementById("pageFrame_left").parentNode.scrollLeft = get_iframe_int_width_under_sigle();
                }
                break;
            //右サイド表示
            case "R":
                get_elem_byId("pageFrame_left").parentNode.style.width = get_iframe_int_width_under_sigle() + "px";
                get_elem_byId("pageFrame_right").parentNode.style.width = get_iframe_int_width_under_sigle() + "px";
                if(get_open_direct() == 'L'){
                    document.getElementById("dsp_area").scrollLeft = 0;
                }else if(get_open_direct() == 'R'){
                    document.getElementById("dsp_area").scrollLeft = get_iframe_int_width_under_sigle();
                }              
                document.getElementById("pageFrame_left").parentNode.scrollLeft = get_iframe_int_width_under_sigle();
                document.getElementById("pageFrame_right").parentNode.scrollLeft = get_iframe_int_width_under_sigle();
                //連結ページで無い場合、dsp_areaを左にスクロールしてiframe_rightを表示するようにする
                if(get_dbl_page_side() == ""){
                    document.getElementById("dsp_area").scrollLeft = get_iframe_int_width_under_sigle();
                    //単ページだが画像が連結されてサイズアップしている場合-2022-5-20追加
                    const img_elem = document.getElementById("pageFrame_right").contentDocument.getElementById("image");
                    const img_n_width = img_elem.naturalWidth * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
                    const img_n_height = img_elem.naturalHeight * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
                    if(img_n_width > get_iframe_int_width_under_sigle() * 1.5){
                        const resio = get_iframe_int_height_under_sigle()/img_n_height;
                        const v = "scale(" + resio + "," + resio + ")";
                        document.getElementById("pageFrame_right").contentWindow.set_body_transform(v,resio);
                        document.getElementById("pageFrame_right").style.width = img_n_width + "px";
                        if(touch_flg) document.getElementById("pageFrame_right").parentNode.style.backgroundColor = IFRAME_OVERFLOW;
                    }  
                }
                if(get_open_direct() == 'L'){
                    document.getElementById("pageFrame_left").parentNode.scrollLeft = 0;
                }
                break;
        }
    }
}
//最初のsingle切替時に表示されるのは左ページ
let single_mode_func_arg = "L";
//page.jsからアクセス
function single_mode_func_exe(){
    if(get_dsp_mode() == "single"){
        single_mode(single_mode_func_arg);
    }else{
        return single_mode("");
    }
}
//paint.jsからアクセス
function get_single_mode_func_arg(){
    return single_mode_func_arg;
}
/************************ set_page ************************
引数:proceed or reverse
proceed---次のデュアルページを表示する。次の単ページにスクロールする
reverse---前のデュアルページを表示する。前の単ページにスクロールする
通常モードの時に実行する
入れ子関数
get_isBigNoPage_under_single_mode
get_iframe_posi
********************************************************** */
const set_page = function(sort){
    let BigNo_page;
    let SmallNo_page;
    //左開きの場合--右側がBigNo
    if(get_open_direct() == 'L'){
        BigNo_page = get_right_page();
        SmallNo_page = get_left_page();
    //右開きの場合--左側がBigNo
    }else if(get_open_direct() == 'R'){
        BigNo_page = get_left_page();
        SmallNo_page = get_right_page();
    }
    let left_page_no;
    let right_page_no;

    const sx = document.getElementById("dsp_area").scrollLeft;

//if-singleモード
    if(get_dsp_mode() == "single"){
  //if-ページ前進
        if(sort == "proceed"){
    //if-bigページ表示中 又は リフローモード 又は オートスピーチ中
            if(get_isBigNoPage_under_single_mode() || reflow_mode || execution_flg){
                //BigNo_pageの次の2ページ。BigNo_pageがlast_pageの場合は通知。
                if(BigNo_page == get_last_page()){
                    show_reg_info("最後のページです。");
                    //alert("最後のページです。");
                    return;        
                }
      //if-左開き
                /* *********************************************************
                bigページ表示中の場合は、ページ遷移を伴う為、single_mode()ではなく、
                single_mode_func_argを指定する
                ********************************************************* */
                if(get_open_direct() == 'L'){
                    left_page_no = get_next_pages(BigNo_page)[0];
                    right_page_no = get_next_pages(BigNo_page)[1];
                    single_mode_func_arg = "L";
      //if-右開き
                }else{
                    left_page_no = get_next_pages(BigNo_page)[1];
                    right_page_no = get_next_pages(BigNo_page)[0];
                    single_mode_func_arg = "R";
                }
                if(reflow_mode) single_mode_func_arg = "";
    //if-smallページ表示中 又は リフローモードではない 又は オートスピーチ中では無い
            }else{
                left_page_no = get_left_page();
                right_page_no = get_right_page();
      //if-左開き
                /* *********************************************************
                smallページ表示中の場合は、ページ遷移を伴わない為、single_mode()で指定
                ********************************************************* */
                if(get_open_direct() == 'L'){
                    single_mode("R");
      //if-右開き
                }else{
                    single_mode("L");
                }                  
                return;
            }
  //if-ページ後退
        }else if(sort == "reverse"){
    //if-bigページ表示中
            if(get_isBigNoPage_under_single_mode()){
                left_page_no = get_left_page();
                right_page_no = get_right_page();
      //if-左開き
                if(get_open_direct() == 'L'){
                    //single_mode_func = single_mode("L");
                    //single_mode_func_arg = "L";
                    single_mode("L");
      //if-右開き
                }else{
                    //single_mode_func = single_mode("R");
                    //single_mode_func_arg = "R";
                    single_mode("R");
                }                  
                return;
    //if-smallページ表示中
            }else if(!get_isBigNoPage_under_single_mode() || reflow_mode){
                if(SmallNo_page == get_first_page()){
                    show_reg_info("最初のページです。");
                    //alert("最初のページです。");
                    return;
                }
      //if-左開き
                if(get_open_direct() == 'L'){
                    //single_mode_func = single_mode("R");
                    left_page_no = get_pre_pages(BigNo_page)[0];
                    right_page_no = get_pre_pages(BigNo_page)[1];
                    single_mode_func_arg = "R";
      //if-右開き
                }else{
                    //single_mode_func = single_mode("L");
                    left_page_no = get_pre_pages(BigNo_page)[1];
                    right_page_no = get_pre_pages(BigNo_page)[0];
                    single_mode_func_arg = "L";
                }
                if(reflow_mode) single_mode_func_arg = "";          
            }
        }
//if-dualモード      
    }else{
        if(sort == "proceed"){
            if(BigNo_page == get_last_page()){
                show_reg_info("最後のページです。");
                //alert("最後のページです。");
                return;        
            }
            if(get_open_direct() == 'L'){
                left_page_no = get_next_pages(BigNo_page)[0];
                right_page_no = get_next_pages(BigNo_page)[1];
            }else if(get_open_direct() == 'R'){
                left_page_no = get_next_pages(BigNo_page)[1];
                right_page_no = get_next_pages(BigNo_page)[0];
            }
        }else if(sort == "reverse"){
        //SmallNo_pageの前の2ページ。SmallNo_pageがfirst_pageの場合は通知。
            if(SmallNo_page == get_first_page()){
                show_reg_info("最初のページです。");
                //alert("最初のページです。");
                return;
            }
            if(get_open_direct() == 'L'){
                left_page_no = get_pre_pages(BigNo_page)[0];
                right_page_no = get_pre_pages(BigNo_page)[1];
            }else if(get_open_direct() == 'R'){
                left_page_no = get_pre_pages(BigNo_page)[1];
                right_page_no = get_pre_pages(BigNo_page)[0];
            }
        }
    }
    set_left_page(left_page_no);
    set_right_page(right_page_no);
    req_page(left_page_no,right_page_no);
    //sx = 0の場合は左ページ表示中
    //singleモードの場合のヘルパー関数
    /*******************************************************
    singleモードの場合
    single_mode(xx)がページ遷移コード(proceed or reverse)の次の
    コードの位置では、うまく働かない。
    ページ遷移完了後に実行する必要がある。
    ***********************************************************/
    //singleモードで表示中のページがlargeNoかsmallNoかを判別する
    //左開きの場合。
    //sx = 0 && iframeのscrollLeft = 0 の時、smallNo
    //sx = 0 && iframeのscrollLeft != 0 または
    //sx !=0 && iframeのscrollLeft = 0 の時、smallNo

    /* ************* 連結ページの表示サイド判定 **************
    連結ページの表示サイド
    iframeが左に寄っている場合、連結ページの右側表示とする
    * ***************************************************/
    function get_iframe_posi(){
        if(document.getElementById("pageFrame_left").parentNode.scrollLeft >= get_iframe_int_width_under_sigle() * 0.9 || document.getElementById("pageFrame_right").parentNode.scrollLeft >= get_iframe_int_width_under_sigle() * 0.9){
            return "R";
        }else{
            return "L";
        }
    }
    /* ******* singleモードでのページ番号(big or small)判定 *******
    連結ページの表示サイド
    iframeが左に寄っている場合、連結ページの右側表示とする
    * ********************************************************/
    function get_isBigNoPage_under_single_mode(){
        if(get_open_direct() == 'L'){
            if(get_dbl_page_side() != ""){
                if(sx == 0 && get_iframe_posi() == "L"){
                    //alert("x1");
                    //return false;
                    if(get_reflow_mode()){
                        return false;
                    }else{
                        return true;
                    }
                }else if(sx == 0 && get_iframe_posi() == "R"){
                    //alert("x2");
                    //return true;
                    return false;
                }else if(sx != 0 && get_iframe_posi() == "L"){
                    //alert("x3");
                    return true;
                }
            }else if(get_dbl_page_side() == ""){
                if(sx == 0){
                    return false;
                }else{
                    return true;
                }
            }
        }else if(get_open_direct() == 'R'){
            if(get_dbl_page_side() != ""){
                if(sx == 0 && get_iframe_posi() == "L"){
                    return false;
                }else if(sx == 0 && get_iframe_posi() == "R"){
                    return false;
                }else if(sx != 0 && get_iframe_posi() == "L"){
                    return true;
                }
            }else if(get_dbl_page_side() == ""){
                if(get_reflow_mode()){
                    if(sx == 0){
                        return false;//true;
                    }else{
                        return true;//false;
                    }
                }else{
                    if(sx == 0){
                        return true;
                    }else{
                        return false;
                    }
                }
            }
        }
    }
}
//------  ------
/************************ req_page **************************
まず左ページをダウンロードし、
引数:Lpage(左ページ), Rpage(右ページ)
requestされたページを表示する。2画面
********************************************************** */
let rpg = "";
function req_page(Lpage,Rpage){
    /****************************************
    execution_flg:自動ページ送り実行中の場合true
    自動ページ送り実行中で無い場合、スピーチ中に
    ページ遷移する場合スピーチを終了させる。
    voice_trans_quitの引数にfalseが必要。
    ************************************** */
    if(!execution_flg) {
        //voice_trans_quit(false);
    }
    rpg = Rpage;
    get_elem_byId("page_trans_conver").style.display = "block";
    with(document.getElementById("pageFrame_left").contentDocument){
        getElementById("page_load").setAttribute("action","/materials/" + get_material_name() + "/" + Lpage + "/index.html")
        getElementById("key").value = get_material_name();
        getElementById("page_no").value = Lpage;
        getElementById("side").value = "L";
        getElementById("page_load").submit();
    }
}
function get_rpg(){
    return rpg;
}
function reset_rpg(){
    rpg = "";
}
function req_Rpage(){
    with(document.getElementById("pageFrame_right").contentDocument){
        getElementById("page_load").setAttribute("action","/materials/" + get_material_name() + "/" + rpg + "/index.html")
        getElementById("key").value = get_material_name();
        getElementById("page_no").value = rpg;//Rpage;
        getElementById("side").value = "R";             
        getElementById("page_load").submit();
    }
}

//page.jsからアクセス
function set_left_iframe_width(val){
    document.getElementById("pageFrame_left").style.width = val;
}
function get_left_iframe_width(){
    return document.getElementById("pageFrame_left").style.width;
}

function set_right_iframe_width(val){
    document.getElementById("pageFrame_right").style.width = val;
}
function get_right_iframe_width(){
    return document.getElementById("pageFrame_right").style.width;
}
//教材一覧ページの表示
let show_bookstocks = function(){
    window.parent.document.getElementById("disp_wide").style.display = "block";
    window.parent.document.getElementById("dsp_area").style.display = "none";
    //window.parent.adjust_dsp_size_under_dual_ipad_at_bookstocks();
    window.parent.document.getElementById("top_dsp_left").style.display = "";
    window.parent.document.getElementById("top_dsp_right").style.display = "";
    let elems = window.parent.document.getElementsByClassName("parts");
    for(i=0;i<elems.length;i++) {
        elems[i].style.visibility = "hidden";
    }
    adjust_dsp_size(); //初期化時の倍率に合わせる
    document.getElementById("adjust_dsp_size_crtl").style.color = "darkgrey";
    document.getElementById("adjust_dsp_size_crtl").disabled = true;
}
//目次ページの表示
let show_toc = function(){
    const left_page_no = trans_directed_page(get_toc_page());
}
//speech,paint,memoボタンの操作
const elems =document.getElementsByClassName("icon_btn");
for(i=0;i<elems.length;i++){
    elems[i].onclick = function(){
        for(j=0;j<elems.length;j++){
            elems[j].style.borderWidth = "3px";
        } 
        this.style.borderWidth = "8px";
        let val;
        document.getElementById("config_paint").style.display = "none";
        switch(this.id){
            case "speech_btn":
                mode = "speech";
                document.getElementById("pageFrame_left").contentWindow.set_layer(mode);
                document.getElementById("pageFrame_right").contentWindow.set_layer(mode);
                val = "blue";
                //document.getElementById("pageFrame_left").contentWindow.setHtmlTouchActionOn();
                //document.getElementById("pageFrame_right").contentWindow.setHtmlTouchActionOn();
                //reset_speech_ctrl_btn();
                if(get_dsp_mode() == "dual"){     
                    //get_elem_byId("speech_ctrl_btns").style.display = "";
                    get_elem_byId("speech_ctrl_btns2").style.display = "none";
                    reflect_vcbtn_side_change("");
                }else if(get_dsp_mode() == "single"){
                    //get_elem_byId("speech_ctrl_btns").style.display = "none";
                    get_elem_byId("speech_ctrl_btns2").style.display = "";
                    reflect_vcbtn_side_change("none");
                }
                break;
            case "paint_btn":
                mode = "paint";
                document.getElementById("pageFrame_left").contentWindow.set_layer(mode);
                document.getElementById("pageFrame_right").contentWindow.set_layer(mode);
                val = "red";
                //document.getElementById("pageFrame_left").contentWindow.setHtmlTouchActionOff();
                //document.getElementById("pageFrame_right").contentWindow.setHtmlTouchActionOff();
                document.getElementById("config_paint").style.display = "";
                if(get_dsp_mode() == "dual"){
                    document.getElementById("config_paint").style.left = "500px";
                }else if(get_dsp_mode() == "single"){
                    document.getElementById("config_paint").style.left = "190px";
                }
                $("#config_paint").draggable({});
                
                const drag = document.getElementById("config_paint");
                let drag_left;
                let drag_top;
                drag.addEventListener("touchstart", function(event) {
                    let resio;
                    if(get_dsp_mode() == "dual"){
                        resio = get_dual_ipad_resio();
                    }else if(get_dsp_mode() == "single"){
                        resio = get_single_ipad_resio();
                    }
                    drag_left = (event.targetTouches[0].pageX - $(this).offset().left)/resio;
                    drag_top = (event.targetTouches[0].pageY - $(this).offset().top)/resio;
                });
                drag.addEventListener("touchmove", function(event) {
                    let resio;
                    if(get_dsp_mode() == "dual"){
                        resio = get_dual_ipad_resio();
                    }else if(get_dsp_mode() == "single"){
                        resio = get_single_ipad_resio();
                    }
                    $(this).css({
                        "left" : event.targetTouches[0].pageX/resio - drag_left + "px", 
                        "top" :  event.targetTouches[0].pageY/resio - drag_top + "px",
                    });
                });

                get_elem_byId("speech_ctrl_btns").style.display = "none";
                get_elem_byId("speech_ctrl_btns2").style.display = "none";
            break;
            case "memo_btn":
                mode = "memo";
                document.getElementById("pageFrame_left").contentWindow.set_layer(mode);
                document.getElementById("pageFrame_right").contentWindow.set_layer(mode);
                //page.jsのメソッド実行--メモ追加
                document.getElementById("pageFrame_left").contentWindow.exec_memo();
                document.getElementById("pageFrame_right").contentWindow.exec_memo();

                val = "green";
                //document.getElementById("pageFrame_left").contentWindow.setHtmlTouchActionOff();
                //document.getElementById("pageFrame_right").contentWindow.setHtmlTouchActionOff();
                document.getElementById("speech_ctrl_btns").style.display = "none";
                //get_elem_byId("speech_ctrl_btns").style.display = "none";
                get_elem_byId("speech_ctrl_btns2").style.display = "none";
                reflect_vcbtn_side_change("none");
                break;
        }
        document.getElementById("disp_frame").style.borderColor = val;
        document.getElementById("save_btn_e").style.borderColor = val;
        document.getElementById("save_btn_w").style.borderColor = val;
    }
}
/* ****************** 自動ページ送り **********************
    子要素からspeechスタート
    (1) set_current_pageで、get_auto_page_changing_flgがtrueの場合、
        window.onloadで
            ページ番号 current_page_No
            ページサイド current_page_side
            大きいNo? current_page_isbigNo
            実行中? execution_flg = false;
        を登録する
    voicetrans.jsでspeech終了 auto_speech呼び出し
        execution_flg = trueの場合で、
            現状ページがbigNoでない場合(current_page_isbigNo = falseの場合)
                bigNo側のsortを指定してpre_voice_trans(sort,null,reflow_mode)実行
            現状ページがbigNoの場合(current_page_isbigNo = trueの場合)
                show_page("proceed")でページ遷移
                (1)が実行される
                execution_flg確認
                execution_flg = trueの場合、
                親要素からsmallNo側のsortを指定してpre_voice_trans(sort,null,reflow_mode)実行
************************************************ */
//set_current_page()で設定
let current_page_No;//speechしているページ番号
let current_page_side;//0:left, 1:right
let current_page_isbigNo;//true:big, false:small
let execution_flg = false;//自動ページ送り実行中の場合true
//子要素からもアクセスされるメソッド 自動ページ送り中 execution_flg = true
function isAutoPageExecution(){
    return execution_flg;
}
/* **************************************************************
auto_speech()終了
flg:
true(デフォルト設定値)の場合は、ページが開かれた状態でのauto_speech終了
falseの場合は、ページ遷移に伴うauto_speech終了の為、※1を実行する必要がない。
もし実行するとダウンロードのタイミングが合わずにエラーが発生する。
************************************************************** */
//
function set_execution_quit(flg){
    execution_flg = false;
    speech_flg = false;
    document.getSelection().removeAllRanges();
    if(!flg) return;
    //voice_trans_quit();
    document.getElementById("pageFrame_left").contentWindow.reset_speech_flg();//※1
    document.getElementById("pageFrame_right").contentWindow.reset_speech_flg();//※1
}
function reset_vspeech_flg(val){
    if(document.getElementById("pageFrame_left").contentWindow.set_vspeech_flg === undefined) return;
    document.getElementById("pageFrame_left").contentWindow.set_vspeech_flg(val);
    document.getElementById("pageFrame_right").contentWindow.set_vspeech_flg(val);
}

/******************************************************
子要素からアクセスされるメソッドwindow.onloadに実行。
オートページが指定されている場合、speechをしているページ番号
とページサイドを親要素に登録する。
current_page_isbigNoをauto_speech関数で参照する
val:ページ番号(int)
******************************************************/

function set_current_page(val){
    if(!auto_page_changing_flg) return;
    current_page_No = val + "";
    /*
    let trans_idx;

    const direct_array = get_page_numDirected_order_array();
    const array = get_page_order_array();
    if(direct_array.length != 0){
        for(v=0;v<direct_array.length;v++){
            const t_array = direct_array[v].split("-");
            if(t_array.indexOf(current_page_No) != -1){
                trans_idx = v;
                break;
            }
        }
    }else{
        trans_idx = array.indexOf(current_page_No);
    }
    */
    const array = get_page_order_array();
    const idx = array.indexOf(current_page_No);
    if(idx%2 == 0){
        if(get_dbl_page_side()!=""){
            current_page_isbigNo = true;  
        }else{
            current_page_isbigNo = false;  
        }
    }else{
        current_page_isbigNo = true;
    }
    if(val == get_left_page()){
        current_page_side = 0;//left
    }else{
        current_page_side = 1;//right
    }
    execution_flg = true;
}
/*****************************************************
自動ページ送り実行中の場合読み上げが終了した時点で、
voicetrans.jsから呼び出される。
*****************************************************/
function auto_speech(){
    //自動ページ送り実行中の場合true
    if(!execution_flg){
        const f = (current_page_side==0)?"pageFrame_left":"pageFrame_right";
        document.getElementById(f).contentWindow.reset_speech_flg();
        return;  
    }
    //left-sort=0,right-sort=1
    let sort;
    if(phrase_umu == "ari"){
        sort = (current_page_side==0)?1:0;
    }else{
        sort = (current_page_side==0)?7:6; 
    }
    if(current_page_isbigNo){
        //ページを進めてダウンロード後speech実行。
        show_pages("proceed");
        /*
        if(get_dbl_page_side()!="" && reflow_mode){
            pre_voice_trans(sort,null,reflow_mode);
        }
        */
    //smallNoページのspeech実行。
    }else{
        if(get_dsp_mode() == "single" && !reflow_mode && get_dbl_page_side() == ""){
            if(get_open_direct() == 'L'){   
                get_elem_byId("dsp_area").scrollLeft = get_iframe_int_width_under_sigle();
            }else{
                get_elem_byId("dsp_area").scrollLeft = 0;
            }
        }
        //リフローの切替
        if(get_dsp_mode() == "single" && reflow_mode && get_dbl_page_side() == ""){
            if(get_open_direct() == 'L'){
                show_reflow(null,"R");
            }else{
                show_reflow(null,"L");
            }
        }
        if(get_dsp_mode() == "dual" && reflow_mode){
            if(get_open_direct() == 'L'){
                show_reflow(null,"R");
            }else{
                show_reflow(null,"L");
            }        }
        //リフローモードの場合proceedしてpre_voice_trans実行。
        //if(reflow_mode){
            //document.getElementById("dsp_area").scrollLeft = get_iframe_int_width_under_sigle();
        //}
        //if(get_dsp_mode() == "single"){
            //get_elem_byId("pageFrame_left").parentNode.style.width = get_iframe_int_width_under_sigle();
        //}

        //largeNoページをspeechするように設定する
        current_page_isbigNo = true;
        pre_voice_trans(sort,null,reflow_mode)
    }
}
/*******************************************************
 自動ページ送りが設定されている場合、ページ要素のwindow.onload
 から呼び出される。自動ページ送り実行中の場合、ページダウンロード後
 speech実行。
 val:ページ番号(int)
****************************************************** */
function execute_auto_speech(val){
    current_page_No = val + "";
    /*
    let trans_idx;

    const direct_array = get_page_numDirected_order_array();
    const array = get_page_order_array();
    if(direct_array.length != 0){
        for(v=0;v<direct_array.length;v++){
            const t_array = direct_array[v].split("-");
            if(t_array.indexOf(current_page_No) != -1){
                trans_idx = v;
                break;
            }
        }
    }else{
        trans_idx = array.indexOf(current_page_No);
    }
    */
    const array = get_page_order_array();
    const idx = array.indexOf(current_page_No);
    /*************************************************
    ページがbigNoの場合return。
    voicetrans.jsからauto_speech呼び出され
    show_pages("proceed")が実行される。
    *************************************************/
    if(idx%2 != 0) return;
    //ページがsmallNoの場合
    set_current_page(val);
    /*************************************************
    自動ページ送り実行中の場合、ページダウンロード後speech実行
    *************************************************/
    if(execution_flg){
        let sort;
        if(phrase_umu == "ari"){
            sort = current_page_side;
        }else{
            sort = (current_page_side==0)?6:7; 
        }
        pre_voice_trans(sort,null,reflow_mode)
    }
}
//let reset_speech_ctrl_btn = function(){
$(".speech_pause_btn").on("click",function(event){
    //音枠再生中はpauseを無効にする
    if(get_otowaku_flg()) return;
    //if(isAutoPageExecution()) return;
    let pre_voice_trans_arg1;
    if(current_page_No == get_left_page()){
        if(window.parent.get_phrase_umu() == "ari"){
            pre_voice_trans_arg1 = 0;
        }else{
            pre_voice_trans_arg1 = 6;
        }
    }else{
        if(window.parent.get_phrase_umu() == "ari"){
            pre_voice_trans_arg1 = 1;
        }else{
            pre_voice_trans_arg1 = 7;
        }
    }
    if(speech_flg){
        voice_trans_pause();
        this.style.color = "red";
        speech_flg = false;        
    }else{
        this.style.color = "";
        speech_flg = true;
        if(get_phrase_ari_short_flg() && getPauseFlg()){
            window.parent.voice_trans_restart();
            return;
        }
        pre_voice_trans(pre_voice_trans_arg1,"",reflow_mode);           
    }
    //オートページが指定されている場合、speechをしているページ番号を親要素に登録する
    if(get_auto_page_changing_flg){
        set_current_page(current_page_No);
    }
    event.stopPropagation();
});
/*
let speech_quit_btn = function(event){
        set_execution_quit();
        voice_trans_quit();
        if(event != null) event.stopPropagation();
}
*/
$(".speech_quit_btn").on("click",function(event){
    set_execution_quit();
    voice_trans_quit();
    voice_trans_quit();
    event.stopPropagation();    
});
//}
/*
function remove_nodes(){
    const block = document.getElementById("fingerspell_block");
    //const stock = document.getElementById("stock_spell_img");
    while( block.firstChild ){
        block.removeChild( block.firstChild );
        //stock.appendChild(block.firstChild);
    }
    block.style.display = "none";
}
*/
let show_speech_frame_flg = false;
function get_show_speech_frame_flg(){
    return show_speech_frame_flg;
}
function set_show_speech_frame_flg(val){
    show_speech_frame_flg = val;
}

let show_speech_frame = function(){
    if(show_speech_frame_flg){
        document.getElementById("pageFrame_left").contentWindow.show_speech_frame();
        document.getElementById("pageFrame_right").contentWindow.show_speech_frame();
        show_speech_frame_flg = false;
    }else{
        document.getElementById("pageFrame_left").contentWindow.hide_speech_frame();
        document.getElementById("pageFrame_right").contentWindow.hide_speech_frame();
        show_speech_frame_flg = true;
    }
}
let adjust_dsp_size_crtl = function(val){
    get_elem_byId('config_btn').onclick();
    let elems = document.getElementsByClassName("parts");
    if(val.classList.contains("circle_btn_w_active")){
        document.getElementById("adjust_disp_size_big").style.display = "";
        document.getElementById("adjust_disp_size_small").style.display = "";
        for(let i=0;i<elems.length;i++) {
            elems[i].style.visibility = "hidden";
        }       
    }else{
        document.getElementById("adjust_disp_size_big").style.display = "none";
        document.getElementById("adjust_disp_size_small").style.display = "none";
        for(let i=0;i<elems.length;i++) {
            elems[i].style.visibility = "visible";
        }
    }
}
let adjust_disp_size_big = function(){
    const elem_h = document.getElementById("h_adjst_ate");
    const elem_v = document.getElementById("v_adjst_ate");
    if(isTouchValid()){
        if(get_orientation()=="yoko"){
            elem_h.value = Number(elem_h.value) + 0.01 + "";
            reflect_h_adjst(elem_h);
        }else{
            elem_v.value = Number(elem_v.value) + 0.01 + "";
            reflect_v_adjst(elem_v);
        }
    }else{
        elem_h.value = Number(elem_h.value) + 0.01 + "";
        reflect_h_adjst(elem_h);
    }
}
let adjust_disp_size_small = function(){
    const elem_h = document.getElementById("h_adjst_ate");
    const elem_v = document.getElementById("v_adjst_ate");
    if(isTouchValid()){
        if(get_orientation()=="yoko"){
            elem_h.value = Number(elem_h.value) - 0.01 + "";
            reflect_h_adjst(elem_h);
        }else{
            elem_v.value = Number(elem_v.value) - 0.01 + "";
            reflect_v_adjst(elem_v);
        }
    }else{
        elem_h.value = Number(elem_h.value) - 0.01 + "";
        reflect_h_adjst(elem_h);
    }
}
