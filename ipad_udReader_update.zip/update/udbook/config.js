//********************** 基本設定画面を表示する ************************
let page_dsp_flg = false; //ページが開いている時 true
let dsp_frame_boderColor;
let show_config_dsp = function(val){
    const elems = document.getElementsByClassName("parts");
    //設定画面を開く
    if(val.classList.contains("circle_btn_w_active")){
        get_elem_byId("setting_screen").style.display = "block";
        dsp_frame_boderColor = document.getElementById("disp_frame").style.borderColor;
        //WIDE画面が開いていない場合
        if(get_elem_byId("disp_wide").style.display == "none"){
            get_elem_byId("dsp_area").style.display = "none";
            //get_elem_byId("disp_right").style.display = "none";
            get_elem_byId("disp_wide").style.display = "block";
            get_elem_byId("stocks_frame").style.display = "none";
            page_dsp_flg = true;
        //WIDE画面が開いている場合
        }else{
            get_elem_byId("stocks_frame").style.display = "none";
            get_elem_byId("dsp_area").style.display = "none";
            //get_elem_byId("disp_right").style.display = "none";
            page_dsp_flg = false;
        }
        for(i=0;i<elems.length;i++) {
            elems[i].style.visibility = "hidden";
        }
        document.getElementById("disp_frame").style.borderColor = "silver";
    //基本設定画面を閉じる
    }else{
        get_elem_byId("setting_screen").style.display = "none";
        //WIDE画面が開いている場合
        if(get_elem_byId("disp_wide").style.display != "none"){                            
            if(get_elem_byId("stocks_frame").style.display == "none" && !page_dsp_flg){
                get_elem_byId("stocks_frame").style.display = "block";
                get_elem_byId("disp_wide").style.display = "block";

            }else if(get_elem_byId("stocks_frame").style.display == "none" && page_dsp_flg){ 
                get_elem_byId("stocks_frame").style.display = "block";
                get_elem_byId("disp_wide").style.display = "none";
                get_elem_byId("dsp_area").style.display = "";
                if(document.getElementById("adjust_dsp_size_crtl").classList.contains("circle_btn_w_active")){
                    document.getElementById("adjust_disp_size_big").style.display = "";
                    document.getElementById("adjust_disp_size_small").style.display = "";            
                }else{
                    for(i=0;i<elems.length;i++) {
                        elems[i].style.visibility = "visible";
                    }
                }
            }
        }
        document.getElementById("disp_frame").style.borderColor = dsp_frame_boderColor;
    }
    document.getElementById("import_screen").style.display = "none";               
}


//基本設定値の読み込みと設定
const configure = function(){
    const req = new XMLHttpRequest(),
    method = "GET",
    file = "/config.txt";
    req.open(method, file, false);//同期通信
    req.onreadystatechange = function () {
        if(req.readyState === 4 && req.status === 200) {
            let rest = req.responseText.replace(/\r?\n/g,"");
            if(rest == "") rest = "{}";
            const obj = JSON.parse(rest);
            set_furigana_umu(obj.furigana_umu);
            set_furigana_umu_rf(obj.furigana_umu_rf);
            set_furigana_umu_prf(obj.furigana_umu_prf);
            set_furigana_sort(obj.furigana_sort);
            set_font_sort(obj.font_sort);
            set_font_color(obj.font_color);
            set_font_color_rf(obj.font_color_rf);
            //set_noun_color(obj.noun_color);
            //set_verb_color(obj.verb_color);
            set_back_rayer_color(obj.back_rayer_color);
            set_reflow_dsp_side(obj.reflow_dsp_side);
            set_reflow_font_size(obj.reflow_font_size);
            set_reflow_line_height(obj.reflow_line_height);
            set_reflow_writing_mode(obj.reflow_writing_mode);
            //set_yubimoji_umu(obj.yubimoji_umu);
            //set_yubimoji_posi(obj.yubimoji_posi)
            set_auto_page_changing(obj.auto_page);
            set_speech_speed(obj.speech_speed);
            set_speech_pitch(obj.speech_pitch);
            set_speech_volume(obj.speech_volume);

            set_h_adjst(obj.s_h_adjst);
            set_v_adjst(obj.s_v_adjst);

            set_highlight_color(obj.highlight_color)
            set_highlight_color_rf(obj.highlight_color_rf)
            set_phrase_umu(obj.phrase_umu);
            set_narrator(obj.narrator);
            set_vcbtn_side_change(obj.vcbtn_side)
            if(obj["timer"] != undefined) set_timer_on_off(obj.timer_on_off,obj["timer"][0],obj["timer"][1]);
        }
    };
    req.send();
}
//教材別設定値(SDATA)の読み込みと設定
let open_direct;//教科書を捲る方向
let toc_page;//目次のページ番号
let book_page_array;//教科書のページ情報
let margin_top;//文字の位置調整用。上側マージン
let margin_left;//文字の位置調整用。左側マージン
let book_img_zoom;//教科書画像の縮小率
let read_last_pageNo;//ラップに表示するページ番号
let first_page;
let last_page;
let page_order_array;
let page_numDirected_order_array = [];
let iframe_width;
let single_reflow_mode_iframe_width;
let iframe_height_under_dual2 = 900;
let frame_height_under_sigle;

let left_page;//左ページのページ番号
let right_page;//右ページのページ番号
let str_wrap;//文字囲するか、しないか
//let page_1_side;//1ページの位置 L or R
//const vacant_page = "S0";//requestページが無い場合に表示するページ記号
//let int_virtuali_first_page;//例)S1,S2,1の場合 -1,0,1となり、-1ページからスタートと解釈する
//let int_virtuali_last_page;//例)S1,S2,1,90,E1,E2の場合、1,90,91,92となり、92が最終ページと解釈する
//let iframe_default_width;
//------ ページ情報を各変数に格納する -------
function set_sdata(val){
    const obj = JSON.parse(val);
    open_direct = obj.open_direct;
    toc_page = obj.toc_page;
    margin_top = obj.margin_top;
    margin_left = obj.margin_left;
    book_img_zoom = obj.book_img_zoom;
    iframe_width = obj.iframe_width;
    single_reflow_mode_iframe_width = obj.single_reflow_mode_iframe_width;
    frame_height_under_sigle = obj.frame_height_under_single;
    iframe_height_under_dual2 = 900;//obj.iframe_height_under_dual;
    str_wrap = obj.str_wrap;
    set_size_con(iframe_width + "px",single_reflow_mode_iframe_width + "px",frame_height_under_sigle + "px",iframe_height_under_dual2 + "px");
    //page_order_array = obj.data;
    //first_page = page_order_array[0];
    //last_page = page_order_array[page_order_array.length - 1];
    //iframe_width = 642;//642,675
    //iframe_default_width = obj.iframe_width;
    //arrange_for_each_mode.jsの変数の値設定
    //page_1_side = obj.page_1_side;
    //book_page_array = obj.book_page;
    //last_page = book_page_array[book_page_array.indexOf("1") + 1];
    //int_virtuali_first_page = (book_page_array.indexOf("1") - 1) * (-1);
    //int_virtuali_last_page = book_page_array.length - (book_page_array.indexOf("1") + 2) + Number(last_page);
}

function set_page_order(val){
    const obj = JSON.parse(val);
    page_order_array = obj.data;
    first_page = page_order_array[0];
    last_page = page_order_array[page_order_array.length - 1];
}
function set_page_numDirected_order(val){
    const obj = JSON.parse(val);
    page_numDirected_order_array = obj.data;
}

function get_page_order_array(){
    return page_order_array;
}
function get_page_numDirected_order_array(){
    return page_numDirected_order_array;
}
function get_iframe_width(){
    return iframe_width + "px";
}
function get_sgrfmd_iframe_width(){
    return single_reflow_mode_iframe_width + "px";
}
function get_str_wrap(){
    if(str_wrap == undefined){
        return "ari";
    }else{
        return str_wrap;
    }
}
/*
function get_iframe_int_width(){
    return iframe_width;
}
function get_iframe_dbl_width(){
    return iframe_width*2 + "px";
}

function get_sgmd_iframe_width(){
    return single_reflow_mode_iframe_width * 2 + "px";
}
function get_sgmd_iframe_int_width(){
    return single_reflow_mode_iframe_width * 2;
}
function get_sgrfmd_iframe_dbl_width(){
    return single_reflow_mode_iframe_width * 2 + "px";
}
*/

//single化の際にiframe_widthを書き換える
/*
function set_iframe_int_width(val){
    iframe_width = val;
}
function get_iframe_default_int_width(){
    return iframe_default_width;
}
function get_iframe_default_width(){
    return iframe_default_width + "px";
}
function get_iframe_default_dbl_width(){
    return iframe_default_width*2 + "px";

}
*/
//
//------ ページ情報の設定と取得メソッド。子要素からのアクセスを考慮し関数化 -------
function get_first_page(){
    return first_page;
}
function get_last_page(){
    return last_page;
}
function get_last_number_page(){
    for (let i = page_order_array.length - 1; i >= 0 ; i--){
        if(!isNaN(page_order_array[i])){
            return page_order_array[i];
        }
    }
}
/*
function get_vacant_page(){
    return vacant_page;
}
*/
function set_read_last_pageNo(val){
    read_last_pageNo = val;
}
function get_read_last_pageNo(){
    return read_last_pageNo;
}
function set_left_page(val){
    left_page = val;
}
function set_right_page(val){
    right_page = val;
}
function get_left_page(){
    return left_page;
}
function get_right_page(){
    return right_page;
}
function get_toc_page(){
    return toc_page;
}
function get_open_direct(){
    return open_direct;
}
function get_margin_top(){
    return margin_top;
}
function get_margin_left(){
    return margin_left;
}
function get_book_img_zoom(){
    return book_img_zoom;
}
function get_book_page_array(){
    return book_page_array;
}
//**************** 基本設定のsetterとgetterメソッド(view_ctrl.jsからアクセス)******************

/*====================================================
ルビ要素の取得
get_strctrl_elems("div"):本文のルビ要素
get_strctrl_elems("exdiv"):リフローのルビ要素
====================================================*/
let get_strctrl_elems = function(id_prefix = "both"){
    const StrCtrl = document.getElementsByClassName("StrCtrl");
    let rt_array = [];
    for(s1=0;s1<StrCtrl.length;s1++){
        if(id_prefix == "both"){
            const temp_rt = StrCtrl[s1].getElementsByTagName("rt");
            for(r1=0;r1<temp_rt.length;r1++){
                rt_array.push(temp_rt[r1]);
            }
        }else{
            if(StrCtrl[s1].id.startsWith(id_prefix)){
                const temp_rt = StrCtrl[s1].getElementsByTagName("rt");
                for(r2=0;r2<temp_rt.length;r2++){
                    rt_array.push(temp_rt[r2]);
                }
            }
        }
    }
    return rt_array;
}
//const rt_elems = document.getElementsByTagName("rt");
let furigana_umu = "ari";
function get_furigana_umu(){
    return furigana_umu;
}
function set_furigana_umu(val){
    if(val != undefined) furigana_umu = val;
    let rt_elems = get_strctrl_elems("div");
    if(furigana_umu=="ari"){
        for(i=0;i<rt_elems.length;i++){
            rt_elems[i].style.display = "";
            //rt_elems[i].style.visibility = "visible";
        }
    }else{
        for(i=0;i<rt_elems.length;i++){
            rt_elems[i].style.display = "none";
            //rt_elems[i].style.visibility = "hidden";
        }
    }
    if(furigana_umu == "ari"){
        get_elem_byId("frigana_ari").checked = true;
        get_elem_byId("frigana_nasi").checked = false;

    }else{
        get_elem_byId("frigana_ari").checked = false;
        get_elem_byId("frigana_nasi").checked = true;
    }
}

let furigana_umu_rf = "ari";
function get_furigana_umu_rf(){
    return furigana_umu_rf;
}
function set_furigana_umu_rf(val){
    if(val != undefined) furigana_umu_rf = val;
    let rt_elems_rf = get_strctrl_elems("exdiv");
    if(furigana_umu_rf=="ari"){
        for(i=0;i<rt_elems_rf.length;i++){
            rt_elems_rf[i].style.visibility = "visible";
        }
    }else{
        for(i=0;i<rt_elems_rf.length;i++){
            rt_elems_rf[i].style.visibility = "hidden";
        }
    }
    if(furigana_umu_rf == "ari"){
        get_elem_byId("frigana_ari_rf").checked = true;
        get_elem_byId("frigana_nasi_rf").checked = false;

    }else{
        get_elem_byId("frigana_ari_rf").checked = false;
        get_elem_byId("frigana_nasi_rf").checked = true;
    }
}
let furigana_umu_prf = "ari";
function get_furigana_umu_prf(){
    return furigana_umu_prf;
}
function set_furigana_umu_prf(val){
    //let rt_elems_prf = get_strctrl_elems("exdiv");
    if(val != undefined) furigana_umu_prf = val;
    /*
    if(val=="ari"){
        for(i=0;i<rt_elems_prf.length;i++){
            rt_elems_prf[i].style.visibility = "visible";
        }
    }else{
        for(i=0;i<rt_elems_prf.length;i++){
            rt_elems_prf[i].style.visibility = "hidden";
        }
    */
    if(furigana_umu_prf == "ari"){
        get_elem_byId("frigana_ari_prf").checked = true;
        get_elem_byId("frigana_nasi_prf").checked = false;

    }else{
        get_elem_byId("frigana_ari_prf").checked = false;
        get_elem_byId("frigana_nasi_prf").checked = true;
    }
}

//------ フリガナ種類(カタカナ・ひらがな)の設定 -------
let furigana_sort = "katakana";
function get_furigana_sort(){
    return furigana_sort;
}
function set_furigana_sort(val){
    if(val != undefined) furigana_sort = val;
    let rt_elems = get_strctrl_elems();    
    if(furigana_sort=="katakana"){
        for(i=0;i<rt_elems.length;i++){
            rt_elems[i].innerHTML = rt_elems[i].innerHTML.replace(/[\u3041-\u3096]/g, function(match) {
            var chr = match.charCodeAt(0) + 0x60;
            return String.fromCharCode(chr);
            });
        }
    //カタカナをひらがに
    }else{
        for(i=0;i<rt_elems.length;i++){
            rt_elems[i].innerHTML = rt_elems[i].innerHTML.replace(/[\u30a1-\u30f6]/g, function(match) {
            var chr = match.charCodeAt(0) - 0x60;
            return String.fromCharCode(chr);
            });
        }
    }
    if(furigana_sort == "katakana"){
        get_elem_byId("frigana_katakana").checked = true;
        get_elem_byId("frigana_hiragana").checked = false;
    }else{
        get_elem_byId("frigana_katakana").checked = false;
        get_elem_byId("frigana_hiragana").checked = true;
    }
}
//------ フォント(serif・gothic)の設定 -------
let font_sort = "serif";
function get_font_sort(){
    return font_sort;
}
function set_font_sort(val){
    if(val != undefined) font_sort = val;
    document.getElementById("setting_text").style.fontFamily = font_sort;
    if(font_sort == "serif"){
        get_elem_byId("honbun_minchyo").checked = true;
        get_elem_byId("honbun_gothic").checked = false;
    }else{
        get_elem_byId("honbun_minchyo").checked = false;
        get_elem_byId("honbun_gothic").checked = true;
    }
}
//------ 文字色の設定 -------
let font_color = "#000000";
function get_font_color(){
    return font_color;
}
function set_font_color(val){
    if(val != undefined) font_color = val;
    //get_elem_byId("setting_text").style.color = val;
    get_elem_byId("font_color").value = font_color;
}
//------ 文字色の設定(リフロー) -------
let font_color_rf = "#000000";
function get_font_color_rf(){
    return font_color_rf;
}
function set_font_color_rf(val){
    if(val != undefined) font_color_rf = val;
    get_elem_byId("setting_text").style.color = font_color_rf;
    get_elem_byId("font_color_rf").value = font_color_rf;

}//------ 名詞の文字色の設定 -------
let noun_color= "#000000";
function get_noun_color(){
    return noun_color;
}
function set_noun_color(val){
    if(val != undefined) noun_color= val;
    const noun_elems = document.getElementsByClassName("noun");
    for(i=0;i<noun_elems.length;i++){
        noun_elems[i].style.color = noun_color;
    }
    get_elem_byId("noun_color").value = noun_color;
}

//------ 動詞の文字色の設定 -------
let verb_color= "#000000";
function get_verb_color(){
    return verb_color;
}
function set_verb_color(val){
    if(val != undefined) verb_color= val;
    const verb_elems = document.getElementsByClassName("verb");
    for(i=0;i<verb_elems.length;i++){
        verb_elems[i].style.color = verb_color;
    }
    get_elem_byId("verb_color").value = verb_color;
}

//------ リフロー背景色の設定 -------
let back_rayer_color= "#ffffff";
function get_back_rayer_color(){
    return back_rayer_color;
}
function set_back_rayer_color(val){
    if(val != undefined) back_rayer_color= val;
    get_elem_byId("back_rayer").style.backgroundColor = back_rayer_color;
    get_elem_byId("back_rayer_color").value = back_rayer_color;
    document.getElementsByClassName("div_frame")[0].style.backgroundColor = back_rayer_color;
    document.getElementsByClassName("div_frame")[1].style.backgroundColor = back_rayer_color;

}
//------ リフローフォントサイズの設定 -------
let reflow_font_size = "3";//idx
function set_reflow_font_size(idx){
    if(idx != undefined) reflow_font_size = idx;
    const elem = get_elem_byId("reflow_font_size");
    elem.options[reflow_font_size].selected = true;
    const s =  elem.options[elem.selectedIndex].value;
    $(".div_frame span").css("font-size",s);
}
let reflow_line_height = "5";
function set_reflow_line_height(idx){
    if(idx != undefined) reflow_line_height = idx;
    const elem = get_elem_byId("reflow_line_height");
    elem.options[reflow_line_height].selected = true;
    const s =  elem.options[elem.selectedIndex].value;
    $(".div_frame span").css("line-height",s);
}
let set_current_reflow_font_size = function(){
    const elem = get_elem_byId("reflow_font_size");
    const s =  elem.options[reflow_font_size].value;
    $(".div_frame span").css("font-size",s);
}
//------ リフロー画面表示位置の設定 -------
let reflow_dsp_side = "L";//L, R
    //子要素から参照しないのでgetterメソッド無し
function set_reflow_dsp_side(val){
    if(val != undefined) reflow_dsp_side = val;
    if(reflow_dsp_side == "L"){
        get_elem_byId("reflow_dsp_left").checked = true;
        get_elem_byId("reflow_dsp_right").checked = false;

    }else{
        get_elem_byId("reflow_dsp_left").checked = false;
        get_elem_byId("reflow_dsp_right").checked = true;
    }
}
//------ リフロー表示モードの設定 -------
let reflow_writing_mode = "V"; //H, V
    //子要素から参照しないのでgetterメソッド無し
function set_reflow_writing_mode(val){
    if(val != undefined) reflow_writing_mode = val;
    if(reflow_writing_mode == "H"){
        get_elem_byId("horizontal").checked = true;
        get_elem_byId("vertical").checked = false;

    }else{
        get_elem_byId("horizontal").checked = false;
        get_elem_byId("vertical").checked = true;
    }
    if(reflow_writing_mode == "H"){
        document.getElementsByClassName("div_frame")[0].classList.toggle('StrCtrl_v2');
        document.getElementsByClassName("div_frame")[1].classList.toggle('StrCtrl_v2');
    }
}
//------ 指文字有無の設定 -------
/*
let yubimoji_umu = "nasi";
    //子要素から参照しないのでgetterメソッド無し

function set_yubimoji_umu(val){
    yubimoji_umu = val;
    if(val == "ari"){
        get_elem_byId("yubimoji_ari").checked = true;
        get_elem_byId("yubimoji_nasi").checked = false;

    }else{
        get_elem_byId("yubimoji_ari").checked = false;
        get_elem_byId("yubimoji_nasi").checked = true;
    }
}
*/
//------ 指文字表示位置の設定 -------
/*
let yubimoji_posi = "bottom";
//子要素から参照しないのでgetterメソッド無し
function set_yubimoji_posi(val){
    yubimoji_posi = val;
    if(val == "bottom"){
        get_elem_byId("yubimoji_bottom").checked = true;
        get_elem_byId("yubimoji_side").checked = false;

    }else{
        get_elem_byId("yubimoji_bottom").checked = false;
        get_elem_byId("yubimoji_side").checked = true;
    }
}
*/
//------ 自動ページ送りon-offの設定 -------
let auto_page_changing_flg = false;
function get_auto_page_changing_flg(){
    return auto_page_changing_flg;
}
function set_auto_page_changing(val){
    if(val != undefined) auto_page_changing_flg = val;
    if(auto_page_changing_flg == true){
        get_elem_byId("auto_page_change_on").checked = true;
        get_elem_byId("auto_page_change_off").checked = false;

    }else{
        get_elem_byId("auto_page_change_on").checked = false;
        get_elem_byId("auto_page_change_off").checked = true;
    }
}
//------ スピーチ速度の設定 -------
let speech_speed = "1.0";
function set_speech_speed(val){
    if(val != undefined) speech_speed = val;
    get_elem_byId("voice_trans_speed_ate").value = speech_speed;
    get_elem_byId("speech_speed").value = speech_speed;
    set_voice_speech_rate(speech_speed);
}
//------ ピッチの設定 -------
let speech_pitch = "1.0";
function set_speech_pitch(val){
    if(val != undefined) speech_pitch = val;
    get_elem_byId("voice_trans_pitch_ate").value = speech_pitch;
    get_elem_byId("speech_pitch").value = speech_pitch;
    set_voice_speech_pitch(speech_pitch);
}
//------ 音量の設定 -------
let speech_volume = "1.0";
function set_speech_volume(val){
    if(val != undefined) speech_volume = val;
    get_elem_byId("voice_trans_volume_ate").value = speech_volume;
    get_elem_byId("speech_volume").value = speech_volume;
    set_voice_speech_volume(speech_volume);
}
//------ ハイライトカラーの設定(固定) -------
let highlight_color = "#f5ec00";
function set_highlight_color(val){
    if(val != undefined) highlight_color = val;
    get_elem_byId("highlight_color").value = highlight_color;
    set_voice_highlight_color(highlight_color);
}
//------ ハイライトカラーの設定(リフロー) -------
let highlight_color_rf = "#f5ec00";
function set_highlight_color_rf(val){
    if(val != undefined) highlight_color_rf = val;
    get_elem_byId("highlight_color_rf").value = highlight_color_rf;
    set_voice_highlight_color_rf(highlight_color_rf);
}
//------ 分節有無の設定 -------
let phrase_umu = "ari"
function get_phrase_umu(){
    return phrase_umu;
}
function set_phrase_umu(val){
    if(val != undefined) phrase_umu = val;
    if(phrase_umu == "ari"){
        get_elem_byId("phrase_ari").checked = true;
        get_elem_byId("phrase_ari_short").checked = false;
        get_elem_byId("phrase_nasi").checked = false;
        set_phrase_ari_short_flg(false);
    }else if(phrase_umu == "ari_short"){
        get_elem_byId("phrase_ari").checked = false;
        get_elem_byId("phrase_ari_short").checked = true;
        get_elem_byId("phrase_nasi").checked = false;
        set_phrase_ari_short_flg(true);
    }else{
        get_elem_byId("phrase_ari").checked = false;
        get_elem_byId("phrase_ari_short").checked = false;
        get_elem_byId("phrase_nasi").checked = true;
        set_phrase_ari_short_flg(false);
    }
}
//------ ナレーターの設定 -------
let narrator = 0;
function set_narrator(idx){
    if(idx != undefined) narrator = idx;
    get_elem_byId("voice-select").options[narrator].selected = true;
}

let vcbtn_side = "vc_C"
let set_vcbtn_side_change = function(val){
    if(val != undefined) vcbtn_side = val;
    switch(vcbtn_side){
        case "vc_L":
            get_elem_byId("vc_L").checked = true;
            get_elem_byId("vc_C").checked = false;
            get_elem_byId("vc_R").checked = false;
                break;
        case "vc_C":
            get_elem_byId("vc_L").checked = false;
            get_elem_byId("vc_C").checked = true;
            get_elem_byId("vc_R").checked = false;
            break;
        case "vc_R":
            get_elem_byId("vc_L").checked = false;
            get_elem_byId("vc_C").checked = false;
            get_elem_byId("vc_R").checked = true;
            break;
    }
}

//------ タイマーの設定 -------
timer_on_off = "off";
function get_timer_on_off(){
    return timer_on_off;
}
function set_timer_on_off(val,h,s){
    if(val != undefined) timer_on_off = val;
    if(timer_on_off == "on"){
        get_elem_byId("timer_on").checked = true;
        get_elem_byId("timer_off").checked = false;
        const vh = get_elem_byId("timer_hour");
        const vs = get_elem_byId("timer_second")
        const txt = vh.options[Number(h)].innerHTML + "時間" + vs.options[Number(s)].innerHTML + "分";
        set_timer(vh.options[Number(h)].value,vs.options[Number(s)].value,txt);
    }else{
        get_elem_byId("timer_on").checked = false;
        get_elem_byId("timer_off").checked = true;
    }
    get_elem_byId("timer_hour").options[Number(h)].selected = true;
    get_elem_byId("timer_second").options[Number(s)].selected = true;
}
//------ 画面サイズの反映 -------
let s_h_adjst = "0.4";
let set_h_adjst = function(val){
    if(val != undefined) s_h_adjst = val;
    get_elem_byId("h_adjst_ate").value = s_h_adjst;
    set_adjst_resio_dual_pc(Number(s_h_adjst)-0.4);
    set_adjst_resio_sigle_pc(Number(s_h_adjst)-0.4);
}
let s_v_adjst = "0.4";
let set_v_adjst = function(val){
    if(val != undefined) s_v_adjst = val;
    get_elem_byId("v_adjst_ate").value = s_v_adjst;
    set_adjst_resio_dual_ipad(Number(s_v_adjst)-0.4);
    set_adjst_resio_sigle_ipad(Number(s_v_adjst)-0.4);
}

//基本設定更新反映メソッド
//------ フリガナ有無の反映 -------
let reflect_furigana_umu = function(val){
    let rt_elems = get_strctrl_elems("div");
    if(val.id=="frigana_ari" && val.checked){
        for(i=0;i<rt_elems.length;i++){
            rt_elems[i].style.display = "";
            //rt_elems[i].style.visibility = "visible";  
        }
        furigana_umu = "ari";
    }else{
        for(i=0;i<rt_elems.length;i++){
            rt_elems[i].style.display = "none";
            //rt_elems[i].style.visibility = "hidden";
        }
        furigana_umu = "nasi";
    }
    reflect_config();
}
//------ フリガナ有無の反映(リフロー) -------
let reflect_furigana_umu_rf = function(val){
    let rt_elems_rf = get_strctrl_elems("exdiv");    
    if(val.id=="frigana_ari_rf" && val.checked){
        for(i=0;i<rt_elems_rf.length;i++){
            rt_elems_rf[i].style.visibility = "visible";
        }
        furigana_umu_rf = "ari";
    }else{
        for(i=0;i<rt_elems_rf.length;i++){
            rt_elems_rf[i].style.visibility = "hidden";
        }
        furigana_umu_rf = "nasi";
    }
    reflect_config();
}

//------ フリガナ有無の反映(窓リフロー) -------
let reflect_furigana_umu_prf = function(val){
    //let rt_elems_rf = get_strctrl_elems("exdiv");    
    if(val.id=="frigana_ari_prf" && val.checked){
        /*
        for(i=0;i<rt_elems_rf.length;i++){
            rt_elems_rf[i].style.visibility = "visible";
        }
        */
        furigana_umu_prf = "ari";
    }else{
        /*
        for(i=0;i<rt_elems_rf.length;i++){
            rt_elems_rf[i].style.visibility = "hidden";
        }
        */
        furigana_umu_prf = "nasi";
    }
    reflect_config();
}
//------ フリガナ種類(カタカナ・ひらがな)の反映 -------
let reflect_furigana_sort = function(val){
    let rt_elems = get_strctrl_elems();    
    //ひらがをカタカナに
    if(val.id=="frigana_katakana" && val.checked){
        for(i=0;i<rt_elems.length;i++){
            rt_elems[i].innerHTML = rt_elems[i].innerHTML.replace(/[\u3041-\u3096]/g, function(match) {
            var chr = match.charCodeAt(0) + 0x60;
            return String.fromCharCode(chr);
            });
        }
        furigana_sort = "katakana";
    //カタカナをひらがに
    }else{
        for(i=0;i<rt_elems.length;i++){
            rt_elems[i].innerHTML = rt_elems[i].innerHTML.replace(/[\u30a1-\u30f6]/g, function(match) {
            var chr = match.charCodeAt(0) - 0x60;
            return String.fromCharCode(chr);
            });
        }
        furigana_sort = "hiragana";
    }
    reflect_config();
}
//------ フォント(serif・gothic)の反映 -------
let reflect_font_sort = function(val){
    if(val.id=="honbun_minchyo" && val.checked){
        document.getElementById("setting_text").style.fontFamily = "serif";
        font_sort = "serif";
    }else{
        document.getElementById("setting_text").style.fontFamily = "sans-serif";
        font_sort = "sans-serif";
    }
    //リフローへの反映
    const StrCtrl_elems = document.getElementsByClassName("StrCtrl");
    for(i=0;i<StrCtrl_elems.length;i++){
        StrCtrl_elems[i].style.fontFamily = font_sort;
    }
    reflect_config();
}
//------ 文字色の反映(固定) -------
let reflect_font_color = function(val){
    //document.getElementById("setting_text").style.color = val.value;
    const p_elems = document.getElementsByTagName("span");
    for(i=0;i<p_elems.length;i++){
        p_elems[i].style.color = val.value;
    }
    font_color = val.value;
    reflect_config();
}
//------ 文字色の反映(リフロー) -------
let reflect_font_color_rf = function(val){
    document.getElementById("setting_text").style.color = val.value;
    const StrCtrl_elems = document.getElementsByClassName("StrCtrl");
    for(i=0;i<StrCtrl_elems.length;i++){
        if(StrCtrl_elems[i].id.startsWith("exdiv")){
            const p_elems = StrCtrl_elems[i].getElementsByTagName("span");
            for(j=0;j<p_elems.length;j++){
                p_elems[j].style.color = val.value;
            }
        }
    }
    font_color_rf = val.value;
    //reflect_config();page.jsへの反映は不要
}
//------ 名詞の文字色の反映 -------
let reflect_noun_color = function(val){
    const noun_elems = document.getElementsByClassName("noun");
    for(i=0;i<noun_elems.length;i++){
        noun_elems[i].style.color = val.value;
    }
    noun_color = val.value;
    reflect_config();
}
//------ 動詞の文字色の反映 -------
let reflect_verb_color = function(val){
    const noun_elems = document.getElementsByClassName("verb");
    for(i=0;i<noun_elems.length;i++){
        noun_elems[i].style.color = val.value;
    }
    verb_color = val.value;
    reflect_config();
}
//------ 背景色の反映 -------
let reflect_back_rayer_color = function(val){
    document.getElementById("back_rayer").style.backgroundColor = val.value;
    document.getElementsByClassName("div_frame")[0].style.backgroundColor = val.value;
    document.getElementsByClassName("div_frame")[1].style.backgroundColor = val.value;
    back_rayer_color = val.value;
}
//------ リフローフォントサイズの反映 -------
let reflect_reflow_font_size = function(){
    const elem = get_elem_byId("reflow_font_size");
    const s =  elem.options[elem.selectedIndex].value;
    reflow_font_size = elem.selectedIndex;
    $(".div_frame span").css("font-size",s);
    //document.getElementsByClassName("div_frame")[0].getElementsByTagName("span").style.fontSize = s;
    //document.getElementsByClassName("div_frame")[1].getElementsByTagName("span").style.fontSize = s;
}
//------ リフロー余白の反映 -------
let reflect_reflow_line_height = function(){
    const elem1 = get_elem_byId("reflow_font_size");
    const s1 =  elem1.options[elem1.selectedIndex].textContent;
    const elem2 = get_elem_byId("reflow_line_height");
    const s2 =  elem2.options[elem2.selectedIndex].textContent;
    const s = Number(s1.replace("px","")) + Number(s2.replace("px","")) + "px";
    reflow_line_height = elem2.selectedIndex;
    $(".div_frame span").css("line-height",s);
    //document.getElementsByClassName("div_frame")[0].getElementsByTagName("span").style.fontSize = s;
    //document.getElementsByClassName("div_frame")[1].getElementsByTagName("span").style.fontSize = s;
}
//------ リフロー表示位置の反映  -------
let reflect_reflow_dsp_side = function(val){
    if(val.id=="reflow_dsp_left" && val.checked){
        reflow_dsp_side = "L";
    }else{
        reflow_dsp_side = "R";
    }
    close_reflow();//view_ctrl.js
    get_elem_byId("divFrame_left").innerHTML = "";
    get_elem_byId("divFrame_right").innerHTML = "";
}
//------ リフローの表示モードの反映  -------
let reflect_reflow_writing_mode = function(val){
    if(reflow_writing_mode != val){
        document.getElementsByClassName("div_frame")[0].classList.toggle('StrCtrl_v2');
        document.getElementsByClassName("div_frame")[1].classList.toggle('StrCtrl_v2');
    }
    if(val.id=="vertical" && val.checked){
        reflow_writing_mode = "V";
    }else{
        reflow_writing_mode = "H";
    }
}
//------ 自動ページ送りon-0ffの反映  -------
let reflect_auto_page_change = function(val){
    if(val.id == "auto_page_change_on"){
        auto_page_changing_flg = true;
    }else{
        auto_page_changing_flg = false;
    }
    set_execution_quit();
}
//------ 指文字有無の反映 -------
/*
let reflect_yubimoji_umu = function(val){
    if(val.id == "yubimoji_ari"){
        yubimoji_umu = "ari";
    }else{
        yubimoji_umu = "nasi";
    }
}
*/
//------ 指文字表示位置の反映 -------
/*
let reflect_yubimoji_posi = function(val){
    if(val.id == "yubimoji_bottom"){
        yubimoji_posi = "bottom";
    }else{
        yubimoji_posi = "side";
    }
}
*/
//------ スピーチ速度の反映 -------
let reflect_speech_speed = function(val){
    speech_speed = val.value;
    set_voice_speech_rate(speech_speed);
    get_elem_byId("speech_speed").value = val.value;
}
//------ ピッチの反映 -------
let reflect_speech_pitch = function(val){
    speech_pitch = val.value;
    set_voice_speech_pitch(speech_pitch);
    get_elem_byId("speech_pitch").value = val.value;
}
//------ 音量の反映 -------
let reflect_speech_volume = function(val){
    speech_volume = val.value;
    set_voice_speech_volume(speech_volume);
    get_elem_byId("speech_volume").value = val.value;
}

let reflect_highlight_color = function(val){
    highlight_color = val.value;
    set_voice_highlight_color(highlight_color);
}

let reflect_highlight_color_rf = function(val){
    highlight_color_rf = val.value;
    set_voice_highlight_color_rf(highlight_color_rf);
}
//------ 分節区切り有無の反映  -------
let reflect_phrase_umu = function(val){
    set_phrase_ari_short_flg(false);
    if(val.id == "phrase_ari"){
        phrase_umu = "ari";
    }else if(val.id == "phrase_ari_short"){
        phrase_umu = "ari_short";
        set_phrase_ari_short_flg(true);
    }else{
        phrase_umu = "nasi";
    }
    //リフローモードで反映させる場合、リフロー状態の再設定が必要。
    if(get_reflow_mode()) show_reflow(null,get_reflow_frame_side());
    reflect_config();
}
//------ ナレーターの反映 -------
let reflect_narrator = function(val){
    narrator = val.selectedIndex;
    set_voice();
}
let reflect_vcbtn_side_change = function(val){
    get_elem_byId("speech_ctrl_btns").style.display = "none";
    get_elem_byId("speech_ctrl_btns_L").style.display = "none";
    get_elem_byId("speech_ctrl_btns_R").style.display = "none";
    get_elem_byId("speech_ctrl_btns2").style.display = "none";
    let top_under_dual = iframe_height_under_dual2 - 50 + "px"
    let top_under_dual_C = iframe_height_under_dual2 - 160 + "px"
    let top_under_single = frame_height_under_sigle - 50 + "px"
    get_elem_byId("speech_ctrl_btns").style.top = top_under_dual_C;
    get_elem_byId("speech_ctrl_btns_L").style.top = top_under_dual;
    get_elem_byId("speech_ctrl_btns_R").style.top = top_under_dual;
    get_elem_byId("speech_ctrl_btns2").style.top = top_under_single;
    if(val == "") val = vcbtn_side;
    if(get_dsp_mode() == "dual"){
        switch(val){
            case "vc_L":
                get_elem_byId("speech_ctrl_btns_L").style.display = "";
                get_elem_byId("vcbtn_posi_under_single").style.marginLeft = "0px";
                vcbtn_side = "vc_L";
                break;
            case "vc_C":
                get_elem_byId("speech_ctrl_btns").style.display = "";
                get_elem_byId("vcbtn_posi_under_single").style.marginLeft = "215px";
                vcbtn_side = "vc_C";
                break;
            case "vc_R":
                get_elem_byId("vcbtn_posi_under_single").style.marginLeft = "400px";
                get_elem_byId("speech_ctrl_btns_R").style.display = "";
                vcbtn_side = "vc_R";
                break;
        }
    }else if(get_dsp_mode() == "single"){
        switch(val){
            case "vc_L":
                get_elem_byId("vcbtn_posi_under_single").style.marginLeft = "0px";
                vcbtn_side = "vc_L";
                break;
            case "vc_C":
                get_elem_byId("vcbtn_posi_under_single").style.marginLeft = "215px";
                vcbtn_side = "vc_C";
                break;
            case "vc_R":
                get_elem_byId("vcbtn_posi_under_single").style.marginLeft = "400px";
                vcbtn_side = "vc_R";
                break;
        }
        if(get_reflow_mode()){
            get_elem_byId("speech_ctrl_btns2").style.top = trans_num(iframe_height_under_sigle_reflow) - 50 + "px";
        }
        get_elem_byId("speech_ctrl_btns2").style.display = "";
    }
}


//------ タイマーの反映 -------
let my_timer;
let set_timer =function(h,s,text){
    if(h=="0" && s=="0") return;
    time = (Number(h) + Number(s)) * 60000;
    my_timer = setTimeout(() => show_reg_info(text + "経過しました!",'timer'),time);
}
let clear_timer = function(){
    clearTimeout(my_timer);
}
let reflect_set_timer = function(val){
    if(val.id == "timer_on"){
        timer_on_off = "on";
        const h = get_elem_byId("timer_hour");
        const s = get_elem_byId("timer_second")
        const txt = h.options[h.selectedIndex].innerHTML + "時間" + s.options[s.selectedIndex].innerHTML + "分";
        set_timer(h.options[h.selectedIndex].value,s.options[s.selectedIndex].value,txt);
    }else{
        timer_on_off = "off";
        clear_timer();
    }
}
let reflect_set_timer2 = function(){
    //get_elem_byId("timer_on").checked = false;
    //get_elem_byId("timer_off").checked = true;
    clear_timer();
}
//------ 画面サイズの反映 -------
function reflect_h_adjst(val){
    s_h_adjst = val.value;
    set_adjst_resio_dual_pc(Number(val.value) - 0.4);
    set_adjst_resio_sigle_pc(Number(val.value - 0.4));
    adjust_dsp();
}
//縦置きの場合でipadのみ適用可能
function reflect_v_adjst(val){
    s_v_adjst = val.value;
    set_adjst_resio_dual_ipad(Number(val.value) - 0.4);
    set_adjst_resio_sigle_ipad(Number(val.value) - 0.4);
    adjust_dsp();
}

let font_color_undo = function(){
    //リフローのフォント色undo
    const strctrl_elem = document.getElementsByClassName("StrCtrl");
    for(i=0;i<strctrl_elem.length;i++){
        strctrl_elem[i].style.color = "";
    }
    const verb_elems = document.getElementsByClassName("verb");
    for(i=0;i<verb_elems.length;i++){
        verb_elems[i].style.color = "";
    }
    const noun_elems = document.getElementsByClassName("noun");
    for(i=0;i<noun_elems.length;i++){
        noun_elems[i].style.color = "";
    }
    const p_elems = document.getElementsByTagName("span");
    for(i=0;i<p_elems.length;i++){
        p_elems[i].style.color = "black";
    }
    //基本設定画面への反映
    font_color = "";
    get_elem_byId("font_color").value = "#000000";
    noun_color = "";
    get_elem_byId("noun_color").value = "#000000";
    verb_color = "";
    get_elem_byId("verb_color").value = "#000000";
    reflect_config();
}
//------ 表示中のページへのの反映(page.jsのメソッド呼び出し) -------
let reflect_config = function(){
    document.getElementById("pageFrame_left").contentWindow.set_page_config();
    document.getElementById("pageFrame_right").contentWindow.set_page_config();
}
//------ 反映された最新情報の保存 -------
let reg_config = function(){
    let ss = '"timer_on_off":"' + timer_on_off + '","timer":["' + get_elem_byId("timer_hour").selectedIndex + '","' + get_elem_byId("timer_second").selectedIndex + '"]';
    let data = {key2:"set_config",memo_str:'{"furigana_umu":"'+ furigana_umu + '","furigana_umu_rf":"'+ furigana_umu_rf + '","furigana_umu_prf":"'+ furigana_umu_prf + '","furigana_sort":"'+ furigana_sort + '","font_sort":"'+ font_sort +'","font_color":"'+ font_color +'","font_color_rf":"'+ font_color_rf +'","noun_color":"'+ noun_color +'","verb_color":"'+ verb_color +'","back_rayer_color":"'+ back_rayer_color + '","reflow_font_size":"'+ reflow_font_size + '","reflow_line_height":"'+ reflow_line_height + '","speech_speed":"'+ speech_speed + '","speech_pitch":"'+ speech_pitch + '","speech_volume":"'+ speech_volume + '","s_h_adjst":"' + s_h_adjst + '","s_v_adjst":"' + s_v_adjst  +'","highlight_color":"'+ highlight_color +'","highlight_color_rf":"'+ highlight_color_rf +'","phrase_umu":"'+ phrase_umu +'","reflow_writing_mode":"'+ reflow_writing_mode +'","auto_page":'+ auto_page_changing_flg +',"reflow_dsp_side":"'+ reflow_dsp_side +'","vcbtn_side":"'+ vcbtn_side +'","narrator":'+ narrator + ',' + ss + '}'};
    //var data = key:{ param1: 'abc', param2: 100 }; // POSTメソッドで送信するデータ
    var xmlHttpRequest = new XMLHttpRequest();
    xmlHttpRequest.onreadystatechange = function()
    {
        var READYSTATE_COMPLETED = 4;
        var HTTP_STATUS_OK = 200;
        if( this.readyState == READYSTATE_COMPLETED
        && this.status == HTTP_STATUS_OK )
        {
            // レスポンスの表示
            show_reg_info("保存しました。");
            //alert("保存しました。");
        }
    }
    xmlHttpRequest.open( 'POST', 'http://localhost:8080', false);
    // サーバに対して解析方法を指定する
    xmlHttpRequest.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );
    // データをリクエスト ボディに含めて送信する
    xmlHttpRequest.send( EncodeHTMLForm( data ) ); 
    // HTMLフォームの形式にデータを変換する
}
function EncodeHTMLForm( data )
{
    var params = [];
    for( var name in data )
    {
        var value = data[ name ];
        var param = encodeURIComponent( name ) + '=' + encodeURIComponent( value );
        params.push( param );
    }
    return params.join( '&' ).replace( /%20/g, '+' );
}
//教材のインポート
const mt_import = function(){
    document.getElementById("setting_screen").style.display = "none";
    document.getElementById("import_screen").style.display = "";
    //window.open('../import.html', 'ctxmenu', 'top=100,left=300,width=700,height=500,location=no');
}
//教材のインポート中止
function qt_import(){
    document.getElementById("setting_screen").style.display = "";
    document.getElementById("import_screen").style.display = "none";
}
function mate_refresh(){
    window.location.reload(true);
}
