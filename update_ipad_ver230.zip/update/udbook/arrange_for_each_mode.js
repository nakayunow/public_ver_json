/* *******************************************************
対象componentは以下の5つ
html表示
    wrap_iframe
    iframe_left
    iframe_right
reflow表示
    reflow_area_left
    reflowa_area_right

モードは以下の3つ
dual
single

定数
iframe_width_under_dual
iframe_width_under_sigle
iframe_width_under_sigle_reflow

iframe_height_under_dual
iframe_height_under_sigle
iframe_height_under_sigle_reflow

reflow_area_width_under_dual
reflow_area_width_under_sigle_reflow

reflow_area_height_under_dual
reflow_area_height_under_sigle_reflow

******************************************************* */

const dsp_area = get_elem_byId("dsp_area");
const page_frame = get_elem_byId("page_frame");
const divFrame_left = get_elem_byId("divFrame_left");
const divFrame_right = get_elem_byId("divFrame_right");
const pageFrame_left = get_elem_byId("pageFrame_left");
const pageFrame_right = get_elem_byId("pageFrame_right");

let dsp_mode = "dual";
//page.jsからもアクセスあり
function get_dsp_mode(){
    return dsp_mode;
}
let trans_num = function(val){
    return Number(val.replace("px",""));
}
let trans_dbl = function(val){
    return Number(val.replace("px","")) * 2 + "px";
}
let add_size = function(con,delta){
    return (Number(con.replace("px","")) + delta) + "px";
}
let trans_scale = function(con,scale){
    return (Number(con.replace("px","")) * scale) + "px";
}
//エレメントのオブジェクト化
let wrap_iframe = {elem:page_frame,left :"0px",top:"0px", width: "0px" ,height:"0px"};
let iframe_left = {elem:pageFrame_left,left :"",top:"", width: "0px" ,height:"0px"};
let iframe_right = {elem:pageFrame_right,left :"",top:"", width: "0px" ,height:"0px"};
let reflow_area_left = {elem:divFrame_left,left :"0px",top:"0px",width: "0px" ,height:"0px"};
let reflow_area_right = {elem:divFrame_right,left :"0px",top:"0px", width: "0px" ,height:"0px"};
/******************************************************
定数設定 以下の定数をconfig.jsで設定する
iframe_width_under_dual:見開きページモードでの単ページ巾
iframe_width_under_sigle_reflow:単ページモードでの単ページ巾
iframe_height_under_dual:見開きページモードでの単ページ高さ(830px固定 + 10px)
iframe_height_under_sigle:単ページモードでの単ページ高さ(830px固定 + 10px)
Frame_height_under_sigle:単ページモードでのフレーム高さ
**************************************************** */

let iframe_width_under_sigle_reflow;
let iframe_width_under_dual= "642px"; //udBookを読み込んだ時に使用。
let Frame_height_under_sigle;
let iframe_width_under_sigle;
let single_dual_resio;
let iframe_height_under_sigle_reflow;
let reflow_area_width_under_dual;
let reflow_area_width_under_sigle_reflow;
let reflow_area_height_under_dual;
let reflow_area_height_under_sigle_reflow;
let iframe_height_under_dual;
//config.jsからアクセス
function set_size_con(val1,val2,val3,val4){
    iframe_width_under_dual = val1;//"642px";
    iframe_width_under_sigle_reflow = val2;//"321px";
    Frame_height_under_sigle = val3;
    iframe_width_under_sigle = trans_dbl(iframe_width_under_sigle_reflow);
    single_dual_resio = trans_num(iframe_width_under_sigle_reflow)/trans_num(iframe_width_under_sigle);
    iframe_height_under_sigle_reflow = trans_num(iframe_height_under_sigle)*single_dual_resio * 1.1 + "px";//(830 * 321/642) + "px";
    reflow_area_width_under_dual = iframe_width_under_dual;
    reflow_area_width_under_sigle_reflow = iframe_width_under_sigle_reflow;
    reflow_area_height_under_dual = iframe_height_under_dual;
    reflow_area_height_under_sigle_reflow = (trans_num(Frame_height_under_sigle) * 0.967 - trans_num(iframe_height_under_sigle_reflow)) + "px";
    iframe_height_under_dual = val4;
}

//const iframe_height_under_dual = "840px";
const iframe_height_under_sigle = "830px";

//view_ctrl.jsからアクセス
function get_iframe_int_width_under_sigle(){
    return trans_num(iframe_width_under_sigle);
}
function get_iframe_int_width_under_dual(){
    return trans_num(iframe_width_under_dual);
}

function get_iframe_int_height_under_sigle(){
    return trans_num(iframe_height_under_sigle);
}
const set_style_in_comp = function(val){
    if(val.left != "") val.elem.style.left = val.left;
    if(val.top != "") val.elem.style.top = val.top;
    if(val.width != "") val.elem.style.width = val.width;
    if(val.height != "") val.elem.style.height = val.height;
}
let reflow_state = {dsp_side:"L",read_page_side:"L"}
let set_reflow_read_side = function(read_page_side){
    reflow_state.read_page_side = read_page_side;
}
/* *****************************************************
    single→sigle reflow→single
    contact_dammy_page(dammy,html_width)をcall backする
        dammy:L-左ページダミー R-右ページダミー ""-ダミー無し
        html_width:documentElementのwidth
***************************************************** */
let adjust_html_size = function(){
    if(get_open_direct() == "L"){
        document.getElementById("pageFrame_left").contentWindow.get_contact();
        document.getElementById("pageFrame_right").contentWindow.get_contact();
    }else{
        document.getElementById("pageFrame_right").contentWindow.get_contact();
        document.getElementById("pageFrame_left").contentWindow.get_contact();
    }
}
let reset_iframe_size_for_mode = function(){
    if(dsp_mode == "dual"){
        iframe_left.width = iframe_width_under_dual;
        iframe_right.width = iframe_width_under_dual;
    }else if(dsp_mode == "single"){
        if(get_reflow_mode()){
            iframe_left.width = iframe_width_under_sigle_reflow;
            iframe_right.width = iframe_width_under_sigle_reflow;
        }else{
            iframe_left.width = trans_dbl(iframe_width_under_sigle_reflow);
            iframe_right.width = trans_dbl(iframe_width_under_sigle_reflow);
        }
    }
}
/*********************************************
                singleモード
******************************************* */
let single_mode_flg = false;
//reflow_flg:reflow表示の場合trueでv_reflow_stateはnullでないのでリフロー処理に向かう
function set_style_under_single(v_reflow_state = null,reflow_flg = false){
    //トグルで切り替え
    if(single_mode_flg && !reflow_flg){
        single_mode_flg = false;
        set_reflow_mode(false);
        reset_reflow_btn(); 
        dsp_mode = "dual";
        set_style_under_dual();
        //singleからdualへの切り替え時に必要な場合があり為
        dsp_area.scrollLeft = 0;
        $(".sp_btn1").css("visibility","visible");
        adjust_html_size();
        document.getElementById("save_btn_w").style.display = "";
        return;
    }
    dsp_mode = "single";
    single_mode_flg = true;
    reflow_area_left.top = iframe_height_under_sigle_reflow;
    reflow_area_right.top =  iframe_height_under_sigle_reflow;
    //dualからsingleへの切り替え時に必要な場合があり為
    get_elem_byId("pageFrame_left").parentNode.style.width = "";
    get_elem_byId("pageFrame_right").parentNode.style.width = "";
    //get_elem_byId("speech_ctrl_btns").style.display = "none";
    //get_elem_byId("speech_ctrl_btns2").style.display = "";
    $(".sp_btn1").css("visibility","visible");
    
    get_elem_byId("pageFrame_left").parentNode.style.height = "";
    get_elem_byId("pageFrame_right").parentNode.style.height = "";
    
    document.getElementById("save_btn_w").style.display = "none";
    //リフローモードでない場合   
    if(v_reflow_state == null){
        //get_elem_byId("speech_ctrl_btns2").style.top = "900px"
        reflect_vcbtn_side_change("");
        //スクロールバー表示
        get_elem_byId("pageFrame_left").parentNode.style.width = get_iframe_int_width_under_sigle() + "px";
        get_elem_byId("pageFrame_right").parentNode.style.width = get_iframe_int_width_under_sigle() + "px";
        reset_reflow_btn();
        set_reflow_mode(false);
        wrap_iframe.left = "0px";
        reflow_area_left.left = "-" + add_size(iframe_width_under_dual,100);
        reflow_area_right.left =  add_size(trans_dbl(iframe_width_under_dual),100);
        reflow_area_left.width = iframe_width_under_dual;
        reflow_area_left.height = iframe_height_under_dual;
        reflow_area_right.width =  iframe_width_under_dual;                     
        reflow_area_right.height =  iframe_height_under_dual;            
        dsp_area.style.width = iframe_width_under_sigle;
        dsp_area.style.height = Frame_height_under_sigle;//iframe_height_under_sigle;
        iframe_left.width = trans_dbl(iframe_width_under_sigle_reflow);
        iframe_left.height = iframe_height_under_dual;
        iframe_right.width = trans_dbl(iframe_width_under_sigle_reflow);
        iframe_right.height = iframe_height_under_dual;
        set_style_in_comp(reflow_area_left);
        set_style_in_comp(reflow_area_right);
        set_style_in_comp(wrap_iframe); 
        set_style_in_comp(iframe_left); 
        set_style_in_comp(iframe_right);
        if(isTouchValid()){
            if(get_orientation()=="yoko"){
                adjust_dsp_size_under_single();  
            }else{
                adjust_dsp_size_under_single_ipad();
            }   
        }else{
            adjust_dsp_size_under_single();
        }   
        adjust_html_size();

        //単ページだが画像が連結されてサイズアップしている場合-2022-5-21追加
        const img_elem = document.getElementById("pageFrame_left").contentDocument.getElementById("image");
        const img_n_width = img_elem.naturalWidth * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
        const img_n_height = img_elem.naturalHeight * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
        if(img_n_width > get_iframe_int_width_under_sigle() * 1.5){
            const resio = get_iframe_int_height_under_sigle()/img_n_height;
            const v = "scale(" + resio + "," + resio + ")";
            document.getElementById("pageFrame_left").contentWindow.set_body_transform(v,resio);
            get_elem_byId("pageFrame_left").parentNode.style.width = get_iframe_int_width_under_sigle() + "px";
            document.getElementById("pageFrame_left").style.width = img_n_width + "px";
        }

        return;
    }
    //リフローモードの場合
    document.getElementById("save_btn_w").style.display = "";

    wrap_iframe.left = "0px";
    dsp_area.scrollLeft = 0; 
    get_elem_byId("speech_ctrl_btns2").style.top = trans_num(iframe_height_under_sigle_reflow) - 50 + "px";
    get_elem_byId("pageFrame_left").parentNode.style.width = "";
    get_elem_byId("pageFrame_right").parentNode.style.width = "";
    if(v_reflow_state.dsp_side == "L" && v_reflow_state.read_page_side == "L"){
        reflow_area_left.left = "0px";
        reflow_area_right.left =  trans_dbl(iframe_width_under_dual);       
        divFrame_left.scrollLeft = 1000;  
    }else if(v_reflow_state.dsp_side == "L" && v_reflow_state.read_page_side == "R"){
        reflow_area_left.left = "-" + add_size(iframe_width_under_dual,100);
        reflow_area_right.left = "0px";      
        divFrame_right.scrollLeft = 1000;  
    }else if(v_reflow_state.dsp_side == "R" && v_reflow_state.read_page_side == "L"){
        reflow_area_left.left = "0px"; 
        reflow_area_right.left =  trans_dbl(iframe_width_under_dual); 
        divFrame_left.scrollLeft = 1000;  
    }else if(v_reflow_state.dsp_side == "R" && v_reflow_state.read_page_side == "R"){
        reflow_area_left.left = "-" + add_size(iframe_width_under_dual,100);
        reflow_area_right.left = "0px";
        divFrame_right.scrollLeft = 1000;               
    }
    dsp_area.style.width = trans_dbl(iframe_width_under_sigle_reflow);
    //dsp_area.style.height = iframe_height_under_sigle;
    dsp_area.style.height = Frame_height_under_sigle;
    reflow_area_left.width = trans_scale(trans_dbl(iframe_width_under_sigle_reflow),0.93);
    reflow_area_left.height = reflow_area_height_under_sigle_reflow
    reflow_area_right.width =  trans_scale(trans_dbl(iframe_width_under_sigle_reflow),0.93);          
    reflow_area_right.height = reflow_area_height_under_sigle_reflow;
    iframe_left.width = iframe_width_under_sigle_reflow;
    iframe_left.height = iframe_height_under_sigle_reflow;
    iframe_right.width = iframe_width_under_sigle_reflow;
    iframe_right.height = iframe_height_under_sigle_reflow;
    set_style_in_comp(reflow_area_left);
    set_style_in_comp(reflow_area_right);
    set_style_in_comp(wrap_iframe);
    set_style_in_comp(iframe_left);
    set_style_in_comp(iframe_right);
    adjust_html_size();
}
/*********************************************
                dualモード
******************************************* */
function set_style_under_dual(v_reflow_state = null){
    
    reflow_area_left.top = "0px";  
    reflow_area_right.top =  "0px";
    iframe_left.width = iframe_width_under_dual;
    iframe_left.height = iframe_height_under_dual;
    iframe_right.width = iframe_width_under_dual;
    iframe_right.height = iframe_height_under_dual;
    //get_elem_byId("speech_ctrl_btns").style.display = "";
    reflect_vcbtn_side_change("");
    //教材が既に選択済でモードが変更された時に実行される
    if(!get_selected_material_flg()){
        if(isTouchValid()){
            if(get_orientation()=="yoko"){
                adjust_dsp_size_under_dual()
            }else{
                adjust_dsp_size_under_dual_ipad();
            }        }else{
            adjust_dsp_size_under_dual();
        }
    }
    //get_elem_byId("speech_ctrl_btns2").style.display = "none";
    get_elem_byId("pageFrame_left").parentNode.style.width = "";
    get_elem_byId("pageFrame_left").parentNode.style.height = "";
    get_elem_byId("pageFrame_right").parentNode.style.width = "";
    get_elem_byId("pageFrame_right").parentNode.style.height = "";
    dsp_area.style.height = trans_num(iframe_height_under_dual) + 20 + "px";
    //リフローモードでない場合
    if(v_reflow_state == null){
        wrap_iframe.left = "0px";
        reflow_area_left.left = "-" + add_size(iframe_width_under_dual,100);
        reflow_area_right.left =  trans_dbl(iframe_width_under_dual);

        dsp_area.style.width = trans_dbl(iframe_width_under_dual);
        //dsp_area.style.height = iframe_height_under_dual;
        reflow_area_left.width = iframe_width_under_dual;
        reflow_area_left.height = iframe_height_under_dual;
        reflow_area_right.width =  iframe_width_under_dual;                     
        reflow_area_right.height =  iframe_height_under_dual;
        set_style_in_comp(reflow_area_left);
        set_style_in_comp(reflow_area_right);
        set_style_in_comp(wrap_iframe);
        set_style_in_comp(iframe_left);
        set_style_in_comp(iframe_right);
        adjust_html_size();
        
        return;
    //リフローモードの場合
    }else{
        //リフローが左表示で左ページを読む場合

        get_elem_byId("pageFrame_left").parentNode.style.width = iframe_width_under_dual;
        get_elem_byId("pageFrame_left").parentNode.style.height = trans_num(iframe_height_under_dual) + 20 + "px";
        get_elem_byId("pageFrame_right").parentNode.style.width = iframe_width_under_dual;          
        get_elem_byId("pageFrame_right").parentNode.style.height = trans_num(iframe_height_under_dual) + 20 + "px";
        if(v_reflow_state.dsp_side == "L" && v_reflow_state.read_page_side == "L"){

            wrap_iframe.left = iframe_width_under_dual;
            reflow_area_left.left = "0px";
            reflow_area_right.left =  trans_dbl(iframe_width_under_dual); 
            divFrame_left.scrollLeft = 1000;  
            //リフローが左表示で右ページを読む場合
        }else if(v_reflow_state.dsp_side == "L" && v_reflow_state.read_page_side == "R"){

            wrap_iframe.left = "0px";
            reflow_area_left.left = "-" + add_size(iframe_width_under_dual,100);
            reflow_area_right.left =  "0px";
            divFrame_right.scrollLeft = 1000;  
        //リフローが右表示で左ページを読む場合
        }else if(v_reflow_state.dsp_side == "R" && v_reflow_state.read_page_side == "L"){
            wrap_iframe.left = "0px";
            reflow_area_left.left = iframe_width_under_dual;
            reflow_area_right.left =  trans_dbl(iframe_width_under_dual);
            divFrame_left.scrollLeft = 1000;  
            //リフローが右表示で右ページを読む場合
        }else if(v_reflow_state.dsp_side == "R" && v_reflow_state.read_page_side == "R"){
            wrap_iframe.left = "-" + iframe_width_under_dual;
            reflow_area_left.left = "-" + add_size(iframe_width_under_dual,100);
            reflow_area_right.left = iframe_width_under_dual; 
            divFrame_right.scrollLeft = 1000;                      
        }
    }
    dsp_area.style.width = trans_dbl(iframe_width_under_dual);
    //dsp_area.style.height = iframe_height_under_dual;
    reflow_area_left.width = trans_scale(iframe_width_under_dual,0.93);
    reflow_area_left.height = iframe_height_under_dual;
    reflow_area_right.width =  trans_scale(iframe_width_under_dual,0.93);                     
    reflow_area_right.height =  iframe_height_under_dual;
    set_style_in_comp(reflow_area_left);
    set_style_in_comp(reflow_area_right);
    set_style_in_comp(wrap_iframe);
    set_style_in_comp(iframe_left);
    set_style_in_comp(iframe_right);
    adjust_html_size();       
}
let dsp_reflow = function(val){
    reflow_state.dsp_side = reflow_dsp_side;//config.js
    reflow_state.read_page_side = val;
    if(dsp_mode == "dual"){
        set_style_under_dual(reflow_state);
    }else if(dsp_mode = "single"){
        set_style_under_single(reflow_state, true);
    }
    //リフロー表示中は書庫・目次表示・ページジャンプのボタンは非表示にする。
    $(".sp_btn1").css("visibility","hidden");
}
let hide_reflow = function(){
    if(dsp_mode == "dual"){
        set_style_under_dual();
        //get_elem_byId("pageFrame_left").parentNode.style.width = "";
        //get_elem_byId("pageFrame_right").parentNode.style.width = "";
        if(get_open_direct() == "R" && get_dbl_page_side() == "R"){
            iframe_right.width = trans_dbl(iframe_right.width);
            iframe_left.width = "0px";
            get_elem_byId("page_frame").style.scrollLeft = 100;
        }



    }else if(dsp_mode = "single"){
        set_style_under_single(null,true);
    }
    $(".sp_btn1").css("visibility","visible");
}
//page.jsからアクセス
let dammy_null_ct = 0;
let call_ct = 0;
let dbl_page_side = "";
let glb_dammy = "";
function get_dbl_page_side(){
    return dbl_page_side;
}
function set_dbl_page_side(val){
    dbl_page_side = "";
}
function get_glb_dammy(){
    return glb_dammy;
}
/* *************************************************
page.jsから呼び出される
dammy:左ページがダミーの場合=L,右ページがダミーの場合=R
html_width:ページ幅

stock.html
set_style_under_dual()
req_page()

page.js
contact_dammy_page(dammy,html_width)

************************************************* */
function contact_dammy_page(dammy,html_width){
//ダミーページの処理
    let resio;
    let v;
    let img_n_width = 10000;
    let img_elem;
    //dammy == ""の処理は2回目の受信で実行する
    get_elem_byId("pageFrame_left").parentNode.style.width = "";
    get_elem_byId("pageFrame_left").parentNode.style.height = "";
    get_elem_byId("pageFrame_right").parentNode.style.width = "";
    get_elem_byId("pageFrame_right").parentNode.style.height = "";
    document.getElementById("pageFrame_left").parentNode.style.backgroundColor = "";
    document.getElementById("pageFrame_right").parentNode.style.backgroundColor = "";
    switch(dammy){
        //左ページがdammyの場合、左のiframeのwidthを0pxにして非表示にし、右側のiframeのwidthを倍にする。
        case "L":
            glb_dammy = "L";
            iframe_left.width = "0px";
            iframe_right.width = trans_dbl(iframe_right.width);
            dbl_page_side = "R";
            img_elem = document.getElementById("pageFrame_right").contentDocument.getElementById("image");
            if(img_elem == null){
                resio = trans_num(iframe_right.width)/html_width;
            }else{
                img_n_width = img_elem.naturalWidth * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
                resio = trans_num(iframe_right.width)/img_n_width;
            }
            //jpegのサイズがシングルサイズの場合でも連結ページの場合がある為
            if(img_n_width < trans_num(iframe_right.width) * 0.8){
                resio = trans_num(iframe_right.width)/html_width;
            }
            v = "scale(" + resio + "," + resio + ")";
            document.getElementById("pageFrame_right").contentWindow.set_body_transform(v,resio);
            document.getElementById("save_btn_w").style.display = "none";
            break;
        case "R":
            glb_dammy = "R";
            iframe_left.width = trans_dbl(iframe_left.width);
            dbl_page_side = "L";
            iframe_right.width = "0px";
            img_elem = document.getElementById("pageFrame_left").contentDocument.getElementById("image");
            if(img_elem == null){
                resio = trans_num(iframe_left.width)/html_width;
            }else{
                img_n_width = img_elem.naturalWidth * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
                resio = trans_num(iframe_left.width)/img_n_width;
            }
            if(img_n_width < trans_num(iframe_left.width) * 0.8){
                resio = trans_num(iframe_left.width)/html_width/2;
                
                //jpegのサイズがシングルサイズの場合でも連結ページの場合がある為
            }
            v = "scale(" + resio + "," + resio + ")";
            document.getElementById("pageFrame_left").contentWindow.set_body_transform(v,resio);
            document.getElementById("save_btn_w").style.display = "none";
            break;
    }
    if(dammy == "") {
        dammy_null_ct += 1;
    }    
    //ダミーページが無い場合
    if(dammy_null_ct > 1){
        //iframe_left.width = iframe_width_under_dual;
        //iframe_right.width = iframe_width_under_dual;
        get_elem_byId("pageFrame_left").parentNode.style.width = "";
        get_elem_byId("pageFrame_left").parentNode.style.width = "";
        //左側の保存ボタン再表示
        if(get_dsp_mode() == "dual")  document.getElementById("save_btn_w").style.display = "";
        //左ページサイズ調整率算定
        img_n_width_left = document.getElementById("pageFrame_left").contentDocument.getElementById("image").naturalWidth * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
        resio_left = trans_num(iframe_left.width)/img_n_width_left;

        img_n_height_left2 = document.getElementById("pageFrame_left").contentDocument.getElementById("image").naturalHeight * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
        resio_left2 = trans_num(iframe_left.height)/img_n_height_left2;

        //v_left = "scale(" + resio_left + "," + resio_left + ")";
        //右ページサイズ調整率算定
        //console.log(document.getElementById("pageFrame_right"));
        img_n_width_right = document.getElementById("pageFrame_right").contentDocument.getElementById("image").naturalWidth * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
        resio_right = trans_num(iframe_right.width)/img_n_width_right;
        
        img_n_height_right2 = document.getElementById("pageFrame_right").contentDocument.getElementById("image").naturalHeight * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
        resio_right2 = trans_num(iframe_right.height)/img_n_height_right2;
        
        //v_right = "scale(" + resio_right + "," + resio_right + ")";
        /********************* ページサイズ調整 ****************************
        連結ページがない状態で、片側ページの倍率が
        小さい場合(縮小)0.9未満 反対側のページ倍率に合わせ、スクロールバーを表示する
        //大きい場合(拡大)1.2超過 反対側のページ倍率に合わせる。
        ****************************************************************/
        if(dsp_mode == "dual"){
            if(resio_left < 0.9 && resio_right < 0.9){
                resio_left = resio_left2;
                resio_right = resio_right2;

                iframe_left.width = img_n_width_left*resio_left + "px";
                iframe_right.width = img_n_width_right*resio_right + "px";

                if(touch_flg) document.getElementById("pageFrame_left").parentNode.style.backgroundColor = IFRAME_OVERFLOW;
                get_elem_byId("pageFrame_left").parentNode.style.width = iframe_width_under_dual;
                get_elem_byId("pageFrame_left").parentNode.style.height = trans_num(iframe_height_under_dual) + 20 + "px";
                
                if(touch_flg) document.getElementById("pageFrame_right").parentNode.style.backgroundColor = IFRAME_OVERFLOW;
                get_elem_byId("pageFrame_right").parentNode.style.width = iframe_width_under_dual;
                get_elem_byId("pageFrame_right").parentNode.style.height = trans_num(iframe_height_under_dual) + 20 + "px";

            }else if(resio_left < 0.9){ //resio_left < 0.7から変更2022-6-15
                resio_left = resio_right;
                iframe_left.width = img_n_width_left*resio_left + "px";

                if(touch_flg) document.getElementById("pageFrame_left").parentNode.style.backgroundColor = IFRAME_OVERFLOW;

                get_elem_byId("pageFrame_left").parentNode.style.width = iframe_width_under_dual;
                get_elem_byId("pageFrame_left").parentNode.style.height = trans_num(iframe_height_under_dual) + 20 + "px";
            }else if(resio_right < 0.9){ //resio_right < 0.7から変更2022-6-15
                resio_right = resio_left;
                iframe_right.width = img_n_width_right*resio_right + "px";

                if(touch_flg) document.getElementById("pageFrame_right").parentNode.style.backgroundColor = IFRAME_OVERFLOW;

                get_elem_byId("pageFrame_right").parentNode.style.width = iframe_width_under_dual;
                get_elem_byId("pageFrame_right").parentNode.style.height = trans_num(iframe_height_under_dual) + 20 + "px";
            //image画像サイズは同じに見えてもresioが若干異なる場合があるので小さい方に合わせる
            }else if(Math.abs(resio_left - resio_right) < 0.08){
                if(resio_left < resio_right){
                    resio_right = resio_left;
                }else{
                    resio_left = resio_right;
                }
            }
        }if(dsp_mode == "single"){
            const rso = trans_num(iframe_width_under_sigle_reflow)/trans_num(iframe_width_under_dual);        
            if(get_reflow_mode()){
                if(resio_left < 0.4 && resio_right < 0.4){
                    resio_left = 1.0;
                    resio_right = 1.0;
                }else if(resio_left < 0.5){
                    resio_left = resio_right;
                    iframe_left.width = img_n_width_left * rso + "px";

                    if(touch_flg) document.getElementById("pageFrame_left").parentNode.style.backgroundColor = IFRAME_OVERFLOW;

                    get_elem_byId("pageFrame_left").parentNode.style.width = iframe_width_under_sigle_reflow;
                    get_elem_byId("pageFrame_left").parentNode.style.height = trans_num(iframe_height_under_sigle_reflow) + 3 + "px";
                }else if(resio_right < 0.5){
                    resio_right = resio_left;
                    iframe_right.width = img_n_width_right * rso + "px";

                    if(touch_flg) document.getElementById("pageFrame_right").parentNode.style.backgroundColor = IFRAME_OVERFLOW;

                    get_elem_byId("pageFrame_right").parentNode.style.width = iframe_width_under_sigle_reflow;
                    get_elem_byId("pageFrame_right").parentNode.style.height = trans_num(iframe_height_under_sigle_reflow) + 3 + "px";
                }    
            }
        }        
        v_left = "scale(" + resio_left + "," + resio_left + ")";
        v_right = "scale(" + resio_right + "," + resio_right + ")";
        document.getElementById("pageFrame_left").contentWindow.set_body_transform(v_left,resio_left);
        document.getElementById("pageFrame_right").contentWindow.set_body_transform(v_right,resio_right);
        //後処理
        dammy_null_ct = 0;
        dbl_page_side = "";
    }
    //windowのサイズ調整。教材選択後1回のみ実施される。
    if(get_selected_material_flg()){
        if(isTouchValid()){
            if(dsp_mode == "dual"){
                if(get_orientation()=="yoko"){
                    adjust_dsp_size_under_dual()
                }else{
                    adjust_dsp_size_under_dual_ipad();
                }
            }else if(dsp_mode == "single"){
                if(get_orientation()=="yoko"){
                    adjust_dsp_size_under_single();  
                }else{
                    adjust_dsp_size_under_single_ipad();
                }
            }
        }else{
            if(dsp_mode == "dual"){
                adjust_dsp_size_under_dual();
            }else if(dsp_mode == "single"){
                adjust_dsp_size_under_single();
            }
        }
        set_selected_material_flg(false);
    }
    set_style_in_comp(iframe_left);
    set_style_in_comp(iframe_right);
    call_ct += 1;
    if(call_ct > 1) {
        call_ct = 0;
        dammy_null_ct = 0;
        glb_dammy = "";
    }
    reset_iframe_size_for_mode();
}
