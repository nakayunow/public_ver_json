function get_raise_boundary_str(val){
    if(dic[val] === undefined){
        return val;
    }else{
        return dic[val];
    }
}
const dic = {"その":"曽の","を":"を、","じっこうする":"実行する"};