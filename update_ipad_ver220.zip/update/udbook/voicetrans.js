
//21-10-17
/* <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< [ 音声合成 ]>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>.>>>>
    voice_trans_pause:一時停止
    voice_trans_restart:再開
    voice_trans_quit:終了
    voice_trans:開始
<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<*>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> */
const glb_synth = window.speechSynthesis;
const glb_uttr = new SpeechSynthesisUtterance();
const us_mark = "__us__";
const yomi_kanji_prefix = "~^~";
const us_mark_reg = new RegExp(us_mark, "g");

//const _sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
let glb_span_elems = [];//phraseクラスまたはStrCtrlクラスの配列
let glb_span_hilight_elems = [];//ハイライトさせるspanエレメント
let glb_ct_for_hilight = 0;//ハイライトさせるspanエレメントの順番
let glb_span_reflow_elems = [];
let glb_span_reflow_hilight_elems = [];
let glb_span_reflow_hilight_first_elem;
let current_span_elem = "";
let pause = false;          //ポーズボタン〓をクリックした時 trueにする
let glb_cancel_flg = false; //ストップボタン■をクリックした時 trueにする
let reflow_flg;
let pr_speech_flg = false;
let voice_highlight_color = "";
let voice_highlight_color_rf = "";
let chng_bg = [];
let pr_speech_elem = []; //音声発声枠クリック時に使用する
let phrase_ari_short_flg = false;
let phrase_nash_flg = false;
let glb_ct = 0; //文書カウンター
let pre_glb_ct = -1;
let pre_glb_ct_array = [];
//====================================
//page.jsからアクセス
function get_phrase_ari_short_flg() {
    return phrase_ari_short_flg;
}
//====================================
//config.jsからアクセス
function set_phrase_ari_short_flg(val) {
    phrase_ari_short_flg = val;
}
function set_phrase_nasi(val) {
    phrase_nash_flg = val;
}
//====================================
//config設定の文書を読む
let voice_t = function () {
    //最初の文節からスタートする
    phrase_ari_start_flg = true;
    if (get_phrase_umu() == "ari") {
        pre_voice_trans(4, 'setting_text');
    } else if (get_phrase_umu() == "ari_short") {
        //start_phrase_elem = document.getElementById("div_dammy").getElementsByClassName("phrase")[0];
        pre_voice_trans(5, 'div_dammy');
    } else {
        pre_voice_trans(5, 'div_dammy');
    }
}
let jp_voice_name;
let us_voice_name;
function set_jp_voice_name(val) {
    jp_voice_name = val;
}
function get_jp_voice_name() {
    return jp_voice_name;
}
function set_us_voice_name(val) {
    us_voice_name = val;
}
//音声ボタンクリック時に起動
/* ***********************************************************
    指定ページ側のspeech_orderに格納されたStrCtrlのid順に読み上げる
    div_id:クリックしたStrCtrlのid
    direct:クリックした側のpage_frame
    vflg:true=reflowから false=pageから呼び出し
*********************************************************** */
let start_phrase_elem; //分節区切り短の場合にスタートphraseを格納する。
function get_phrase_elems(div_id, direct, vflg, direct_phrase_elem = null) {
    start_phrase_elem = direct_phrase_elem;
    phrase_ari_start_flg = false; //どのphraseエレメントから読みをスタートさせるかを決めるflgを初期化する。
    let speech_order_array = [];//speech_orderを配列として格納
    let speech_reflow_order_array = [];
    //let idx = 0;
    let ret_array = [];
    let ret_array2 = [];
    let flg = false;
    //引数div_idがnullの場合はspeech_orderの最初のStrCtrlからspeech開始する
    if (div_id == null) flg = true;
    //reflow_flg = false;
    if (document.getElementById(direct).contentDocument.getElementById("speech_order") == null || document.getElementById(direct).contentDocument.getElementById("speech_order") == "") return;
    //speech_orderのStrCtrlのidを配列で格納
    let StrCtrl_ids = document.getElementById(direct).contentDocument.getElementById("speech_order").innerHTML.split(':');
    //const divFrame_id = (direct.indexOf("left") != -1) ? "divFrame_right" : "divFrame_left";
    reflow_flg = get_reflow_mode();//vflg;
    let telems;
    if (get_reflow_frame_side() == "L") {
        telems = document.getElementById("divFrame_left").getElementsByClassName("StrCtrl");
    } else if (get_reflow_frame_side() == "R") {
        telems = document.getElementById("divFrame_right").getElementsByClassName("StrCtrl");;
    }
    for (i = 0; i < StrCtrl_ids.length - 1; i++) {
        //指定のStrCtrlのidがspeech_order中のidと一致した場合、flgをtrueにする
        if (div_id == StrCtrl_ids[i]) {
            flg = true;
        }
        if (flg) {
            if (reflow_flg && !pr_speech_flg) {
                for (t1 = 0; t1 < telems.length; t1++) {
                    if (telems[t1].id == StrCtrl_ids[i].replace("div", "exdiv")) {
                        speech_reflow_order_array.push(telems[t1]);
                        break;
                    }
                }
            }
            if (document.getElementById(direct).contentDocument.getElementById(StrCtrl_ids[i]) != null) {
                speech_order_array.push(document.getElementById(direct).contentDocument.getElementById(StrCtrl_ids[i]));
            }
        }
    }
    for (k = 0; k < speech_order_array.length; k++) {
        if (speech_order_array[k] == null) continue;
        let phrase_elems = speech_order_array[k].getElementsByClassName("phrase");
        for (m = 0; m < phrase_elems.length; m++) {
            const st2 = phrase_elems[m].textContent.replace(/\r?\n/g, "").replace(/\s+/g, "");
            if (st2 != "") ret_array.push(phrase_elems[m]);//  [idx] = phrase_elems[m];
        }
        if (reflow_flg && !pr_speech_flg) {
            let phrase_elems2 = speech_reflow_order_array[k].getElementsByClassName("phrase");
            for (n = 0; n < phrase_elems2.length; n++) {
                const stt2 = phrase_elems2[n].textContent.replace(/\r?\n/g, "").replace(/\s+/g, "");
                if (stt2 != "") ret_array2.push(phrase_elems2[n]);//  [idx2] = phrase_elems2[n];
            }
        }
    }
    glb_span_reflow_elems = ret_array2;
    //if(start_phrase_elem == null) start_phrase_elem = ret_array[0];
    return ret_array;
}
//分節区切り無し、または分節区切り短
function get_StrCtrl_elems(div_id, direct, vflg, direct_phrase_elem = null) {
    start_phrase_elem = direct_phrase_elem;
    let speech_order_array = [];//speech_orderを配列として格納
    let speech_reflow_order_array = [];
    let flg = false;
    //引数div_idがnullの場合はspeech_orderの最初のStrCtrlからspeech開始する
    if (div_id == null) flg = true;
    //reflow_flg = false;
    if (document.getElementById(direct).contentDocument.getElementById("speech_order") == null || document.getElementById(direct).contentDocument.getElementById("speech_order") == "") return;
    //speech_orderのStrCtrlのidを配列で格納
    let StrCtrl_ids = document.getElementById(direct).contentDocument.getElementById("speech_order").innerHTML.split(':');
    //const divFrame_id = (direct.indexOf("left") != -1) ? "divFrame_right" : "divFrame_left";
    reflow_flg = get_reflow_mode();//vflg;
    let telems2;
    if (get_reflow_frame_side() == "L") {
        telems2 = document.getElementById("divFrame_left").getElementsByClassName("StrCtrl");
        glb_span_reflow_hilight_first_elem = telems2[0].getElementsByClassName("phrase")[0];
    } else if (get_reflow_frame_side() == "R") {
        telems2 = document.getElementById("divFrame_right").getElementsByClassName("StrCtrl");
        glb_span_reflow_hilight_first_elem = telems2[0].getElementsByClassName("phrase")[0];
    }
    //glb_span_reflow_hilight_first_elem = telems2[0].getElementsByClassName("phrase")[0];

    for (i2 = 0; i2 < StrCtrl_ids.length - 1; i2++) {
        //指定のStrCtrlのidがspeech_order中のidと一致した場合、flgをtrueにする
        if (div_id == StrCtrl_ids[i2]) {
            flg = true;
        }
        if (flg) {
            if (reflow_flg && !pr_speech_flg) {
                for (t2 = 0; t2 < telems2.length; t2++) {
                    if (telems2[t2].id == StrCtrl_ids[i2].replace("div", "exdiv")) {
                        speech_reflow_order_array.push(telems2[t2]);
                        break;
                    }
                }
            }
            if (document.getElementById(direct).contentDocument.getElementById(StrCtrl_ids[i2]) != null) {
                speech_order_array.push(document.getElementById(direct).contentDocument.getElementById(StrCtrl_ids[i2]));
            }
            //idx += 1;
        }
    }
    glb_span_reflow_elems = speech_reflow_order_array;
    //if(start_phrase_elem == null) start_phrase_elem = speech_order_array[0];
    return speech_order_array;
}
//音声発声枠クリック時に起動。elm_id:音声枠idvのid
let otowaku_div_id = "";
function get_speech_element(elm_id, direct, direct_phrase_elem = null) {
    otowaku_div_id = elm_id;
    //リフローのハイライト抑制に使用する
    pr_speech_flg = true;
    //set_speech_flg(true);
    start_phrase_elem = direct_phrase_elem;//文頭から音声をスタートする。

    let ret_array = [];
    //div_7-div_1$div_3:
    let SpeechElem_ids = document.getElementById(direct).contentDocument.getElementById("speech_element").innerHTML.split(':');
    //連想配列作成
    let speech_element_array = {};
    let target_elem = [];
    for (i = 0; i < SpeechElem_ids.length - 1; i++) {
        let val = SpeechElem_ids[i].split("-");
        speech_element_array[val[0]] = val[1]; //[音声発声枠div-id:音声変換対象文字内包div-id$...]
    }
    //音声発声枠クリック時にdivのidに対応した音声変換対象文字内包divエレメント群を所得する
    let d_array = speech_element_array[elm_id].split("$");

    for (j = 0; j < d_array.length; j++) {
        target_elem[j] = document.getElementById(direct).contentDocument.getElementById(d_array[j]);
        //窓リフローの表示
        if (target_elem[j].classList.contains("PrSpeechElem")) {
            if (!target_elem[j].classList.contains("StrCtrl_v")) {
                target_elem[j].style.height = "";
            }
            pr_speech_elem.push(target_elem[j]);
            target_elem[j].style.border = "";
            target_elem[j].style.display = "";
            target_elem[j].style.zIndex = "10000";
            target_elem[j].style.color = "";
        }

        const phrase_elems = target_elem[j].getElementsByClassName("phrase");
        let temp_array = [];
        for (m = 0; m < phrase_elems.length; m++) {
            temp_array[m] = phrase_elems[m];
        }
        if (get_phrase_umu() == "ari") {
            ret_array = ret_array.concat(temp_array);
        } else {
            ret_array.push(target_elem[j]);
        }
        //ret_array = ret_array.concat(temp_array);

    }
    return ret_array;
}
function reset_pr_speech_elem() {
    for (j = 0; j < pr_speech_elem.length; j++) {
        pr_speech_elem[j].style.display = "none";
    }
    pr_speech_elem = [];
    pr_speech_flg = false;
}
function set_phrase_elems(id) {
    let ret_array = [];
    let elem = document.getElementById(id);
    let phrase_elems = elem.getElementsByClassName("phrase");
    for (m = 0; m < phrase_elems.length; m++) {
        ret_array[m] = phrase_elems[m];
    }
    return ret_array;
}
function set_StrCtrl_elems(id) {
    let ret_array = [];
    let elem = document.getElementById(id);
    ret_array[0] = elem;
    return ret_array;
}
function getElemIdx(targetElem, ElemnArray) {
    for (i = 0; i < ElemnArray.length; i++) {
        if (ElemnArray[i] === targetElem) return i;
    }
    return -1;
}
//*************** HTML編集後に初期化が必要 ***************
let glb_flg = false;
//---------- 初期化関数 -----------
let init_glbVar_html = function () {
    glb_flg = false;
}
//************* 音声再生終了時に初期化が必要 ***************
//page.jsからアクセス
function getPauseFlg() {
    return (pause) ? true : false;
}
function voice_trans_pause() {
    if (glb_span_elems.length == 0) return;
    pause = true;
    glb_cancel_flg = true;//文節(短) 間合い:長の場合ストップさせる
    if (phrase_ari_short_flg || get_phrase_umu() == "nasi_strctrl") {
        glb_synth.pause();
    } else {
        current_span_elem = glb_span_elems[glb_ct];
    }

}
//let temp_disable_flg = false;

function voice_trans_restart() {
    console.log("=========== restart ==========");
    //glb_synth.resume();
    //glb_cancel_flg = false;
    //pause = false;
    const t_ct = (glb_ct_for_hilight_array_0 != -1) ? glb_ct_for_hilight_array_0 : glb_ct_for_hilight;
    glb_ct_for_hilight_array_0 = -1;
    if (phrase_ari_short_flg) {// || get_phrase_umu() == "nasi_strctrl"){
        const t = glb_span_hilight_elems[t_ct];
        //console.log(t.textContent);
        set_execution_quit();
        voice_trans_quit(false);//falseを指定して音枠を初期化しない
        set_speech_param(0);
        if (current_sort == 2 || current_sort == 3) {//音枠
            pre_voice_trans(current_sort, otowaku_div_id, false, t);
            document.getElementById(directPageFrame).contentWindow.document.getElementById(otowaku_div_id).style.border = "5px ridge red";
            document.getElementById(directPageFrame).contentWindow.document.getElementById(otowaku_div_id.replace("div","exdiv")).style.border = "5px ridge red";
        } else {
            //console.log(t.textContent);
            document.getElementById(directPageFrame).contentWindow.voice_restart(t);
        }
    } else if (get_phrase_umu() == "nasi_strctrl") {
        const t = glb_span_hilight_elems[glb_ct_for_hilight];
        set_execution_quit();
        voice_trans_quit(false);//falseを指定して音枠を初期化しない
        set_speech_param(0);
        if (current_sort == 2 || current_sort == 3) {//音枠
            pre_voice_trans(current_sort, otowaku_div_id, false)
        } else {
            pre_voice_trans(current_sort, t.id, false)
        }
    } else {
        const targ = (directPageFrame == "pageFrame_left") ? 0 : 1;
        pre_voice_trans(targ, "", false);
        glb_cancel_flg = false;
        pause = false;
    }
}
function voice_trans_quit(flg = true) {
    if (glb_span_elems.length == 0) return;
    glb_cancel_flg = true;
    pause = false;
    //ipad対応
    if (touch_flg) {
        glb_uttr.text = "";
        glb_synth.speak(glb_uttr);
    }
    //safari対応
    /*
    if (agent.indexOf("safari") != -1 && agent.indexOf("chrome") == -1) {
        glb_uttr.text = "";
        glb_synth.speak(glb_uttr);
    }
    */
    glb_synth.cancel();
    //選択解除
    for (i = 0; i < glb_span_elems.length; i++) {
        if (phrase_ari_short_flg) {
            const t_elem = glb_span_elems[i].getElementsByClassName("phrase");
            let t_elem_reflow;
            if (reflow_flg && !pr_speech_flg) {
                t_elem_reflow = glb_span_reflow_elems[i].getElementsByClassName("phrase");
                for (j = 0; j < t_elem.length; j++) {
                    t_elem[j].style.backgroundColor = "";
                    t_elem_reflow[j].style.backgroundColor = "";
                }
            } else {
                for (j = 0; j < t_elem.length; j++) {
                    t_elem[j].style.backgroundColor = "";
                }
            }
        } else {
            glb_span_elems[i].style.backgroundColor = "";
            if (reflow_flg && !pr_speech_flg) {
                if (glb_span_reflow_elems[i] != undefined) glb_span_reflow_elems[i].style.backgroundColor = '';
            }
        }
    }
    if (flg) {
        reset_pr_speech_elem();
        reset_scrl_val();
    }
    pre_scrl = 0;
    //set_page_speaking_flg(false);//固定画面でのクリックで音声発火を有効にする。
    //set_speech_flg(false);//リフロー画面でのクリックで音声発火を有効にする。
    set_pause_flg(true);//pauseを有効にする
    glb_ct = 0;
    pre_cct = -1;
    pre_glb_ct = -1;
    glb_ct_for_hilight = 0;
    //pre_glb_ct_for_hilight = -1;
    array_voice_str_idx = 0;
    sentence_delimita_qty = 0;
    sentence_qty = 0;
    glb_ct_for_hilight_array_0 = -1;
    array_voice_str = [];
    glb_span_elems = [];
    //auto_speech()終了
    set_execution_quit();
    //glb_cancel_flg = false;
    pre_glb_ct_array = [];
    set_speech_param(0);
    t_d = 0;
    //音枠のフレーム色を元に戻す
    show_speech_frame2();
}
function set_voice_speech_rate(val) {
    glb_uttr.rate = val;//document.getElementById("voice_trans_speed_ate").value;
}
function set_voice_speech_pitch(val) {
    glb_uttr.pitch = val;//document.getElementById("voice_trans_pitch_ate").value;
}
function set_voice_speech_volume(val) {
    glb_uttr.volume = val;//document.getElementById("voice_trans_pitch_ate").value;
}
/*
function set_voice(){
    if(voiceSelect.value == "") return;
    glb_uttr.voice = speechSynthesis.getVoices().filter(voice => voice.name === voiceSelect.value)[0];
    glb_uttr.lang = glb_uttr.voice.lang;
}
*/
function set_voice(arg) {
    const voices = speechSynthesis.getVoices();
    for (let i = 0; i < voices.length; i++) {
        if (voices[i].name === arg) {
            glb_uttr.voice = voices[i];
            glb_uttr.lang = voices[i].lang;
            break;
        }
    }
}
function set_voice_highlight_color(val) {
    voice_highlight_color = val;
}
function set_voice_highlight_color_rf(val) {
    voice_highlight_color_rf = val;
}

/*====================================================================================
pre_scrl:前回のスクロール量の値を保存。今回のスクロール量がpre_scrlより大きいとスクロールを実施する。
t_scrl:スクロール量を保存。
init_scrl_posi:phraseエレメントをクリツクした時のスクロール量を保存。
param:リフロー上の先頭エレメントの位置(right or top)を保存。
====================================================================================*/
let pre_scrl = 0;
let t_scrl = 0;
let reset_scrl_val = function () {
    pre_scrl = 0;
    t_scrl = 0;
    init_scrl_posi = 0;
}
let param;
function set_param(val){
    param = val;
}
function is_first_elem(){
    if(glb_ct == 0 && array_voice_str_idx == 0){
        return true;
    }else{
        return false;
    }
}
function is_last_elem(){
    if(glb_span_elems.length - 1 == glb_ct && array_voice_str_idx == array_voice_str.length - 1){
        return true;
    }else{
        return false;
    }
}
/**********************************************************
glb_ctが最初と最後の時に特殊な処理が必要
glb_ct==最初:
    リフロー画面の下部または左部に隠れているハイライト領域がある
    場合のみその領域分をスクロールさせる
limit_point:クリックしたphraseエレメントの位置(right or top)
******************************************************** */
let scr_motion = async function (elem, delta, limit_point) {
    //--- 横書モードの時に使用する
    const single_mode_elem_height = Number(elem.style.top.replace("px",""));
    const speech_speed = Number(document.getElementById("speech_speed").value);
    //console.log("========" + glb_ct);
    //console.log("====delta====" + delta);
    //delta = delta/0.92;//移動幅を増やす
    const m = 3;//--- 3pxを20msで移動
    
    let excess_area = 0;//--- リフロー画面の下部または左部に隠れているハイライト領域を保存
    if (get_reflow_writing_mode() == "H") {
        if(get_dsp_mode() == "dual"){
            excess_area = (limit_point - param) - (elem.scrollTop + Number(elem.style.height.replace("px","")));
        }else if(get_dsp_mode() == "single"){
            excess_area = (limit_point - param) - single_mode_elem_height - (elem.scrollTop + Number(elem.style.height.replace("px","")));
        }
    }else if (get_reflow_writing_mode() == "V") {
        //param = glb_span_reflow_hilight_first_elem.getBoundingClientRect().right;
        excess_area = (param-limit_point) - (elem.scrollLeft*-1  + Number(elem.style.width.replace("px","")));
        //if(glb_ct != 0 && glb_span_elems.length -1 == glb_ct) excess_area -= delta;
    }
    /* *******************************************************************
    最初の要素と最後の要素の時、excess_areaにdeltaを加算する。
    中間要素の場合はdelta分スクロールした場合のexcess_areaを算出するので加算しない。
    ******************************************************************* */
    if(is_first_elem()){
        excess_area += delta;
        //--- 最初の要素の時excess_areaが0以下の場合returnする。
        if(excess_area <= 0) return;
    }else if(is_last_elem()){
        excess_area += delta;
    }

    //console.log((param-limit_point) - (elem.scrollLeft*-1  + Number(elem.style.width.replace("px",""))));
    //console.log("excess_area=" + excess_area);
    //console.log("param=" + param);
    //console.log("limit_point=" + limit_point);
    //console.log("scrollLeft=" + elem.scrollLeft*-1);
    //console.log("width=" + Number(elem.style.width.replace("px","")));
    //console.log(elem.scrollLeft*-1  + Number(elem.style.width.replace("px","")));
    
    //console.log("======t_scrl========" + t_scrl + "===" + delta);
    //const d = init_scrl_posi - delta;
    //if(d>0) delta = delta - d;
    //alert(elem.style.height);
    const ct = Math.ceil(delta/m);
    const p = delta / ct * -1;
    for (let i = 1; i <= ct; i++) {
        //console.log("init_elem.scrollTop==" + elem.scrollTop);
        if (get_reflow_writing_mode() == "V") {
            if(get_dsp_mode() == "dual"){
                if (elem.scrollLeft < limit_point - param || is_first_elem()) {
                    console.log("break");
                    if(is_first_elem()) delta = 0;
                    const d = p * i * -1;
                    excess_area = delta - d;
                    delta = d;
                    break;
                }
            }else if(get_dsp_mode() == "single"){ //---valid block
                if (elem.scrollLeft < limit_point - param || is_first_elem()) {
                    console.log("break");
                    if(is_first_elem()) delta = 0;
                    const d = p * i * -1;
                    excess_area = delta - d;
                    delta = d;
                    break;
                }
            }
            if (pre_scrl > p * i - t_scrl) {
                elem.scrollLeft = p * i - t_scrl;
                pre_scrl = p * i - t_scrl;
            }
        }else if (get_reflow_writing_mode() == "H") {
            if(get_dsp_mode() == "dual"){       
                if (elem.scrollTop > limit_point || is_first_elem()) {//singleの場合400
                    console.log("break7");
                    if(is_first_elem()) delta = 0;
                    const d = p * i * -1;
                    excess_area = delta - d;
                    delta = d;
                    break;
                }
            }else if(get_dsp_mode() == "single"){
                if (elem.scrollTop > limit_point - single_mode_elem_height || is_first_elem()) {//singleの場合400
                    console.log("break7");
                    if(is_first_elem()) delta = 0;
                    const d = p * i * -1;
                    excess_area = delta - d;
                    delta = d;
                    break;
                }
            }
            //console.log("======pre_scrl========" + pre_scrl + "= < ==" + (p * i * -1 + t_scrl) + "=t_scrl=" + t_scrl);
            if (pre_scrl < p * i * -1 + t_scrl) {
                elem.scrollTop = p * i * -1 + t_scrl;
                pre_scrl = p * i * -1 + t_scrl;
            }
        }
        if(get_dsp_mode() == "dual"){  
            await _sleep(15 / speech_speed);
        }else if(get_dsp_mode() == "single"){
            await _sleep(5 / speech_speed);
        }
    }
    t_scrl += delta;
    //console.log("ppppppppppppp t_scrl=" + t_scrl);
    //t_scrl += 250;//250
    let elem_scroll_at_start = 0;
    const elem_width = Number(elem.style.width.replace("px",""));
    const elem_height = Number(elem.style.height.replace("px",""));
    if(excess_area > 0){
        if(get_dsp_mode() == "dual"){  
            await _sleep(2500 / speech_speed);
        }else if(get_dsp_mode() == "single"){  
            await _sleep(2000 / speech_speed);
        }

        if (get_reflow_writing_mode() == "H") {
            elem_scroll_at_start = elem.scrollTop;
        }else if (get_reflow_writing_mode() == "V") {
            elem_scroll_at_start = elem.scrollLeft;
        }
        //?????excess_area += (get_delta()/0.7); //一行大き目にする
        pre_scrl = 0;
        const ct2 = Math.ceil(excess_area/m);
        const p2 = excess_area / ct2 * -1;
        for (let j = 1; j <= ct2; j++) {
            if (get_reflow_writing_mode() == "H") {
                if (pre_scrl < p2 * j * -1 + t_scrl) {
                    elem.scrollTop = p2 * j * -1 + t_scrl;
                    if(elem.scrollTop -  elem_scroll_at_start> elem_height){
                        await _sleep(800);
                        elem_scroll_at_start = elem.scrollTop;
                    }
                    pre_scrl = p2 * j * -1 + t_scrl;
                }
            }else if (get_reflow_writing_mode() == "V") {
                if (pre_scrl > p2 * j - t_scrl) {
                    elem.scrollLeft = p2 * j - t_scrl;
                    if(elem_scroll_at_start - elem.scrollLeft > elem_width){
                        await _sleep(800);
                        elem_scroll_at_start = elem.scrollLeft;
                    }
                    pre_scrl = p2 * j - t_scrl;
                }    
            }
            if(get_dsp_mode() == "dual"){  
                await _sleep(10 / speech_speed);
            }else if(get_dsp_mode() == "single"){
                await _sleep(10 / speech_speed);
            }
        }
    }
    if(excess_area > 0) t_scrl += excess_area;
    //if(glb_span_elems.length == glb_ct) elem.scrollTop = 0;  
}
/* ********************************************************
次の一行分の移動距離を返す。字幅+行間幅
******************************************************** */
let get_delta = function () {
    const a = Number((get_elem_byId("reflow_font_size").options[get_elem_byId("reflow_font_size").selectedIndex].value).replace("px", "")) * 0.92;
    const b = Number((get_elem_byId("reflow_line_height").options[get_elem_byId("reflow_line_height").selectedIndex].value).replace("px", "")) * 0.91;
    return a + b;
}
/* ********************************************************
スクロールをスタートする位置
param:リフロー上の最初をのエレメントの位置(right or top)を保存。
******************************************************** */
let get_scrl_start_posi = function () {
    if (get_dsp_mode() == "dual") {
        if (get_reflow_writing_mode() == "V") {
            return param - 200;
        } else if (get_reflow_writing_mode() == "H") {
            return 300;
        }
    } else if (get_dsp_mode() == "single") {
        if (get_reflow_writing_mode() == "V") {
            return param - 150;
        } else if (get_reflow_writing_mode() == "H") {
            return 100;
        }
    }
}
let init_scrl_posi = 0;
//let pre_right = 0;
let exec_scr_motion = function () {
    if(!get_reflow_mode()) return;
    if(get_reflow_as() == "off") return;
    if(pr_speech_flg) return;
    if(get_phrase_umu() == "ari") return;
    //========================= 自動スクロール ===========================
    const targ = (directPageFrame == "pageFrame_left") ? "divFrame_left" : "divFrame_right";
    //const scrl_width = get_elem_byId(targ).scrollWidth;// + get_elem_byId(targ).scrollLeft;
    //if(scrl_width - array_for_scrl[array_voice_str_idx][0] > 500 + init_scrl_left){

    //横書き、縦書きの判別
    /* ***********************************
    array_for_scrl[0]:right or top
    array_for_scrl[1]:height or width
    array_for_scrl[2]:行数 - 1
    *********************************** */
    if (get_reflow_writing_mode() == "V") {
        //console.log("^^^^^^^^^^^=" + array_for_scrl[array_voice_str_idx][0]);
        if (array_for_scrl[array_voice_str_idx][0] < get_scrl_start_posi() - init_scrl_posi) {
            scr_motion(get_elem_byId(targ), (array_for_scrl[array_voice_str_idx][2] + 1) * get_delta(), array_for_scrl[array_voice_str_idx][0]);//75
        }
    } else if (get_reflow_writing_mode() == "H") {
        //console.log("^^^^^^^^^^^=" + array_for_scrl[array_voice_str_idx][0]);
        //console.log("s1=" + get_scrl_start_posi());
        //console.log("s2=" + init_scrl_posi);
        if (array_for_scrl[array_voice_str_idx][0] > get_scrl_start_posi() + init_scrl_posi || glb_ct == 0) {
            //console.log("limit=" + array_for_scrl[array_voice_str_idx][0]);
            scr_motion(get_elem_byId(targ), (array_for_scrl[array_voice_str_idx][2] + 1) * get_delta(), array_for_scrl[array_voice_str_idx][0]);//75
        }
    }
}


let scr_motion2 = async function(elem,start,delta){
    const m = 3;
    const ct = Math.ceil(delta/m);
    if (get_reflow_writing_mode() == "V") {
        const p = delta/ct*-1;
        for(let i=1;i<=ct;i++){
            elem.scrollLeft = p * i - start;
            await _sleep(20);
        }
    }else if (get_reflow_writing_mode() == "H") {
        const p = delta/ct;
        for(let i=1;i<=ct;i++){
            elem.scrollTop = p * i + start;
            await _sleep(20);
        }
    }
}

//let kx = 1;
let pre_row_posi = 0;
let t_d = 0;
function hilight() {//hilight_flg = true){
    /******************************************************
     StrCtrlに前景・背景色が設定されている場合に備える
     glb_span_elemsが<span class="phrase"の場合fore-colorのみ
     親のfore-colorをコントロールする
    *****************************************************/
    if (glb_cancel_flg) return;
    /*
    glb_span_elemsがphraseエレメントで構成されている場合、
    (音節区切り短で無い場合。又は(音節区切り短だが)音枠の場合)
    glb_span_elemsをglb_span_hilight_elemsに代入する。
    glb_span_elemsがdivエレメント(StrCtrl)で構成されている場合、
    (音節区切り短の場合)
    voice_trans_rcsの実行時にglb_span_hilight_elemsにphraseが代入される。
    
    phrase_ari_short_flg == falseは、
    phrase_umu == "ari" ハイライト:文節(短) 間合い:長
    phrase_umu == "nasi_strctrl" ハイライト:段落等 間合い:無
    の時
    */
    if (!phrase_ari_short_flg) {
        glb_span_hilight_elems = glb_span_elems;
        glb_span_reflow_hilight_elems = glb_span_reflow_elems;
        glb_ct_for_hilight = glb_ct;
    }
    if (glb_span_hilight_elems[glb_ct_for_hilight] == undefined) return;

    let fr_color = glb_span_hilight_elems[glb_ct_for_hilight].parentNode.style.color;
    if (fr_color != "") {
        const rc_array = fr_color.replace("rgb(", "").replace(")", "").split(",");
        //前景色が白に近い場合、黒に変換する
        if (rc_array[0] > 230 && rc_array[1] > 230 && rc_array[2] > 230) {
            chng_bg.push(glb_ct_for_hilight);
            chng_bg.push(fr_color);
            glb_span_hilight_elems[glb_ct_for_hilight].style.color = "rgb(0,0,0)";
        }
    }
    glb_span_hilight_elems[glb_ct_for_hilight].style.backgroundColor = voice_highlight_color;
    
    if (reflow_flg && !pr_speech_flg) {
        glb_span_reflow_hilight_elems[glb_ct_for_hilight].style.backgroundColor = voice_highlight_color_rf;
    }
    //========================= 自動スクロール ===========================
    if (get_reflow_mode() && get_phrase_umu() == "ari" && !pr_speech_flg && get_reflow_as() == "on") {
        const targ = (directPageFrame=="pageFrame_left")?"divFrame_left":"divFrame_right";
        const h_elem = glb_span_reflow_hilight_elems[glb_ct_for_hilight];
        if (get_reflow_writing_mode() == "V") {
            if(pre_row_posi != h_elem.getBoundingClientRect().left && h_elem.getBoundingClientRect().right < 1000){
                    //const targ = (directPageFrame=="pageFrame_left")?"divFrame_left":"divFrame_right";
                    const d = h_elem.getBoundingClientRect().right - h_elem.getBoundingClientRect().left;
                    //alert(d);
                    //scr_motion(get_elem_byId(targ),-75*kx,-75);
                    scr_motion2(get_elem_byId(targ),t_d,d);
                t_d += d;
                pre_row_posi = glb_span_reflow_hilight_elems[glb_ct_for_hilight].getBoundingClientRect().left;
            }
        }else if (get_reflow_writing_mode() == "H") {
            if(pre_row_posi != h_elem.getBoundingClientRect().top && h_elem.getBoundingClientRect().bottom > 500){
                //const targ = (directPageFrame=="pageFrame_left")?"divFrame_left":"divFrame_right";
                const d = h_elem.getBoundingClientRect().bottom - h_elem.getBoundingClientRect().top;
                //scr_motion(get_elem_byId(targ),-75*kx,-75);
                scr_motion2(get_elem_byId(targ),t_d,d);
            t_d += d;
            pre_row_posi = glb_span_reflow_hilight_elems[glb_ct_for_hilight].getBoundingClientRect().top;
        }
    }
    }
    //============================================  

    if (pre_glb_ct != -1) {
        if (phrase_ari_short_flg && glb_ct_for_hilight == 0) {
            ; //何もしない
        } else {
            glb_span_hilight_elems[pre_glb_ct].style.backgroundColor = "";
            if (reflow_flg && !pr_speech_flg) glb_span_reflow_hilight_elems[pre_glb_ct].style.backgroundColor = "";
        }
    }
    pre_glb_ct = glb_ct_for_hilight;
}
/***************************************************************
hilight2:複数の文節をハイライトさせる
    引数--glb_ct_for_hilight_array:ハイライトさせる要素を指定した配列

erase_hilight2:指定の要素までハイライトを消す
    引数--idx:ハイライトを消す要素の最大値を指定
***************************************************************/
let glb_ct_for_hilight_array_0 = -1;
function hilight2(glb_ct_for_hilight_array) {
    glb_ct_for_hilight_array_0 = glb_ct_for_hilight_array[0];
    /******************************************************
     StrCtrlに前景・背景色が設定されている場合に備える
     glb_span_elemsが<span class="phrase"の場合fore-colorのみ
     親のfore-colorをコントロールする
    *****************************************************/
    if (glb_cancel_flg) return;
    /*
    glb_span_elemsがphraseエレメントで構成されている場合、
    (音節区切り短で無い場合。又は(音節区切り短だが)音枠の場合)
    glb_span_elemsをglb_span_hilight_elemsに代入する。
    glb_span_elemsがdivエレメント(StrCtrl)で構成されている場合、
    (音節区切り短の場合)
    voice_trans_rcsの実行時にglb_span_hilight_elemsにphraseが代入される。
    */
    for (let i = 0; i < glb_ct_for_hilight_array.length; i++) {
        glb_ct_for_hilight = glb_ct_for_hilight_array[i];
        let fr_color = glb_span_hilight_elems[glb_ct_for_hilight].parentNode.style.color;
        if (fr_color != "") {
            const rc_array = fr_color.replace("rgb(", "").replace(")", "").split(",");
            //前景色が白に近い場合、黒に変換する
            if (rc_array[0] > 230 && rc_array[1] > 230 && rc_array[2] > 230) {
                chng_bg.push(glb_ct_for_hilight);
                chng_bg.push(fr_color);
                glb_span_hilight_elems[glb_ct_for_hilight].style.color = "rgb(0,0,0)";
            }
        }
        glb_span_hilight_elems[glb_ct_for_hilight].style.backgroundColor = voice_highlight_color;
        if (reflow_flg && !pr_speech_flg) glb_span_reflow_hilight_elems[glb_ct_for_hilight].style.backgroundColor = voice_highlight_color_rf;
    }
    pre_glb_ct_array = glb_ct_for_hilight_array;
}
function erase_hilight2(idx) {
    for (let i = 0; i <= idx; i++) {
        glb_span_hilight_elems[i].style.backgroundColor = "";
        if (glb_span_reflow_hilight_elems[i] == undefined) continue;
        if (reflow_flg && !pr_speech_flg) glb_span_reflow_hilight_elems[i].style.backgroundColor = '';
    }
}
function erase_hilight3(array_arg) {
    if (array_arg.length == undefined || array_arg.length == 1) {
        glb_span_hilight_elems[array_arg].style.backgroundColor = "";
        if (reflow_flg && !pr_speech_flg) glb_span_reflow_hilight_elems[array_arg].style.backgroundColor = '';
    } else {
        for (let i = 0; i < array_arg.length; i++) {
            glb_span_hilight_elems[array_arg[i]].style.backgroundColor = "";
            if (reflow_flg && !pr_speech_flg) glb_span_reflow_hilight_elems[array_arg[i]].style.backgroundColor = '';
        }
    }
}

//arg 音声変換する文字列の配列
let voice_str = "";
let array_voice_str = [];
let array_voice_str_idx = 0;
let array_voice_str_size = [];
let array_voice_str_size_sub = [];
let phrase_elem_idx = 0;
//句点で区切った文の数
let sentence_qty = 0;
let match_us_mark_div = "X"; //0:マッチなし,1:マッチ開始,2:マッチ終了
let temp_array = [];
let fl_flg = false;

let array_for_scrl = [];
let array_for_scrl_sub = [];
let flap_ct = 0;//折り返し個数
/********************************************************************************************
arg [①,②,③,④,⑤,⑥,⑦,⑧,⑨,⑩]  ①,②...はphraseエレメント内のtext
arg配列を英文と日本語文に再配列化する。日本語文は更に句点毎に再配列化する
array_voice_str[①②③④,⑤⑥⑦,⑧⑨⑩] ④⑦の最後の文字が句点
array_voice_str_idx 0,1,2

array_voice_str_sizeはarray_voice_strの各要素に対応した文字数を格納した配列
array_voice_str_size[[3,5,2,3],[3,5],[3,7,5]]

array_voice_str_orderはarray_voice_strの各要素に対応した順番を格納した配列
array_voice_str_order[[0,1,2,3],[4,5],[6,7,8]]

glb_ct_for_hilight 取り込んだphraseエレメントの順番を表す。
    phraseエレメント20個取り込んだ場合、0〜19。


========================== イベント遷移 ======================================================
play_voice(array_voice_str_idx=0)
↓
glb_uttr.onboundary↕︎            ↑                   
↓                               ↑
glb_uttr.onend                  ↑           glb_uttr.onend            glb_uttr.onend      
             ↓                  ↑                  ↓                         ↓
(phrase_ari_short_flg=true)     ↑   (get_phrase_umu()=nasi_strctrl)        (else)
ex_phrase_short_brief_stop();   ↑     phrase_nasi_brief_stop()     glb_uttr_onend_method()
             ↓            ↓     ↑     ↓          ↓
      (StrCtrlEnd")      (StrCtrlNotEnd)    (StrCtrlEnd")
reset_ex_phrase_short_param()            glb_uttr_onend_method()
             ↓
glb_uttr_onend_method()(array_voice_str_idx=10)
             ↓
          次のdivへ

(StrCtrlNotEnd)の時 
array_voice_str_idx += 1 → speak_exe(array_voice_str[array_voice_str_idx]) → glb_uttr.onboundary

glb_uttr.onboundaryのe.charIndexについて
発声が昇順とは限らないので要注意(5の次に3になる事がある)
以下のコードで「^」の数を取得しているがcctが1の次に0になる場合がある(cctはdelimitaの数)
sct = array_voice_str[array_voice_str_idx].slice(0,e.charIndex);
cct = ( sct.match( new RegExp( "\\^", "g" ) ) || [] ).length ;
従って取得したcctをグローバル変数(pre_cct)に格納し、新たに取得したcctがそれより大きい時にのみhilightさせる様にする。

hilight()させるphraseはglb_ct_for_hilightで指定する
glb_ct_for_hilight = sentence_delimita_qty + cct

(array_voice_str_idx >= sentence_qty - 1 ):array_voice_str_idx=10,sentence_qty-1=10の時
glb_uttr_onend_method()が発火
********************************************************************************************/

//========================== step1(first) ==========================
function play_voice(arg) {
    console.log("play_voice");
    const targ = (directPageFrame == "pageFrame_left") ? "divFrame_left" : "divFrame_right";
    let orgn_width = get_elem_byId(targ).style.width;
    let orgn_height = get_elem_byId(targ).style.height
    let orgn_scrl_left;
    let orgn_scrl_top;

    if (get_reflow_mode() && get_phrase_umu() != "ari" && !pr_speech_flg) {
        if (get_reflow_writing_mode() == "V") {
            orgn_scrl_left = get_elem_byId(targ).scrollLeft;
            get_elem_byId(targ).style.width = "30000px";
        } else if (get_reflow_writing_mode() == "H") {
            orgn_scrl_top = get_elem_byId(targ).scrollTop;
            get_elem_byId(targ).style.height = "30000px";    
        }
    }

    //console.log(arg);
    set_speech_param(1);//pause可能にする
    arg.push("dammy");
    //hilight();
    let delimita;
    if (get_phrase_umu() == "ari_short") {
        delimita = " 。";
    } else {
        delimita = "^";
    }
    //const delimita = " ";// 。もあり
    voice_str = "";
    array_voice_str = [];
    array_voice_str_idx = 0;
    array_voice_str_size = [];
    array_voice_str_size_sub = [];
    array_voice_str_order = [];
    array_voice_str_order_sub = [];
    phrase_elem_idx = 0;
    sentence_delimita_qty = 0;
    match_us_mark_div = "X";
    sentence_qty = 0;
    fl_flg = false;
    pre_jp_end_flg = false;
    temp_array = [];

    array_for_scrl = [];
    array_for_scrl_sub = [];
    flap_ct = 0;
    const wd = Number((get_elem_byId("reflow_font_size").options[get_elem_byId("reflow_font_size").selectedIndex].value).replace("px", "")) * 0.92;
    const wh = Number((get_elem_byId("reflow_line_height").options[get_elem_byId("reflow_line_height").selectedIndex].value).replace("px", "")) * 0.91;
    const ww = wd + wh;
    for (let i = 0; i < arg.length; i++) {
        let max_len = 5;
        if(arg[i].indexOf(yomi_kanji_prefix) != -1){
            max_len = 8;
        }
        //if (arg[i].indexOf(us_mark) == -1 && arg[i].length >= 1 && arg[i].length < 5 && arg[i].indexOf("、") == -1 && arg[i].match(/^[a-zA-Z0-9!-/.:-@¥[-`{-~]+$/) == null) {//arg[i].length>1 && arg[i].length<4){
        if (arg[i].indexOf(us_mark) == -1 && arg[i].length >= 1 && arg[i].length < max_len && arg[i].indexOf("、") == -1 && arg[i].match(/^[a-zA-Z0-9!-/.:-@¥[-`{-~]+$/) == null) {//arg[i].length>1 && arg[i].length<4){
            let str_i = "";
            if (arg[i].length == 1) {
                str_i = arg[i] + ",";
            } else {
                if(arg[i].indexOf(yomi_kanji_prefix) != -1){
                    arg[i] = arg[i].replace(/\~\^\~/g,"");//yomi_kanji_prefix
                    let flg = false;
                    for (let si = 0; si < arg[i].length; si++) {
                        if (arg[i].charAt(si).match(/[\u30a1-\u30f6\u3041-\u3096]/) != null && !flg) {
                            str_i += arg[i].charAt(si) + "-";
                            flg = true;
                        } else {
                            str_i += arg[i].charAt(si);
                        }
                    }
                }else{
                    for (let si = 0; si < arg[i].length; si++) {
                        if (si == 0) {
                            str_i += arg[i].charAt(si) + "-";
                        } else {
                            str_i += arg[i].charAt(si);
                        }
                    }
                }
            }
            arg[i] = str_i;
        }else{
            if(arg[i].indexOf(yomi_kanji_prefix) != -1){
                arg[i] = arg[i].replace(/\~\^\~/g,"");//yomi_kanji_prefix
            }
        }
        //文節に読字がない場合
        const rt = arg[i].replace(/\.|\…|\?|\/|\-|\,|\!|\x20|\d|\’|\, |\.|<br>|\[|\]|。|、/g, "");
        if (rt == "") {
            arg[i] = arg[i] + " ";
        }

        let b_elem_rect;
        if (get_reflow_mode() && glb_span_reflow_hilight_elems[i] != undefined && get_phrase_umu() != "ari") {
            b_elem_rect = glb_span_reflow_hilight_elems[i].getBoundingClientRect();

            if (get_reflow_writing_mode() == "V") {
                if (array_for_scrl_sub.length == 0) array_for_scrl_sub.push(b_elem_rect.right);
            } else if (get_reflow_writing_mode() == "H") {
                if (array_for_scrl_sub.length == 0) {
                    console.log("top=" + i + "====" + b_elem_rect.top);
                    array_for_scrl_sub.push(b_elem_rect.top);
                }
            }
        }
        if (arg[i] == "dammy") {
            if (voice_str != "") {
                array_voice_str.push(voice_str);
                if (get_reflow_mode() && get_phrase_umu() != "ari" && !pr_speech_flg) {

                    if (get_reflow_writing_mode() == "V") {
                        array_for_scrl_sub.push(array_for_scrl_sub[0] - (glb_span_reflow_hilight_elems[glb_span_reflow_hilight_elems.length - 1]).getBoundingClientRect().left);
                    } else if (get_reflow_writing_mode() == "H") {
                        array_for_scrl_sub.push((glb_span_reflow_hilight_elems[glb_span_reflow_hilight_elems.length - 1]).getBoundingClientRect().bottom - array_for_scrl_sub[0]);
                    }
                    flap_ct = Math.round((array_for_scrl_sub[1] + wh) / ww) - 1;
                    array_for_scrl_sub.push(flap_ct);
                    array_for_scrl.push(array_for_scrl_sub);
                    array_for_scrl_sub = [];
                    flap_ct = 0;
                }

                array_voice_str_size.push(array_voice_str_size_sub);
                array_voice_str_order.push(array_voice_str_order_sub);
                sentence_qty += 1;
            }
            continue;
        }
        /*========================================
        match_us_mark_div
            X:初期値
            E:次も英語読み
            AE:日本語読みから英語読みに切り替わった
            N:次も日本語読み
            AN:英語読みから日本語読みに切り替わった
        =========================================*/
        if (arg[i].indexOf(us_mark) != -1) {
            if (match_us_mark_div == "X") {
                match_us_mark_div = "E";
            } else if (match_us_mark_div == "AN") {
                match_us_mark_div = "AE";
            } else if (match_us_mark_div == "N") {
                match_us_mark_div = "AE";
            } else if (match_us_mark_div == "AE") {
                match_us_mark_div = "E";
            } else if (match_us_mark_div == "E") {
                match_us_mark_div = "E";
            }
        } else {
            if (match_us_mark_div == "X") {
                match_us_mark_div = "N";
            } else if (match_us_mark_div == "E") {
                match_us_mark_div = "AN";
            } else if (match_us_mark_div == "AE") {
                match_us_mark_div = "AN";
            } else if (match_us_mark_div == "AN") {
                match_us_mark_div = "N";
            } else if (match_us_mark_div == "N") {
                match_us_mark_div = "N";
            }
        }

        //phrase_ari_short_flg:文節区切-ari_short,md_ari_hlton,md_ari_hiloffの時、true
        if (phrase_ari_short_flg || get_phrase_umu() == "nasi_strctrl") {
            //=文頭の文節が日本語読みで「。」で終わる場合
            if (match_us_mark_div == "N" && arg[i].charAt(arg[i].length - 1) == "。") {
                pre_jp_end_flg = true;
                voice_str += arg[i].substring(0, arg[i].length - 1);
                array_voice_str_size_sub.push(arg[i].length);
                array_voice_str_size.push(array_voice_str_size_sub);
                array_voice_str_order_sub.push(phrase_elem_idx);
                array_voice_str_order.push(array_voice_str_order_sub);
                array_voice_str.push(voice_str);
                if (get_reflow_mode() && get_phrase_umu() != "ari" && !pr_speech_flg) {
                    if (get_reflow_writing_mode() == "V") {
                        array_for_scrl_sub.push(array_for_scrl_sub[0] - b_elem_rect.left);
                    } else if (get_reflow_writing_mode() == "H") {
                        array_for_scrl_sub.push(b_elem_rect.bottom - array_for_scrl_sub[0]);
                    }
                    flap_ct = Math.round((array_for_scrl_sub[1] + wh) / ww) - 1;
                    array_for_scrl_sub.push(flap_ct);
                    array_for_scrl.push(array_for_scrl_sub);
                    array_for_scrl_sub = [];
                    flap_ct = 0;
                }
                voice_str = "";
                array_voice_str_size_sub = [];
                array_voice_str_order_sub = [];
                phrase_elem_idx += 1;
                sentence_qty += 1;
                //=文節の読み言語が変わる場合
            } else if (match_us_mark_div == "AN") {
                array_voice_str_size.push(array_voice_str_size_sub);
                array_voice_str_order.push(array_voice_str_order_sub);
                array_voice_str.push(voice_str);
                if (get_reflow_mode() && get_phrase_umu() != "ari" && !pr_speech_flg) {
                    if (get_reflow_writing_mode() == "V") {
                        array_for_scrl_sub.push(array_for_scrl_sub[0] - b_elem_rect.left);
                    } else if (get_reflow_writing_mode() == "H") {
                        array_for_scrl_sub.push(b_elem_rect.bottom - array_for_scrl_sub[0]);
                    }
                    flap_ct = Math.round((array_for_scrl_sub[1] + wh) / ww) - 1;
                    array_for_scrl_sub.push(flap_ct);
                    array_for_scrl.push(array_for_scrl_sub);
                    array_for_scrl_sub = [];
                    flap_ct = 0;
                }

                voice_str = "";
                array_voice_str_size_sub = [];
                array_voice_str_order_sub = [];

                voice_str = arg[i] + delimita;
                phrase_elem_idx += 1;
                sentence_qty += 1;
                if (arg[i].charAt(arg[i].length - 1) == "。") {
                    pre_jp_end_flg = true;
                    array_voice_str_size_sub.push(arg[i].length);
                    array_voice_str_size.push(array_voice_str_size_sub);
                    array_voice_str_order_sub.push(phrase_elem_idx);
                    array_voice_str_order.push(array_voice_str_order_sub);
                    array_voice_str.push(voice_str);
                    if (get_reflow_mode() && get_phrase_umu() != "ari" && !pr_speech_flg) {
                        if (get_reflow_writing_mode() == "V") {
                            array_for_scrl_sub.push(array_for_scrl_sub[0] - b_elem_rect.left);
                        } else if (get_reflow_writing_mode() == "H") {
                            array_for_scrl_sub.push(b_elem_rect.bottom - array_for_scrl_sub[0]);
                        }
                        flap_ct = Math.round((array_for_scrl_sub[1] + wh) / ww) - 1;
                        array_for_scrl_sub.push(flap_ct);
                        array_for_scrl.push(array_for_scrl_sub);
                        array_for_scrl_sub = [];
                        flap_ct = 0;
                    }
                    voice_str = "";
                    array_voice_str_size_sub = [];
                    array_voice_str_order_sub = [];

                    voice_str = arg[i] + delimita;
                    phrase_elem_idx += 1;
                    sentence_qty += 1;

                }
            } else if (match_us_mark_div == "AE") {
                //全行程が日本語読みで文節末尾が「。」でない場合
                if (!pre_jp_end_flg) {
                    array_voice_str_size.push(array_voice_str_size_sub);
                    array_voice_str_order.push(array_voice_str_order_sub);
                    array_voice_str.push(voice_str);
                    if (get_reflow_mode() && get_phrase_umu() != "ari" && !pr_speech_flg) {
                        if (get_reflow_writing_mode() == "V") {
                            array_for_scrl_sub.push(array_for_scrl_sub[0] - b_elem_rect.left);
                        } else if (get_reflow_writing_mode() == "H") {
                            array_for_scrl_sub.push(b_elem_rect.bottom - array_for_scrl_sub[0]);
                        }
                        flap_ct = Math.round((array_for_scrl_sub[1] + wh) / ww) - 1;
                        array_for_scrl_sub.push(flap_ct);
                        array_for_scrl.push(array_for_scrl_sub);
                        array_for_scrl_sub = [];
                        flap_ct = 0;
                    }
                    pre_jp_end_flg = false;
                }
                voice_str = "";
                array_voice_str_size_sub = [];
                array_voice_str_order_sub = [];

                voice_str = arg[i] + delimita;
                phrase_elem_idx += 1;
                sentence_qty += 1;
            } else {
                const t_arg = arg[i].replace(/。/g, "");
                voice_str += t_arg + delimita;
                array_voice_str_size_sub.push(arg[i].length);
                array_voice_str_order_sub.push(phrase_elem_idx);
                phrase_elem_idx += 1;
            }
        } else {
            voice_str += arg[i];
        }
    }

    
    //if(get_phrase_umu() == "ari_short"){
    if (phrase_ari_short_flg || get_phrase_umu() == "nasi_strctrl") {
        //段落内の最初の文が英文の場合(array_voice_str_idxは0 )
        if (array_voice_str[array_voice_str_idx].match(us_mark_reg) && get_phrase_umu() != "nasi_strctrl") {
            let fct;
            if (get_phrase_umu() == "ari_short") {
                fct = (array_voice_str[array_voice_str_idx].match(new RegExp("。", "g")) || []).length;
            } else {
                fct = (array_voice_str[array_voice_str_idx].match(new RegExp("\\^", "g")) || []).length;
            }
            //const fct= ( array_voice_str[array_voice_str_idx].match( new RegExp( "\\^", "g" ) ) || [] ).length;
            //let temp_array=[];
            for (let m = 0; m < fct; m++) {
                temp_array.push(glb_ct_for_hilight + m);
            }
            fl_flg = true;
            sentence_delimita_qty += (fct - 1);
            //sentence_delimita_qty += fct;
            hilight2(temp_array);
        }

        //文をハイライト
        if (get_phrase_umu() == "ari_short" || get_phrase_umu() == "_md_ari_hlton") {
            hilight();
        } else if (get_phrase_umu() == "md_ari_hiloff") {
            hilight2(array_voice_str_order[array_voice_str_idx]);
        } else if (get_phrase_umu() == "nasi_strctrl") {//get_phrase_umu() == "nasi"){
            hilight();
        } else {
            hilight();
        }
        /*
        if(get_phrase_umu() == "_nasi_strctrl"){
            let str = "";
            for(let ti=0;ti<array_voice_str.length;ti++){
                str += array_voice_str[ti] + "。";
            }
            speak_exe(str);
        */
        //}else{
        speak_exe(array_voice_str[array_voice_str_idx]);//array_voice_str_idxは0からスタートする
        //}
    } else {
        hilight();
        speak_exe(voice_str);
    }
    console.log(array_for_scrl);
    console.log(array_voice_str);


    if (get_reflow_mode() && get_phrase_umu() != "ari" && !pr_speech_flg) {
        if (get_reflow_writing_mode() == "V") {
            set_param(glb_span_reflow_hilight_first_elem.getBoundingClientRect().right);
            get_elem_byId(targ).style.width = orgn_width;
            get_elem_byId(targ).scrollLeft = orgn_scrl_left;
        } else if (get_reflow_writing_mode() == "H") {
            set_param(glb_span_reflow_hilight_first_elem.getBoundingClientRect().top);
            get_elem_byId(targ).style.height = orgn_height;
            get_elem_byId(targ).scrollTop = orgn_scrl_top;
        }
    }
    
    //if(glb_ct != 0)
    console.log("exec_scr_motion");

    exec_scr_motion();
}
//========================== step2 ==========================
let pre_cct = -1;
glb_uttr.onboundary = function (e) {
    console.log("glb_uttr.onboundary");
    let sct = "";
    let cct;
    //文節区切り短の場合
    if (phrase_ari_short_flg) {
        //英文の場合
        if (array_voice_str[array_voice_str_idx].match(us_mark_reg)) {
            //前回のonboundary時が英文の場合
            if (fl_flg) {
                ; //何もしない
                //前回のonboundary時が和文の場合
            } else {
                fl_flg = true;
                //pre-phraseのハイライトを消す
                glb_span_hilight_elems[glb_ct_for_hilight].style.backgroundColor = "";
                if (reflow_flg && !pr_speech_flg) glb_span_reflow_hilight_elems[glb_ct_for_hilight].style.backgroundColor = '';
                //sentence_delimita_qtyにphrase数を加算
                let fct;
                if (get_phrase_umu() == "ari_short") {
                    fct = (array_voice_str[array_voice_str_idx].match(new RegExp("。", "g")) || []).length;
                } else {
                    fct = (array_voice_str[array_voice_str_idx].match(new RegExp("\\^", "g")) || []).length;
                }
                //ハイライト
                for (let m = 0; m < fct; m++) {
                    //temp_array.push(glb_ct_for_hilight + m);
                    temp_array.push(sentence_delimita_qty + m);//valid
                }
                sentence_delimita_qty += fct;
                hilight2(temp_array);
            }
            return;
            //和文の場合
        } else {
            //前回のonboundary時が英文の場合
            if (fl_flg) {
                fl_flg = false;
                //ハイライト消灯
                erase_hilight3(temp_array);
                //sentence_delimita_qty += 1;
                temp_array = [];
                //前回のonboundary時が和文の場合
            } else {
                ; //何もしない
            }
        }
        //glb_uttr.onendで次の文章がある場合最初のphraseをhilightさせる。
        if (e.charIndex == 0) {
            hilight();
            /*
            if(array_voice_str_size[array_voice_str_idx][pre_cct] !== undefined && array_voice_str_size[array_voice_str_idx][pre_cct]<4 && get_phrase_umu() == "_md_ari_hlton"){
                if(glb_span_hilight_elems[glb_ct_for_hilight + 1] != undefined){
                    //next-phraseが英文でない場合
                    if(array_voice_str[array_voice_str_idx + 1] != undefined && !array_voice_str[array_voice_str_idx + 1].match(us_mark_reg)){
                        glb_ct_for_hilight += 1;
                        hilight(false);
                    }
                    //glb_ct_for_hilight -= 1;
                }
            }
            */
            //pre_cct = 0;
        }
        //ipadでは、e.charLengthがundefinedになる。またsubstringに対応していない。
        sct = array_voice_str[array_voice_str_idx].slice(0, e.charIndex);
        //let cct;
        if (get_phrase_umu() == "ari_short") {
            cct = (sct.match(new RegExp("\\。", "g")) || []).length;
        } else {
            cct = (sct.match(new RegExp("\\^", "g")) || []).length;
        }
        if (pre_cct < cct) {
            glb_ct_for_hilight = sentence_delimita_qty + cct;
            //文をハイライト
            if (get_phrase_umu() == "ari_short" || get_phrase_umu() == "md_ari_hlton") {
                hilight();
                /*
                if(array_voice_str_size[array_voice_str_idx][cct] !== undefined && array_voice_str_size[array_voice_str_idx][pre_cct]<3 && get_phrase_umu() == "_md_ari_hlton"){
                    if(glb_span_hilight_elems[glb_ct_for_hilight + 1] != undefined){
                        //next-phraseが英文でない場合
                        if(array_voice_str[array_voice_str_idx + 1] != undefined && !array_voice_str[array_voice_str_idx + 1].match(us_mark_reg)){
                            glb_ct_for_hilight += 1;
                            hilight(false);
                        }
                    }
                }
                */
            } else if (get_phrase_umu() == "md_ari_hiloff") {
                //文単位ハイライトの場合
                if (phrase_nash_flg) {
                    ;//何もしない。
                    //文単位ハイライトの場合で、読み終わった文節(中)のハイライトが消える場合。
                } else {
                    erase_hilight2(glb_ct_for_hilight - 1);
                }
            }
            pre_cct = cct;//phrase_ari_short_flgがtrueの場合pre_cctにはcctの最大値が格納される。
        }
    }
    //onboundaryが発火せずにonendが発火する場合がある
}

//========================== step3 ==========================
glb_uttr.onend = function (e) {
    console.log("glb_uttr.onend");
    if (pause) return;
    if (phrase_ari_short_flg) {
        //===== step4 =====
        ex_phrase_short_brief_stop();
        return;
    }
    if (get_phrase_umu() == "nasi_strctrl") {
        //===== step4 =====
        phrase_nasi_brief_stop();
        return;
    }
    glb_uttr_onend_method();

}

//========================== step4 ==========================
let sentence_delimita_qty = 0;
let ex_phrase_short_brief_stop = function () {
    console.log("ex_phrase_short_brief_stop");
    //div class=StrCtrl内の全ての文章を読み終わった場合
    //===== step5 =====
    if (array_voice_str_idx >= sentence_qty - 1) {
        //===== step6 =====
        console.log("StrCtrlEnd");

        //========================= 自動スクロール ===========================
        
        //if (glb_span_elems.length - 1 == glb_ct) exec_scr_motion();

        //============================================  

        //glb_uttr_onend_methodの前処理をする
        reset_ex_phrase_short_param();
        //文が読み終わったが全ての文章を読み終わっていない場合
    } else {
        //===== step5 =====
        console.log("StrCtrlNotEnd");
        //t_cct = 0;
        array_voice_str_idx += 1;//次の文を読む
        if (array_voice_str[array_voice_str_idx] != undefined) {

            //========================= 自動スクロール ===========================
            exec_scr_motion();
            //============================================  

            sentence_delimita_qty += pre_cct + 1;
            //文をハイライト
            if (get_phrase_umu() == "ari_short" || get_phrase_umu() == "md_ari_hlton") {
                hilight();

            } else if (get_phrase_umu() == "md_ari_hiloff") {
                if (phrase_nash_flg) erase_hilight2(glb_ct_for_hilight);
                hilight2(array_voice_str_order[array_voice_str_idx]);
            }
            //hilight2(array_voice_str_size[array_voice_str_idx]);
            speak_exe(array_voice_str[array_voice_str_idx]);
            pre_cct = -1;
        } else {
            reset_ex_phrase_short_param();
            return;
        }
        //sentence_delimita_qty += pre_cct + 1;
        console.log("sentence_delimita_qty=" + sentence_delimita_qty);
    }
}

//========================== step4 ==========================
let phrase_nasi_brief_stop = function () {
    console.log("phrase_nasi_brief_stop");
    //array_voice_str_idx = 0;
    //===== step7(last) =====
    //glb_uttr_onend_method();    
    if (array_voice_str_idx >= sentence_qty - 1) {
        array_voice_str_idx = 0;

        //========================= 自動スクロール ===========================
        //if (glb_span_elems.length > glb_ct) exec_scr_motion();
        //============================================  

        //===== step7(last) =====
        glb_uttr_onend_method();
    } else {
        array_voice_str_idx += 1;//次の文を読む
        if (array_voice_str[array_voice_str_idx] != undefined) {

            //========================= 自動スクロール ===========================
            exec_scr_motion();
            //============================================  


            speak_exe(array_voice_str[array_voice_str_idx]);
        } else {
            array_voice_str_idx = 0;
            //===== step7(last) =====
            glb_uttr_onend_method();
        }
    }
}

//========================== step6 ==========================
let reset_ex_phrase_short_param = function () {
    console.log("reset_ex_phrase_short_param");
    if (phrase_nash_flg) erase_hilight2(glb_ct_for_hilight);
    array_voice_str_idx = 0;
    sentence_delimita_qty = 0;
    //glb_ct_for_hilight += 1;
    glb_ct_for_hilight = 0;
    //===== step7 =====
    glb_uttr_onend_method();
}

//========================== step7(last) ==========================
let glb_uttr_onend_method = async function (e) {
    console.log("glb_uttr_onend_method");
    /*===================================================
    pause → onend → glb_uttr_onend_method
    音枠で全て読み終わった場合onendから次のphraseに移行させない
    ================================================== */
    if (glb_ct >= glb_span_elems.length && (current_sort == 2 || current_sort == 3)) {
        speech_quit_btn_click(null);
        return;
    }
    /*****************************************************
    pauseでonendが発火する。
    文節読み間隔短でpauseが実行された場合、onend処理を無効にする
    *****************************************************/
    if (pause && phrase_ari_short_flg) return;
    voice_str = "";
    //文節読み間隔短の場合。
    if (phrase_ari_short_flg) {
        //選択解除
        for (i = 0; i < glb_span_elems.length; i++) {
            if (phrase_ari_short_flg) {
                const t_elem = glb_span_elems[i].getElementsByClassName("phrase");
                let t_elem_reflow;
                if (reflow_flg && !pr_speech_flg) {
                    if (glb_span_reflow_elems[i] != undefined) {
                        t_elem_reflow = glb_span_reflow_elems[i].getElementsByClassName("phrase");
                    }
                    for (j = 0; j < t_elem.length; j++) {
                        t_elem[j].style.backgroundColor = "";
                        if (t_elem_reflow[j] == undefined) continue;
                        t_elem_reflow[j].style.backgroundColor = "";
                    }
                } else {
                    for (j = 0; j < t_elem.length; j++) {
                        t_elem[j].style.backgroundColor = "";
                    }
                }
            } else {
                glb_span_elems[i].style.backgroundColor = "";
                if (reflow_flg && !pr_speech_flg) glb_span_reflow_elems[i].style.backgroundColor = '';
            }
        }
        glb_ct_for_hilight = 0;
        pre_glb_ct = -1;
        //pre_glb_ct_for_hilight = -1;
        match_us_mark_div = "X";
        sentence_delimita_qty = 0;
        //glb_span_elems = [];これがあるとオートスピーチがおかしくなる
        pre_cct = 0;
    }
    if (chng_bg.length != 0) {
        glb_span_hilight_elems[chng_bg[0]].style.color = chng_bg[1];
        chng_bg = [];
    }
    if (!glb_cancel_flg) {// && !glb_synth.pending ) {
        if(get_phrase_umu()=="ari"){
            const speech_interval = get_elem_byId("speech_interval").options[get_elem_byId("speech_interval").selectedIndex].value;
            await _sleep(speech_interval);
        }
        voice_trans(glb_ct);
    }
    //set_speech_flg(false);//リフロー画面でのクリックで音声発火を有効にする。
    //set_page_speaking_flg(false);//固定画面でのクリックで音声発火を有効にする。
}
let speak_exe = function (arg) {
    set_voice(jp_voice_name);
    if (arg.match(us_mark)) {
        //glb_uttr.voice = speechSynthesis.getVoices().filter(voice => voice.name === voiceSelect.value)[1] ;
        set_voice(us_voice_name);
        //制御に使用した文字を削除する。[.?/]は文書が途切れないので、途切れる「,」を付加する。
        arg = arg.replace(/__us__/g, "").replace(/。/g, "").replace(/\^/g, " ").replace(/\.|\/|\!|\(|\)/g, ",").replace(/\?/, "? ").toLowerCase();
        //想定されるアルファベット以外の文字を削除して、全て小文字に変換する
        //arg = arg.replace(/(\.|\?|\/|\-|\,|\!|・)/g,"").toLowerCase();
    }
    //arg = arg.replace(/は/g,"派");
    //arg = arg.replace(/\^/g,"");
    //arg = arg.replace(/__us__/g,"").replace(/。/g,"").replace(/^/g,"");
    if (get_jp_voice_name().indexOf("Google") != -1) arg = arg.replace(/\^/g, "");
    //arg = arg.replace(/朕/g,"");
    glb_uttr.text = arg;
    glb_synth.speak(glb_uttr);
}
//speech_orderに沿って読み上げの最中の場合のみ、auto_speechを有効にするための判別flg
let current_sort;
let exe_auto_speech_flg = function () {
    if (current_sort == 0 || current_sort == 1 || current_sort == 6 || current_sort == 7) {
        return true;
    } else {
        return false;
    }
}
//*************** メインメニューで▶︎がクリックされて駆動 ******************
let directPageFrame = "";
//view_ctrl.jsからアクセス
function set_directPageFrame(val){
    directPageFrame = val;
}
function pre_voice_trans(sort, vElem, reflow_flg, velm = null) {
    t_d = 0;
    const targ = (directPageFrame == "pageFrame_left") ? "divFrame_left" : "divFrame_right";
    if (get_reflow_writing_mode() == "V") {
        init_scrl_posi = get_elem_byId(targ).scrollLeft;
        t_scrl = get_elem_byId(targ).scrollLeft * -1;
    } else if (get_reflow_writing_mode() == "H") {
        if (get_dsp_mode() == "single") {
            init_scrl_posi = get_elem_byId(targ).scrollTop + Number(get_elem_byId(targ).style.top.replace("px", "")) + 14;
            t_scrl = get_elem_byId(targ).scrollTop;// + Number(get_elem_byId(targ).style.top.replace("px","")) + 14;
        } else {
            init_scrl_posi = get_elem_byId(targ).scrollTop;
            t_scrl = get_elem_byId(targ).scrollTop;
        }
    }


    pre_scrl = 0;
    //t_d = 0;
    //reset_scrl_val();
    //alert(sort);
    //alert(vElem);
    //alert(reflow_flg);
    current_sort = sort;
    //===speech開始時点でglb_cancel_flgをfalseにしてglb_ctがインクリメントされるようにする。
    glb_cancel_flg = false;
    if (pause) {
        pause = false;
        //選択解除        
        for (i = 0; i < glb_span_elems.length; i++) {
            glb_span_elems[i].style.backgroundColor = "";
            if (reflow_flg && !pr_speech_flg) glb_span_reflow_elems[i].style.backgroundColor = '';
        }
        var index = getElemIdx(current_span_elem, glb_span_elems);
        glb_ct = index;
        voice_trans(index);
        return;
    } else {
        //glb_cancel_flg = false;
        if (!glb_flg) {
            if (sort == 0) {
                //指定ページ側のspeech_orderに格納されたStrCtrlのid順に読み上げる
                glb_span_elems = get_phrase_elems(vElem, 'pageFrame_left', reflow_flg, velm);//document.getElementsByClassName("phrase");
                directPageFrame = "pageFrame_left";
            } else if (sort == 1) {
                //指定ページ側のspeech_orderに格納されたStrCtrlのid順に読み上げる
                glb_span_elems = get_phrase_elems(vElem, 'pageFrame_right', reflow_flg, velm);//document.getElementsByClassName("phrase");  
                directPageFrame = "pageFrame_right";
            } else if (sort == 2) {
                //指定ページ側のspeech_element(音枠)に格納されたStrCtrlのid順に読み上げる
                glb_span_elems = get_speech_element(vElem, 'pageFrame_left', velm);//document.getElementsByClassName("phrase");
                directPageFrame = "pageFrame_left";
                k_flg = false;
            } else if (sort == 3) {
                //指定ページ側のspeech_element(音枠)に格納されたStrCtrlのid順に読み上げる
                glb_span_elems = get_speech_element(vElem, 'pageFrame_right', velm);//document.getElementsByClassName("phrase");
                directPageFrame = "pageFrame_right";
                k_flg = false;
                //vElem(div_id)のinnerTextを読み上げる
            } else if (sort == 4) {
                glb_span_elems = set_phrase_elems(vElem);
                //プレビューを読み上げる
            } else if (sort == 5) {
                glb_span_elems = set_StrCtrl_elems(vElem);
                //分節区切り無し
            } else if (sort == 6) {
                glb_span_elems = get_StrCtrl_elems(vElem, 'pageFrame_left', reflow_flg, velm);//document.getElementsByClassName("phrase");
                k_flg = false;
                directPageFrame = "pageFrame_left";
            } else if (sort == 7) {
                glb_span_elems = get_StrCtrl_elems(vElem, 'pageFrame_right', reflow_flg, velm);//document.getElementsByClassName("phrase");
                k_flg = false;
                directPageFrame = "pageFrame_right";
            }
            //glb_flg = true; ********************** 本稼働時にはコメントアウトを外す
        }
    }
    if (glb_span_elems.length == 0 && exe_auto_speech_flg()) {
        auto_speech();
        return;
    }
    //スピーチ開始行の選択がある場合、該当する<span>エレメントを取得する
    if (window.getSelection() != "") {
        let vrg = window.getSelection().getRangeAt(0).getBoundingClientRect();
        let vrg_top = vrg.top;
        let vrg_left = vrg.left;
        let target_spnan_elem;//取得した<span>エレメントを格納
        flg = false;
        for (i = 1; i < glb_span_elems.length; i++) {
            if (vrg_top >= glb_span_elems[i].getBoundingClientRect().top - 20 && vrg_top <= glb_span_elems[i].getBoundingClientRect().top + 10) {
                if (vrg_left <= glb_span_elems[i].getBoundingClientRect().left) {
                    target_spnan_elem = glb_span_elems[i];
                    flg = true;
                    break;
                }
            }
        }
        if (!flg) {
            show_reg_info("選択範囲を選び直して下さい。");
            window.getSelection().removeAllRanges();
            return;
        }
        window.getSelection().removeAllRanges();
        var index = getElemIdx(target_spnan_elem, glb_span_elems);   //glb_span_elems.indexOf(target_spnan_elem);
        glb_ct = index - 1;
        voice_trans(glb_ct);
    } else {
        voice_trans(0);
    }
}
//************************ 音声変換開始 ************************
//開始行の指定がない場合は、i=0からスタート
let phrase_ari_start_flg = false;
function voice_trans(i) {
    var vs;
    if (glb_span_elems === undefined) return;
    const ct = glb_span_elems.length;
    //音声変換終了処理
    if (i >= ct) { //メイン
        glb_cancel_flg = true;
        let elm = glb_span_elems;//get_phrase_elems();//document.getElementsByClassName("phrase");
        let elm2 = glb_span_reflow_elems;
        for (i = 0; i < elm.length; i++) {
            elm[i].style.backgroundColor = "";
            if (reflow_flg && !pr_speech_flg) elm2[i].style.backgroundColor = "";
        }
        glb_ct = 0;
        pre_glb_ct = -1;
        glb_ct_for_hilight_array_0 = -1;
        pre_glb_ct_array = [];
        glb_ct_for_hilight = 0;
        reset_pr_speech_elem();
        //set_page_speaking_flg(false);
        //reset_vspeech_flg(false);
        set_speech_param(0);
        glb_span_elems = [];
        reset_scrl_val();
        //音枠のフレーム色を元に戻す
        show_speech_frame2();
        //============= auto_speech ==============
        if (exe_auto_speech_flg()) auto_speech();
        return;
    }
    let vss;
    if (glb_span_elems[i] == null) return;
    if (glb_span_elems[i].classList.contains("StrCtrl")) {
        //sort = "StrCtrl";
        glb_span_hilight_elems = [];
        glb_span_reflow_hilight_elems = [];
        let tmp_reflow_elems;
        if (reflow_flg && !pr_speech_flg) {
            tmp_reflow_elems = glb_span_reflow_elems[i].getElementsByClassName("phrase");
        }
        vss = voice_trans_rcs(glb_span_elems[i].getElementsByClassName("phrase"), true, tmp_reflow_elems);
    } else {
        //sort = "phrase";
        if (get_phrase_umu() == "ari") {// && current_sort !=2 && current_sort != 3){
            if (start_phrase_elem == null) {
                phrase_ari_start_flg = true;
            } else {
                if (glb_span_elems[i] === start_phrase_elem) phrase_ari_start_flg = true;
            }
            if (phrase_ari_start_flg) {
                vss = voice_trans_rcs(glb_span_elems[i].childNodes);
            } else {
                vss = [];
            }
        } else {
            vss = voice_trans_rcs(glb_span_elems[i].childNodes);
        }
    }
    //vsにテキストが含まれる場合
    vs = vss.join("");
    if (vs != "") {
        play_voice(vss);
        glb_ct += 1;
    } else {
        glb_ct += 1;
        if (glb_ct >= ct) {
            glb_cancel_flg = true;
            let elm = glb_span_elems;//get_phrase_elems();//document.getElementsByClassName("phrase");
            let elm2 = glb_span_reflow_elems;
            for (i = 0; i < elm.length; i++) {
                //if(elm[i].style.backgroundColor == voice_highlight_color)
                elm[i].style.backgroundColor = "";
                if (reflow_flg && !pr_speech_flg) elm2[i].style.backgroundColor = "";
            }
            glb_ct = 0;
            pre_glb_ct = -1;
            glb_ct_for_hilight_array_0 = -1;
            pre_glb_ct_array = [];
            glb_ct_for_hilight = 0;
            reset_scrl_val();
            reset_pr_speech_elem();
            //set_page_speaking_flg(false);
            //reset_vspeech_flg(false);
            set_speech_param(0);
            glb_span_elems = [];
            //音枠のフレーム色を元に戻す
            show_speech_frame2();
            //remove_nodes();
            if (exe_auto_speech_flg()) auto_speech();
        } else {
            voice_trans(glb_ct);
        }
    }
}
/*
function get_vs(i){
    var vs;
    const ct = glb_span_elems.length;
    //改行・スペースの削除-----------------------------------
    if(i>=ct){
        glb_cancel_flg = true;
        let elm = glb_span_elems;//get_phrase_elems();//document.getElementsByClassName("phrase");
        let elm2 = glb_span_reflow_elems;
        for(i=0;i<elm.length;i++){
            //if(elm[i].style.backgroundColor == voice_highlight_color)
            elm[i].style.backgroundColor="";
            if(reflow_flg) elm2[i].style.backgroundColor="";
        }
        glb_ct = 0;
        pre_glb_ct = -1;
        return;
    }
    vs = voice_trans_rcs(glb_span_elems[i].childNodes);
    vs = vs.replace(/\r?\n/g,"");
    vs = vs.replace(/\s+/g, "");
    if(vs == 'undefined'){
        vs = "";
    }
    //vsにテキストが含まれる場合
    if (vs != ""){
        glb_ct +=  1;
        return vs;
    }else{
        get_vs(glb_ct);
    }

}
*/
function furigana_rt(rt_elem, arg) {
    let rt;
    if (rt_elem.classList.contains("hira")) {
        rt = arg.replace(/[\u30a1-\u30f6]/g, function (match) {
            var chr = match.charCodeAt(0) - 0x60;
            return String.fromCharCode(chr);
        });
    } else if (rt_elem.classList.contains("kata")) {
        rt = arg.replace(/[\u3041-\u3096]/g, function (match) {
            var chr = match.charCodeAt(0) + 0x60;
            return String.fromCharCode(chr);
        });
    } else {
        rt = arg;
    }
    return rt;
}
//ElementsからTextNodeのみの取得。
/*************************************************
flg:true-velementsがphraseクラスエレメントの場合。
    false-velementsがphraseクラスエレメントの子ノード場合。
*************************************************/
let k_flg = false;
function voice_trans_rcs(velements, flg = false, velements_reflow = []) {
    let voice_str_rcs_array = []; //戻り値
    if (flg) {
        for (let k = 0; k < velements.length; k++) {
            //文節区切り短の場合
            if (phrase_ari_short_flg || get_phrase_umu() == "nasi_strctrl") {
                if (start_phrase_elem == null || get_phrase_umu() == "nasi_strctrl") {
                    k_flg = true;
                } else {
                    if (velements[k] === start_phrase_elem) k_flg = true;
                }
                if (k_flg) {
                    const rt_srt = voice_trans_rcs_sub(velements[k].childNodes);
                    if (rt_srt == "") continue;
                    voice_str_rcs_array.push(rt_srt);
                    glb_span_hilight_elems.push(velements[k]);
                    glb_span_reflow_hilight_elems.push(velements_reflow[k]);
                }
            } else {
                const rt_srt = voice_trans_rcs_sub(velements[k].childNodes);
                if (rt_srt == "") continue;
                voice_str_rcs_array.push(rt_srt);
            }
            /*
            const rt_srt = voice_trans_rcs_sub(velements[k].childNodes);
            if(rt_srt == "") continue;
            voice_str_rcs_array.push(rt_srt);
            //文節区切り短の場合
            if(phrase_ari_short_flg){
                glb_span_hilight_elems.push(velements[k]);
                glb_span_reflow_hilight_elems.push(velements_reflow[k]);
            }
            */
        }
    } else {
        voice_str_rcs_array.push(voice_trans_rcs_sub(velements));
    }
    function voice_trans_rcs_sub(elements) {
        const cct = elements.length;
        let voice_str_rcs = "";
        for (let j = 0; j < cct; j++) {
            //取得したノードがテキストノードの場合
            if (elements.item(j).nodeType == 3) {
                voice_str_rcs += elements.item(j).textContent;
                //エレメントノードの場合
            } else if (elements.item(j).nodeType == 1) {
                //rubyタグの場合は子ノードのrtのtextContentを取得
                if (elements.item(j).tagName == "RUBY") {
                    if(elements.item(j).classList.contains("m_kanji")){
                        voice_str_rcs += yomi_kanji_prefix + elements.item(j).firstChild.data;
                    }else{
                        const txt = elements.item(j).getElementsByTagName("rt")[0].textContent;
                        voice_str_rcs += furigana_rt(elements.item(j).children[0],txt);    
                    }
                } else if (elements.item(j).tagName == "US") {
                    voice_str_rcs = voice_str_rcs + us_mark;
                    const temp_us = elements.item(j).textContent;
                    if (temp_us != "") {
                        for (let ui = 0; ui < temp_us.length; ui++) {
                            voice_str_rcs = voice_str_rcs + "," + temp_us.charAt(ui) + ",";
                        }
                        //voice_str_rcs = voice_str_rcs + ","
                    }
                } else {
                    voice_str_rcs += voice_trans_rcs(elements.item(j).childNodes)
                }
            }
        }
        //改行・スペース等を削除
        voice_str_rcs = voice_str_rcs.replace(/\r?\n/g, "").replace(/\s+/g, "").replace("〜", "");
        if (voice_str_rcs == 'undefined') {
            voice_str_rcs = "";
        }
        return voice_str_rcs;
    }
    return voice_str_rcs_array;
}
