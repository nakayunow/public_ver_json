//let iframe_id;
const StrCtrl_elem = document.getElementsByClassName("StrCtrl");
const _sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
//親にページが音声再生中と伝える。反対側のページは音声再生できない。
let vspeech_flg = false;//trueの場合、StrCtrlクリックでpauseにする。faseの場合、StrCtrlクリックでspeechにする。
let memo_flg = false;
let saved_memo_id = [];//保存済みだがページ未ダウンロードのメモのid
let thisPageNo;
let pre_voice_trans_arg1;
let current_mode;

function reset_speech_flg(){
    vspeech_flg = false;
    window.parent.set_speech_flg(false);
}
function set_vspeech_flg(val){
    vspeech_flg = val;
}
window.ondblclick = function(){
    if(current_mode != "speech") return;
    //auto_speech()終了
    window.parent.set_execution_quit();
    window.parent.voice_trans_quit();
    window.parent.voice_trans_quit();
    //speech_flg = false; 
    document.getSelection().removeAllRanges();
}
window.onclick = function(){
    if(current_mode != "speech") return;
    //if(window.parent.isAutoPageExecution()) return;
    //音声合成中の場合一時停止させる
    if(vspeech_flg){
        window.parent.voice_trans_pause();
        vspeech_flg = false;
        window.parent.set_speech_flg(false);      
    }else{
        //speechモードで読み上げ時以外で発火する(初期はvspeech_flg = falseの為)とNGのため
        if(!window.parent.getPauseFlg()) return;
        vspeech_flg = true;
        window.parent.set_speech_flg(true);
        if(window.parent.get_phrase_ari_short_flg() && window.parent.getPauseFlg()){
            window.parent.voice_trans_restart();
            return;
        }
        window.parent.pre_voice_trans(pre_voice_trans_arg1,"",false);
        //vspeech_flg = true;
        //window.parent.set_speech_flg(true);
    }
}
function set_layer(mode){
    current_mode = mode;
    //<img id="image" src="book.jpeg"/> zIndex = 100
    //memo関連 zIndex = 105
    //speech時 透明要素 span_elems[j].zIndex = 104;
    let elems = document.getElementsByClassName("memo_mark");
    switch(current_mode){
        case "speech":
            for(i=0;i<StrCtrl_elem.length;i++){
                StrCtrl_elem[i].style.zIndex = 101;
                StrCtrl_elem[i].style.border = "";
            }
            for(i=0;i<elems.length;i++){
                elems[i].style.pointerEvents = "none";
            }
            document.getElementById("my_canvas").style.zIndex = 102;    
            break;
        case "paint":
            document.getElementById("my_canvas").style.zIndex = 104;
            break;
        case "memo":
            for(i=0;i<StrCtrl_elem.length;i++){
                StrCtrl_elem[i].style.zIndex = 104;
                StrCtrl_elem[i].style.backgroundColor = "";
            }
            for(j=0;j<elems.length;j++){
                elems[j].style.pointerEvents = "";
            }
            document.getElementById("my_canvas").style.zIndex = 102;
            //document.getElementById("memo").style.zIndex = 105;
            break;
    }
}
let rect = null;
function pre_memo(val){
    if(val == "") return;
    const range = val.getRangeAt(0);
    rect = range.getBoundingClientRect();
}
function exec_memo(){
    if(rect == null) return;
    if(rect.right - rect.left > 10) add_memo(rect);
    rect = null;
}
/*
function setUserSelectOn(){
    if(current_mode == "memo") $('StrCtrl').css('user-select','text');
}
function setUserSelectOff(){
    if(current_mode == "memo") $('StrCtrl').css('user-select','none');  
}
*/
let reg_pre_voice_trans_arg1;
window.onload = function(){
    //画面の設定
    //教科書画像の縮小率取得し設定する
    document.getElementById("image").style.zoom = window.parent.get_book_img_zoom();

    //文書表示位置の調整
    const back_layer_elem = document.getElementById("back_layer");
    back_layer_elem.style.marginTop = window.parent.get_margin_top() + "px";
    back_layer_elem.style.marginLeft = window.parent.get_margin_left() + "px";
    // ------------ canvasのサイズ設定(htmlのサイズに合わせる)------------
    const canvas = document.getElementById("my_canvas");
    canvas.width = document.documentElement.scrollWidth;//image.naturalWidth * $('#image').css('zoom');
    canvas.height = document.documentElement.scrollHeight;//image.naturalHeight * $('#image').css('zoom');

    //現在のmodeにより各要素のzIndexを設定する
    set_layer(window.parent.get_mode());
    /* *************************************************************
    StrCtrlへのspeechメソッド組み込み
    pre_voice_trans_arg1 = 0 or 6 : pageFrame_leftのページをspeech
    pre_voice_trans_arg1 = 1 or 7 : pageFrame_rightのページをspeech
    ************************************************************* */
    const str = window.location.href.split("/");
    thisPageNo = str.slice(-2,-1); //cocoa用
    
    /* node.js用
    for(i=0;i<str.length;i++){
        if(str[i].startsWith("page_no=")){
            thisPageNo = str[i].replace("page_no=","");
        }
    }
    */
    /* **********************************************************
        左右ページのどちらかにダミーページがある場合の処理と
        htmlのサイズをiframeのサイズに合わせる処理の為の情報発信

        parentのiframeのwidthを調整する為、parentに情報を送る
        parent method
        contact_dammy_page(page_side,dammy,html_width,img_n_width)
            dammy = ""  ダミーページ無し
            dammy = "L" 左ページがダミー
            dammy = "R" 右ページがダミー
    ********************************************************** */
   
    let left_page = window.parent.get_left_page();
    let show_page_flg = false;//ページ遷移アニメ終了フラグ
    let dammy = "";
    let html_width;
    if(thisPageNo == left_page){
        //page_side = "L";
        //左ページがダミーの場合。反対側のiframe-widthを連結ページ幅にする
        if(document.getElementById("image").getAttribute("src") == ""){
            dammy = "L";
        }
    }else{
        //page_side = "R";
        //右ページがダミーの場合。反対側のiframe-widthを連結ページ幅にする
        const vdammy = window.parent.get_glb_dammy();
        if(vdammy == ""){
            if(document.getElementById("image").getAttribute("src") == ""){
                dammy = "R";
            }
        }else{
            dammy = vdammy;
        }
        //右側ページの場合の時、ページ遷移状態解除
        show_page_flg = true;
    }
    reg_pre_voice_trans_arg1 = pre_voice_trans_arg1;


    //htmlのサイズをiframeのサイズに合わせる
    html_width = document.documentElement.scrollWidth;
    //img_n_width = document.getElementById("image").naturalWidth * (Number(window.parent.get_book_img_zoom().replace("%",""))/100);
    window.parent.contact_dammy_page(dammy,html_width);
    
    $('span').on('touchend mouseup',function(e) {
        pre_memo(window.getSelection());
    });

    /* *************************************************************
    speechモードの場合の画面の設定
    StrCtrlのコピーを表示用として、透明化したStrCtrlを最前面に設置する。
    StrCtrlがcanvasより前面なのでクリックすることによりspeechが開始される
    ************************************************************* */
    //const body_elem = document.getElementsByTagName("body");
    for(i=0;i<StrCtrl_elem.length;i++){
        const strCtrl_fragment = document.createRange().createContextualFragment(StrCtrl_elem[i].outerHTML);
        strCtrl_fragment.childNodes[0].classList.remove("StrCtrl");
        strCtrl_fragment.childNodes[0].classList.add("StrCtrl_ex");
        strCtrl_fragment.childNodes[0].style.zIndex = 103; //#image(zIndex:100)の上
        strCtrl_fragment.childNodes[0].style.backgroundColor = "";
        const span_elems = strCtrl_fragment.childNodes[0].getElementsByTagName("span");
        for(j=0;j<span_elems.length;j++){
            span_elems[j].style.opacity = 0.0;//0.0; //StrCtrl(z-index:101)
            span_elems[j].style.backgroundColor = "";
            //目次のページをクリックした時に発動。ページジャンプ。
            if(span_elems[j].classList.contains("toc")){
                span_elems[j].zIndex = 104;
                span_elems[j].onclick = function(e){
                    e.stopPropagation();
                    window.parent.trans_directed_page(this.innerHTML);
                    const left_page_no = window.parent.get_directed_page(this.innerHTML)[0];
                    const right_page_no =window.parent.get_directed_page(this.innerHTML)[1];
                    window.parent.set_left_page(left_page_no);
                    window.parent.set_right_page(right_page_no);
                    window.parent.req_page(left_page_no,right_page_no);
                }
            }
        }
        strCtrl_fragment.childNodes[0].id = StrCtrl_elem[i].id.replace("div","exdiv"); //div_1 → exdiv_1
        //StrCtrlクリックで発火
        strCtrl_fragment.childNodes[0].onclick = function(e){
            if(window.parent.get_mode() != "speech") return;
            if(window.parent.isAutoPageExecution()) return;
            if(window.parent.get_page_speaking_flg()) return;
            if(this.innerHTML != "") return;
            window.parent.set_page_speaking_flg(true);
            e.stopPropagation();
            //音声枠をクリックした場合
            if(pre_voice_trans_arg1 == 0 || pre_voice_trans_arg1 == 6){
                pre_voice_trans_arg1 = 2;
            }else if(pre_voice_trans_arg1 == 1 || pre_voice_trans_arg1 == 7){
                pre_voice_trans_arg1 = 3;
            }
            window.parent.pre_voice_trans(pre_voice_trans_arg1,this.id.replace("exdiv","div"),null);
            //reg_pre_voice_trans_arg1の値を本来の値に戻す
            pre_voice_trans_arg1 = reg_pre_voice_trans_arg1;
            window.parent.set_page_speaking_flg(true);
        }
        //fragmentのphraseエレメント群
        let phrase_elems = strCtrl_fragment.childNodes[0].getElementsByClassName("phrase");
        //オリジナルのphraseエレメント群
        let orign_phrase_elems = StrCtrl_elem[i].getElementsByClassName("phrase");
        for(let r=0;r<phrase_elems.length;r++){
            phrase_elems[r].onclick = function(e){
                if(window.parent.get_mode() != "speech") return;
                if(window.parent.isAutoPageExecution()) return;
                if(window.parent.get_page_speaking_flg()) return;
                window.parent.set_page_speaking_flg(true);
                e.stopPropagation();
                if(vspeech_flg){
                    window.parent.voice_trans_pause();
                    vspeech_flg = false;
                    window.parent.set_speech_flg(false);       
                }else{
                    window.parent.pre_voice_trans(pre_voice_trans_arg1,phrase_elems[r].parentNode.id.replace("exdiv","div"),false,orign_phrase_elems[r]);
                        vspeech_flg = true;
                    window.parent.set_speech_flg(true);
                }
                //オートページが指定されている場合、speechをしているページ番号を親要素に登録する
                if(window.parent.get_auto_page_changing_flg){
                    window.parent.set_current_page(thisPageNo);
                }
            }
        }
        strCtrl_fragment.childNodes[0].ondblclick = function(e){
            e.stopPropagation();
            window.parent.set_execution_quit();
            window.parent.voice_trans_quit();
            window.parent.voice_trans_quit();
            window.parent.set_page_speaking_flg(false);
            //speech_flg = false; 
            document.getSelection().removeAllRanges();
        }
        
        strCtrl_fragment.childNodes[0].blur();
        back_layer_elem.appendChild(strCtrl_fragment);
    }
    // --------------- メモの情報取得 ----------------
    var req = new XMLHttpRequest(),
    method = "GET",
    file = "/materials/" + window.parent.get_material_name() + "/" + thisPageNo + "/memo.txt";
    req.open(method, file, true);
    req.onreadystatechange = function () {
        if(req.readyState === 4 && req.status === 200) {
            const rest = req.responseText.replace(/\r?\n/g,"");
            const qstr = rest.split("^^^");
            for(i=0;i<qstr.length-1;i++){
                let qdata = qstr[i].split("=");
                document.getElementById(qdata[0]).value = qdata[1];
            }
        }
    };
    req.send();
    // --------------- メモ表示のイベントリスナー設定 ----------------

    //let elems = document.getElementsByClassName("memo_mark");
    //for(i=0;i<elems.length;i++){
    $('.memo_mark').on("click touchend",function(e){
        let id = this.id;
        e.preventDefault();
        id2 = id.replace("memo_mark","memo_container");
        id3 = id.replace("memo_mark","memo_arrow");
        if(document.getElementById(id2).style.display == "none"){
            document.getElementById(id2).style.display = "";
            document.getElementById(id3).style.display = "";
        }else{
            document.getElementById(id2).style.display = "none";
            document.getElementById(id3).style.display = "none";
        }
    });
    //}
    // --------------- メモ情報の置換元格納 ----------------
    //document.getElementById("rep_src").value = document.getElementById("memo_div").outerHTML;
    
    
    /*
    let image = document.getElementById("image");
    let cssStyleDeclaration = getComputedStyle( window.parent.document.getElementById("divFrame_left"), null ) ;
    let iframe_width = cssStyleDeclaration.getPropertyValue( "width" ).replace("px","") ;
    
    //$('#image').css('zoom',Number(iframe_width)/image.naturalWidth);
    */
    var img = new Image();
    img.src = "./image.png";
    if(img.width > 0){
        set_img(img); //canvas_event.jsのメソッド。canvasにペイント情報を反映
    }
    set_page_config();
    window.parent.count_up();
    //--------------------------------------------
    if(window.parent.isAutoPageExecution() && !window.parent.get_reflow_mode()){
        window.parent.execute_auto_speech(thisPageNo);
    }
    if(show_page_flg){
        window.parent.page_trans_conver_non();
        window.parent.single_mode_func_exe();
        //window.parent.adjust_dsp_size_under_single();
    }
    if(!window.parent.get_show_speech_frame_flg()){
        show_speech_frame();
    }else{
        hide_speech_frame()
    }
    //右ページのダウロード
    if(window.parent.get_rpg() != "" && !show_page_flg){
        window.parent.req_Rpage();
        window.parent.reset_rpg();
    }


    // 各パラメーターの設定
    let interval_time = 100; // タップ時間判定間隔（ミリ秒）
    let longtouch_time = 500; // ロングタップ（長押し）時間（ミリ秒）interval_time の倍数

    // 判定用変数
    let touched = false; // タップ判定用
    let moveded = false; // フリック、スワイプ判定用
    let touch_time = 0; // タップ時間判定用
    let target_elem;
    let mousemove_start = false;
    $(".memo_mark").on({
        'mousedown touchstart': function (e) {
            target_elem = this;
            mousemove_start = true;
            e.preventDefault(); // 各イベントを無効に
            touched = true;
            touch_time = 0;
            document.interval = setInterval(function () {
                touch_time += interval_time; // タップ時間計測
                // ロングタップ判定
                if (touched && !moveded) {
                    // ◯ミリ秒経過時
                    if (touch_time === longtouch_time) {
                        // 行いたい処理
                        if(confirm("メモを削除します。よろしいですか?")){
                            remove_memo(target_elem);
                            if(thisPageNo == window.parent.get_left_page()){                        
                                window.parent.reg_paint_memo('pageFrame_left','reg_frame_L');
                            }else{
                                window.parent.reg_paint_memo('pageFrame_right','reg_frame_R');
                            }
                            //alert("保存ボタンを押すと削除が完了します。");
                        }
                    }
                }
            }, interval_time);
        },
        'mouseup touchend': function (e) {
            e.preventDefault(); // 各イベントを無効に
            // リリース時
            /*
            if (touched && !moveded) {
                // 通常タップ判定
                if (touch_time < longtouch_time) {
                    // 行いたい処理
                    console.log('通常タップ！');
                }
                // ロングタップ後のリリース時
                if (touch_time <= longtouch_time) {
                    // 行いたい処理
                    console.log('ロングタップ終わり！');
                }
            }
            */

            // 各パラメーターをリセット
            touched = false;
            moveded = false;
            mousemove_start = false;
            clearInterval(document.interval);
            //preventEvent = false;
        },
        'touchmove': function (e) {
            e.preventDefault(); // 各イベントを無効に
            moveded = true; // フリック、スワイプ時は、ロングタップ判定しないためのフラグ
        },
        'mousemove': function(e){
            e.preventDefault(); // 各イベントを無効に
            if(mousemove_start){
                moveded = true;
            }
        }
    });
    //文字囲込み要否設定
    const sts0 = document.styleSheets[0];
    if(window.parent.get_str_wrap() == "ari"){ 
        sts0.cssRules[3].style.whiteSpace = "normal";
        sts0.cssRules[7].style.whiteSpace = "normal";
    }else{
        sts0.cssRules[3].style.whiteSpace = "nowrap";
        sts0.cssRules[7].style.whiteSpace = "nowrap";
    }
}//window.onload終了

function get_contact(){
    /* **********************************************************
        左右ページのどちらかにダミーページがある場合の処理と
        htmlのサイズをiframeのサイズに合わせる処理の為の情報発信

        parentのiframeのwidthを調整する為、parentに情報を送る
        parent method
        contact_dammy_page(page_side,dammy,html_width,img_n_width)
            dammy = ""  ダミーページ無し
            dammy = "L" 左ページがダミー
            dammy = "R" 右ページがダミー
    ********************************************************** */
    let left_page = window.parent.get_left_page();
    let dammy = "";
    let html_width;
    if(thisPageNo == left_page){
        //左ページがダミーの場合。反対側のiframe-widthを連結ページ幅にする
        if(document.getElementById("image").getAttribute("src") == ""){
            dammy = "L";
        }
    }else{
        //右ページがダミーの場合。反対側のiframe-widthを連結ページ幅にする
        if(document.getElementById("image").getAttribute("src") == ""){
            dammy = "R";
        }
    }
    //htmlのサイズをiframeのサイズに合わせる
    html_width = document.documentElement.scrollWidth;
    window.parent.contact_dammy_page(dammy,html_width);
}      
let trans_resio = 0;
function set_body_transform(v,r){
    document.getElementsByTagName("body")[0].style.transform = v;
    trans_resio = r;
}
function get_trans_resio(){
    return trans_resio;
}
//設定内容をページに反映させる
let furigana_sort = "katakana";
let font_sort = "serif";
let font_color = "#000000";
let noun_color = "#000000";
let verb_color = "#000000";
function set_page_config(){
    //ルビの有無およびカタカナ・ひらがなの設定
    const rt_elems = document.getElementsByTagName("rt");
    //if(window.parent.get_furigana_umu() == "ari"){
        for(i=0;i<rt_elems.length;i++){
            rt_elems[i].style.display = "";
            //rt_elems[i].style.visibility = "visible";
            if(window.parent.get_furigana_sort() == "hiragana" && window.parent.get_furigana_sort() != furigana_sort){
                rt_elems[i].innerHTML = rt_elems[i].innerHTML.replace(/[\u30a1-\u30f6]/g, function(match) {
                var chr = match.charCodeAt(0) - 0x60;
                return String.fromCharCode(chr);
                });
            }else if(window.parent.get_furigana_sort() == "katakana" && window.parent.get_furigana_sort() != furigana_sort){
                rt_elems[i].innerHTML = rt_elems[i].innerHTML.replace(/[\u3041-\u3096]/g, function(match) {
                    var chr = match.charCodeAt(0) + 0x60;
                return String.fromCharCode(chr);
                });                  
            }
        }
        furigana_sort = window.parent.get_furigana_sort();
    //本文にフリガナ無しで窓リフローにフリガナ有りの場合
    //}else{
    if(window.parent.get_furigana_umu() == "nasi"){
        for(i=0;i<rt_elems.length;i++){
            rt_elems[i].style.display = "none";
            //rt_elems[i].style.visibility = "hidden";
        }
    }
    if(window.parent.get_furigana_umu_prf() == "ari"){
        const pr_elems = document.getElementsByClassName("PrSpeechElem");
        for(bi=0;bi<pr_elems.length;bi++){
            const pr_rt_elems = pr_elems[bi].getElementsByTagName("rt");
            for(ci=0;ci<pr_rt_elems.length;ci++){
                pr_rt_elems[ci].style.display = "";
            }
        }    
    }
    /*
    //窓リフローのフリガナ有無設定
    const qelems = document.getElementsByClassName("PrSpeechElem");
    if(window.parent.get_furigana_umu_prf() == "ari"){
        for(q1=0;q1<qelems.length;q1++){
            const qrts = qelems[q1].getElementsByTagName("rt");
            for(q2=0;q2<qrts.length;q2++){
                qrts[q2].style.display = "";
            }
        }
    }else{
        for(r1=0;r1<qelems.length;r1++){
            const qrts = qelems[r1].getElementsByTagName("rt");
            for(r2=0;r2<qrts.length;r2++){
                qrts[r2].style.display = "none";
            }
        }
    }
    */
    //フォントの設定--明朝・ゴシック
    //const StrCtrl_elems = document.getElementsByClassName("StrCtrl");
    if(window.parent.get_font_sort() != font_sort){
        const StrCtrl_ex_elem = document.getElementsByClassName("StrCtrl_ex");
        font_sort = window.parent.get_font_sort();
        for(let i=0;i<StrCtrl_elem.length;i++){
            StrCtrl_elem[i].style.fontFamily = font_sort;
        }
        for(let j=0;j<StrCtrl_ex_elem.length;j++){
            StrCtrl_ex_elem[j].style.fontFamily = font_sort;
        }
    }
    //フォントの設定--文字色
    const sts0 = document.styleSheets.item(0);
    if(window.parent.get_font_color() != font_color){
        font_color = window.parent.get_font_color();
        if(font_color != ""){
            sts0.cssRules.item(0).style.setProperty("color",font_color);
            for(i=0;i<StrCtrl_elem.length;i++){
                StrCtrl_elem[i].classList.add("font_color");
            }
        }else{
            for(i=0;i<StrCtrl_elem.length;i++){
                StrCtrl_elem[i].classList.remove("font_color");
            }
        }
    }
    //フォントの設定--文字(名詞)色
    const sts1 = document.styleSheets.item(0);
    const noun_elems = document.getElementsByClassName("noun");
    if(window.parent.get_noun_color() != noun_color){
        noun_color = window.parent.get_noun_color();
        if(noun_color != ""){
            sts1.cssRules.item(1).style.setProperty("color",noun_color);
            for(i=0;i<noun_elems.length;i++){
                noun_elems[i].classList.add("noun_color");
            }
        }else{
            for(i=0;i<noun_elems.length;i++){
                noun_elems[i].classList.remove("noun_color");
            }
        }
    }
    //フォントの設定--文字(動詞)色
    const sts2 = document.styleSheets.item(0);
    const verb_elems = document.getElementsByClassName("verb");
    if(window.parent.get_verb_color() != verb_color){
        verb_color = window.parent.get_verb_color();
        if(verb_color != ""){
            sts2.cssRules.item(2).style.setProperty("color",verb_color);
            for(i=0;i<verb_elems.length;i++){
                verb_elems[i].classList.add("verb_color");
            }
        }else{
            for(i=0;i<verb_elems.length;i++){
                verb_elems[i].classList.remove("verb_color");
            } 
        }
    }
    //分節区切り有無の設定
    let left_page = window.parent.get_left_page();
    if(thisPageNo == left_page){
        if(window.parent.get_phrase_umu() == "ari"){
            pre_voice_trans_arg1 = 0;
        }else{
            pre_voice_trans_arg1 = 6;
        }
    }else{
        if(window.parent.get_phrase_umu() == "ari"){
            pre_voice_trans_arg1 = 1;
        }else{
            pre_voice_trans_arg1 = 7;
        }
    }
    reg_pre_voice_trans_arg1 = pre_voice_trans_arg1;
    vspeech_flg = false;
    window.parent.set_speech_flg(false);
}
//view_ctrl.jsから呼び出す
function show_speech_frame(){
    const StrCtrl_ex_elem = document.getElementsByClassName("StrCtrl_ex");
    for(i=0;i<StrCtrl_elem.length;i++){
        if(StrCtrl_elem[i].classList.contains("SpeechElem") || StrCtrl_elem[i].classList.contains("PrSpeechElem")){
            StrCtrl_elem[i].style.border = "3px ridge green";
            StrCtrl_ex_elem[i].style.border = "3px ridge green";
        }
    }
}
function hide_speech_frame(){
    const StrCtrl_ex_elem = document.getElementsByClassName("StrCtrl_ex");
    for(i=0;i<StrCtrl_elem.length;i++){
        if(StrCtrl_elem[i].classList.contains("SpeechElem") || StrCtrl_elem[i].classList.contains("PrSpeechElem")){
            StrCtrl_elem[i].style.border = "0px none";
            StrCtrl_ex_elem[i].style.border = "0px none";
        }
    }
}
//親ウィンドウから呼び出す
function get_page_no(){
    return thisPageNo;
}
function get_id_ct(){
    let ct = 0;
    let elems = document.getElementsByClassName("memo_mark");
    if(elems == null) return 1;
    for(i=0;i<elems.length;i++){
        if(Number(elems[i].id.split(":")[1])>ct){
            ct = Number(elems[i].id.split(":")[1]);
        }
    }
    return ct + 1;
}

//メモの追加
function add_memo(vrg){
    //document.getElementById("rep_src").value = document.getElementById("memo_div").outerHTML;
    let id_ct = get_id_ct();
    const dy = 30;
    //選択範囲を取得
    //let vrg = rg.getBoundingClientRect();
    
    create_selected_area(vrg,id_ct);//メモ用divの生成
    create_arrow(vrg,dy,id_ct)
    create_memo(vrg,dy,id_ct);
    window.getSelection().removeAllRanges();
}

function create_selected_area(clientRect,id){
    let e_div = document.createElement("div");
    const in_padding = 2;
    const trans_resio = 1/get_trans_resio();
    e_div.style.width = clientRect.width + in_padding * 2 +"px";
    e_div.style.top = (clientRect.bottom - clientRect.height - in_padding*2)*trans_resio + "px";
    e_div.style.left = (clientRect.left - in_padding)*trans_resio +  "px";
    e_div.style.height = clientRect.height + in_padding + "px";
    e_div.setAttribute("class","memo_mark")
    e_div.id = "memo_mark:" + id;
    document.getElementById("memo_div").appendChild(e_div);
    e_div.onclick = function(e){
        if(saved_memo_id.indexOf(this.id.split(":")[1]) == -1){
            remove_memo(this);
        }else{
            let id = this.id;
            e.preventDefault();
            id2 = id.replace("memo_mark","memo_container");
            id3 = id.replace("memo_mark","memo_arrow");
            if(document.getElementById(id2).style.display == "none"){
                document.getElementById(id2).style.display = "";
                document.getElementById(id3).style.display = "";
            }else{
                document.getElementById(id2).style.display = "none";
                document.getElementById(id3).style.display = "none";
            }        
        }
    }
}

function create_memo(clientRect,dy,id){
    let e_div = document.createElement("div");
    //e_div.style.width = "25px";
    //e_div.style.height = "25px";
    const trans_resio = 1/get_trans_resio();
    e_div.style.display = "inline-block";
    e_div.style.top = (clientRect.bottom + dy)*trans_resio + "px";
    e_div.style.left = clientRect.left*trans_resio + "px";
    e_div.setAttribute("class","memo");
    e_div.id = "memo_container:" + id;
    e_div.style.zIndex = 10000;
    //const name = e_div.style.top + ":" + e_div.style.left;
    //e_div.setAttribute("name",name);

    let e_txtar = document.createElement("textarea");
    e_txtar.id = "memo:" + id;
    e_txtar.setAttribute("class","memo_txt")
    e_txtar.style.position = "relative";
    e_txtar.style.zIndex = -1;
    //e_txtar.classList.add("memo_txt");
    e_div.appendChild(e_txtar);
    document.getElementById("memo_div").appendChild(e_div);
    drag(e_div);
    //ipad用
    e_div.addEventListener('touchmove',function(e){
        let touchcoord = e.targetTouches[0];
        this.style.left = touchcoord.pageX*trans_resio + "px";
        this.style.top = touchcoord.pageY*trans_resio + "px";
        adjust_arrow(e_div);
    });

    e_div.onmouseup = function(){
        this.style.display = "block";
        this.style.width = "1px";
        this.style.height = "1px";
        this.firstChild.focus();
    }

    e_txtar.addEventListener('input', function(){
        this.style.height = 'auto';
        this.style.height = this.scrollHeight + 'px';
    }, false);

    e_txtar.onblur = function(){
        this.parentNode.style.display = "inline-block";
        this.parentNode.style.width = "";
        this.parentNode.style.height = "";
    }
    /*
    e_txtar.onclick = function(){
        alert("j" + this.classList + "j");
    }
    */
}
function create_arrow(clientRect,dy,id){
    const elem = document.createElement("div");
    const trans_resio = 1/get_trans_resio();
    elem.style.top = clientRect.bottom*trans_resio + "px";
    elem.style.left = clientRect.left*trans_resio + "px";
    elem.style.width ="0px";
    elem.style.height = dy + "px";
    elem.size = 1;
    //elem.style.transform = "rotate(90deg)" 
    elem.setAttribute("class","memo_arrow")
    elem.id = "memo_arrow:" + id;
    document.getElementById("memo_div").appendChild(elem);
}
function adjust_arrow(memo_container){
    let d_elem = memo_container;
    let id = d_elem.id.replace("memo_container","memo_arrow")
    const trans_resio = 1/get_trans_resio();
    //let id2 = d_elem.id.replace("memo_container","memo")
    //let memo = document.getElementById(id2);
    let arrow = document.getElementById(id);
    let dx = change_num(arrow.style.left) - change_num(d_elem.style.left);
    let dy = change_num(arrow.style.top) - change_num(d_elem.style.top);
    let tmp_deg = Math.atan(dx/dy) * 180.0 / Math.PI;
    let d1 = dy < 0 ? 0 : 180;
    let deg = tmp_deg * (-1) + d1;
    arrow.style.transform = "rotate(" + deg + "deg)" 
    let height = Math.sqrt(Math.pow(dy,2) + Math.pow(dx,2));
    arrow.style.height = height + "px";
    //memo.value = "x=" + dx + " d1=" + d1 + " deg=" + deg +" w=" + height;
}
function remove_memo(val){
    //document.getElementById("rep_src").value = document.getElementById("memo_div").outerHTML;
    const id = val.id.split(":")[1];
    document.getElementById("memo_mark:" + id).remove();//drag要素
    document.getElementById("memo:" + id).remove();//textareaを包含
    document.getElementById("memo_container:" + id).remove();//textareaを包含
    document.getElementById("memo_arrow:" + id).remove();//矢印
    //document.getElementById("memo_container" + id).remove();
}
function change_num(val){
    let rt = Number(val.replace("px",""));
    return rt;
}

function reg_memo(arg){
    //let md = document.getElementById("memo_div")
    let elems1 = document.getElementsByClassName("memo_txt");//textarea
    let elems2 = document.getElementsByClassName("memo_arrow");//やじるし
    let elems3 = document.getElementsByClassName("memo");//drag要素
    let str = "";
    for(i=0;i<elems1.length;i++){
        str += elems1[i].id + "=" + elems1[i].value + "^^^";
        saved_memo_id.push(elems1[i].id.split(":")[1]);//memo:1 → 1
        //elems[i].style.display = "none";
        elems2[i].style.display = "none";
        elems3[i].style.display = "none";
    }
    let tmp_txtar = document.createElement("textarea");
    tmp_txtar.value = document.getElementById("memo_div").innerHTML;
    
    window.parent.document.getElementById(arg).contentDocument.getElementById("data").value = tmp_txtar.value;//document.getElementById("memo_div").innerHTML;
    window.parent.document.getElementById(arg).contentDocument.getElementById("memo_str").value = str;
    window.parent.document.getElementById(arg).contentDocument.getElementById("key2").value = "material_memo_reg";
    window.parent.document.getElementById(arg).contentDocument.getElementById("rep_src").value = document.getElementById("rep_src").value;
    window.parent.document.getElementById(arg).contentDocument.getElementById("memo_reg_frm").submit();
}
/* ****************************************
    arg : reg_frame_L or reg_frame_R
**************************************** */
function reg_paint(arg){
    let canvas = document.getElementById("my_canvas");
    //let ctx = canvas.getContext('2d');
    //canvasの画像をBase64形式に変換する
    window.parent.document.getElementById(arg).contentDocument.getElementById("data").value = canvas.toDataURL('image/png').replace(/^.*,/, '');
    window.parent.document.getElementById(arg).contentDocument.getElementById("key2").value = "material_paint_reg";
    window.parent.document.getElementById(arg).contentDocument.getElementById("memo_reg_frm").submit(); 
}
function reg_pageNo(){
    const data = {key2:"reg_pageNo",memo_str:thisPageNo};
    //var data = key:{ param1: 'abc', param2: 100 }; // POSTメソッドで送信するデータ
    var xmlHttpRequest = new XMLHttpRequest();
    xmlHttpRequest.onreadystatechange = function()
    {
        var READYSTATE_COMPLETED = 4;
        var HTTP_STATUS_OK = 200;

        if( this.readyState == READYSTATE_COMPLETED
        && this.status == HTTP_STATUS_OK )
        {
            // レスポンスの表示
            window.parent.show_reg_info("保存しました。");
            //alert("保存しました。");
        }
    }

    xmlHttpRequest.open( 'POST', 'http://localhost:8080', false);

    // サーバに対して解析方法を指定する
    xmlHttpRequest.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );

    // データをリクエスト ボディに含めて送信する
    xmlHttpRequest.send( window.parent.EncodeHTMLForm( data ) ); 
    // HTMLフォームの形式にデータを変換する
}

function drag(val){
	$(val).draggable({
		drag: function(event,ui){
			adjust_arrow(val);
		}
	});
};
